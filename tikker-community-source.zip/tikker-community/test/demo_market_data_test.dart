import 'package:flutter_test/flutter_test.dart';
import 'package:tikker/features/chart/chart_state.dart';
import 'package:tikker/features/demo/demo_market_data.dart';

void main() {
  test('fictional series is deterministic, valid and disjoint for all frames',
      () {
    for (final frame in ChartTimeframe.values) {
      final closes = <double>{};
      for (final symbol in DemoMarketData.symbols) {
        final first = DemoMarketData.candles(symbol, frame);
        final replayed = DemoMarketData.candles(symbol, frame, step: 2);
        expect(first.length, DemoMarketData.initialBars);
        expect(replayed.length, first.length + 2);
        expect(first.map((c) => c.close),
            replayed.take(first.length).map((c) => c.close));
        closes.add(first.last.close);
        DateTime? previous;
        for (final candle in replayed) {
          expect(candle.low, greaterThan(0));
          expect(candle.low, lessThanOrEqualTo(candle.open));
          expect(candle.low, lessThanOrEqualTo(candle.close));
          expect(candle.high, greaterThanOrEqualTo(candle.open));
          expect(candle.high, greaterThanOrEqualTo(candle.close));
          expect(candle.volume, greaterThan(0));
          final time = DateTime.parse(candle.timestamp);
          if (!frame.isIntraday) expect(time.hour, 0);
          if (previous != null) expect(time.isAfter(previous), isTrue);
          previous = time;
        }
        expect(DemoMarketData.stock(symbol).logoUrl, isNull);
        expect(DemoMarketData.stock(symbol).isDomesticKisTicker, isFalse);
      }
      expect(closes.length, DemoMarketData.symbols.length);
    }
  });

  test('unknown or real symbols and out of range steps never fall back', () {
    expect(() => DemoMarketData.candles('005930', ChartTimeframe.day),
        throwsArgumentError);
    expect(
        () => DemoMarketData.candles('DEMO001', ChartTimeframe.day, step: -1),
        throwsRangeError);
    expect(
        () => DemoMarketData.candles('DEMO001', ChartTimeframe.day,
            step: DemoMarketData.maxReplaySteps + 1),
        throwsRangeError);
  });
}
