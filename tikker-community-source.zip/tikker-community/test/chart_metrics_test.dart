import 'package:flutter_test/flutter_test.dart';
import 'package:tikker/features/chart/chart_metrics.dart';

void main() {
  test(
      'SMA uses complete equal-weight windows and is stable across viewport slices',
      () {
    expect(simpleMovingAverage([10, 20, 30, 60, 50], 3),
        [null, null, 20, 110 / 3, 140 / 3]);
    expect(simpleMovingAverage([10, 20], 3), [null, null]);
  });
  test('axis ticks are readable and bounded across price scales', () {
    expect(chartPriceTicks(181296, 315664),
        [200000, 225000, 250000, 275000, 300000]);
    expect(chartPriceTicks(0.1, 0.2).every((x) => x >= .1 && x <= .2), isTrue);
    expect(chartPriceTicks(4, 4), isEmpty);
    expect(chartPriceTicks(double.nan, 5), isEmpty);
  });
}
