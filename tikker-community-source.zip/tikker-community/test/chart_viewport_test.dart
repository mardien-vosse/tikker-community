import 'package:flutter_test/flutter_test.dart';
import 'package:tikker/features/chart/chart_viewport.dart';
import 'package:tikker/shared/models/market_models.dart';

List<CandlePoint> bars(int start, int count) => List.generate(
    count,
    (i) => CandlePoint(
        open: 100,
        high: 110,
        low: 90,
        close: 105,
        volume: 10,
        timestamp: DateTime.utc(2026, 9, 4, 0, start + i).toIso8601String()));

void main() {
  test('latest view is bounded while retaining full history', () {
    final data = bars(0, 200);
    final range = const ChartViewport().resolve(data);
    expect(range.start, 128);
    expect(range.end, 200);
    expect(data.length, 200);
  });

  test('historical view does not jump on new bars, prepend or rolling cache',
      () {
    final data = bars(50, 200);
    final view = const ChartViewport().pan(data, -50);
    expect(view.followsLatest, isFalse);
    final initial = view.resolve(data);
    for (final updated in [bars(50, 210), bars(0, 260), bars(70, 190)]) {
      final range = view.resolve(updated);
      expect(updated[range.start].timestamp, data[initial.start].timestamp);
      expect(updated[range.end - 1].timestamp, data[initial.end - 1].timestamp);
    }
  });

  test('latest follows append and pan to the end resumes following', () {
    final data = bars(0, 200);
    final historical = const ChartViewport().pan(data, -50);
    expect(historical.pan(data, 500).followsLatest, isTrue);
    expect(historical.latest().resolve(bars(0, 210)).end, 210);
  });

  test('zoom retains time under pointer away from boundaries', () {
    final data = bars(0, 200);
    final view = const ChartViewport().pan(data, -40);
    final before = view.resolve(data);
    final after = view.zoom(data, .5, anchor: .5).resolve(data);
    expect((before.start + before.end) / 2, (after.start + after.end) / 2);
  });

  test('empty and short history are bounded without manufacturing candles', () {
    expect(const ChartViewport().resolve([]).end, 0);
    final short = bars(0, 11);
    final view = const ChartViewport().pan(short, -100).zoom(short, .5);
    final range = view.resolve(short);
    expect(range.start, 0);
    expect(range.end, 11);
    expect(range.slots, 20);
  });
}
