import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:tikker/features/chart/chart_state.dart';
import 'package:tikker/features/chart/drawing_editor.dart';
import 'package:tikker/providers/app_preferences.dart';

const line = ChartDrawingAnnotation(
    tool: ChartDrawingTool.trend,
    startX: .2,
    startY: .6,
    endX: .8,
    endY: .3,
    startTime: '20261001',
    endTime: '20261016',
    startPrice: 200000,
    endPrice: 220000);

void main() {
  testWidgets(
      'numeric editor validates price and applies style to selected line',
      (tester) async {
    final container = ProviderContainer(overrides: [
      chartDrawingAnnotationsProvider.overrideWith((ref) => [line]),
      chartSelectedDrawingIndexProvider.overrideWith((ref) => 0),
    ]);
    addTearDown(container.dispose);
    await tester.pumpWidget(UncontrolledProviderScope(
        container: container,
        child: const MaterialApp(
            home: Scaffold(body: DrawingSelectionToolbar()))));
    await tester.tap(find.text('속성'));
    await tester.pumpAndSettle();
    final prices = find.byType(TextFormField);
    await tester.enterText(prices.at(1), '-1');
    await tester.tap(find.text('적용'));
    await tester.pumpAndSettle();
    expect(find.text('0보다 큰 가격을 입력하세요.'), findsOneWidget);
    await tester.enterText(prices.at(1), '210,000');
    await tester.enterText(prices.at(0), '지지선');
    await tester.tap(find.text('적용'));
    await tester.pumpAndSettle();
    expect(container.read(chartDrawingAnnotationsProvider).single.startPrice,
        210000);
    expect(container.read(chartDrawingAnnotationsProvider).single.label, '지지선');
    await tester.tap(find.byTooltip('선 잠금'));
    await tester.pump();
    expect(
        container.read(chartDrawingAnnotationsProvider).single.locked, isTrue);
    await tester.tap(find.byTooltip('선 숨김'));
    await tester.pump();
    expect(
        container.read(chartDrawingAnnotationsProvider).single.hidden, isTrue);
    await tester.tap(find.byTooltip('선 표시'));
    await tester.pump();
    expect(
        container.read(chartDrawingAnnotationsProvider).single.hidden, isFalse);
  });

  testWidgets('editing only label preserves hidden price precision',
      (tester) async {
    final original = line.copyWith(startPrice: 200000.123456);
    final container = ProviderContainer(overrides: [
      chartDrawingAnnotationsProvider.overrideWith((ref) => [original]),
      chartSelectedDrawingIndexProvider.overrideWith((ref) => 0),
    ]);
    addTearDown(container.dispose);
    await tester.pumpWidget(UncontrolledProviderScope(
        container: container,
        child: const MaterialApp(
            home: Scaffold(body: DrawingSelectionToolbar()))));
    await tester.tap(find.text('속성'));
    await tester.pumpAndSettle();
    expect(find.text('200000.123456'), findsNothing);
    await tester.enterText(find.byType(TextFormField).first, '메모만 변경');
    await tester.tap(find.text('적용'));
    await tester.pumpAndSettle();
    expect(container.read(chartDrawingAnnotationsProvider).single.startPrice,
        original.startPrice);
  });

  test('new line attributes survive persistence and legacy lines use defaults',
      () async {
    SharedPreferences.setMockInitialValues({});
    final store = await SharedPreferencesAppPreferencesStore.create();
    await store.saveDrawingAnnotations(
        symbol: '005930',
        timeframe: ChartTimeframe.day,
        drawings: [
          line.copyWith(
              colorValue: 0xFFFBBF24,
              strokeWidth: 3,
              channelOffset: 1500,
              dashed: true,
              locked: true,
              hidden: true,
              label: '중요')
        ]);
    final loaded = store
        .loadDrawingAnnotations(symbol: '005930', timeframe: ChartTimeframe.day)
        .single;
    expect(loaded.startPrice, line.startPrice);
    expect(loaded.colorValue, 0xFFFBBF24);
    expect(loaded.strokeWidth, 3);
    expect(loaded.channelOffset, 1500);
    expect(loaded.dashed && loaded.locked && loaded.hidden, isTrue);
    expect(loaded.label, '중요');
    expect(line.locked || line.hidden || line.dashed, isFalse);
  });
}
