import 'package:flutter_test/flutter_test.dart';
import 'package:tikker/features/chart/chart_state.dart';
import 'package:tikker/features/chart/chart_viewport.dart';
import 'package:tikker/features/chart/multi_chart_viewport.dart';
import 'package:tikker/shared/models/market_models.dart';

CandlePoint candle(String timestamp, double close) => CandlePoint(
      open: close,
      high: close + 1,
      low: close - 1,
      close: close,
      volume: 10,
      timestamp: timestamp,
    );

void main() {
  test('projects missing timestamps into empty shared slots', () {
    final first = [
      candle('20260904090000', 100),
      candle('20260904090100', 101),
      candle('20260904090300', 103),
    ];
    final second = [
      candle('20260904090000', 200),
      candle('20260904090200', 202),
      candle('20260904090300', 203),
    ];
    final window = MultiChartTimeline(
      [first, second],
      ChartTimeframe.minute,
    ).window(const ChartViewport(capacity: 20));

    expect(window.timestamps, hasLength(4));
    expect(window.project(first).slots, [16, 17, 19]);
    expect(window.project(second).slots, [16, 18, 19]);
  });

  test('shared viewport keeps all series on the same historical interval', () {
    final first = List.generate(40, (i) {
      final time = DateTime(2026, 9, 4, 9).add(Duration(minutes: i));
      return candle(time.toIso8601String(), 100.0 + i);
    });
    final second = [
      for (var i = 0; i < first.length; i++)
        if (i % 5 != 0) first[i],
    ];
    final timeline = MultiChartTimeline([first, second], ChartTimeframe.minute);
    final historical = const ChartViewport(capacity: 20)
        .panTimestamps(timeline.timestamps, -10);
    final window = timeline.window(historical);

    expect(window.range.start, 10);
    expect(window.range.end, 30);
    expect(window.project(first).candles.length, 20);
    expect(window.project(second).candles.length, 16);
  });
}
