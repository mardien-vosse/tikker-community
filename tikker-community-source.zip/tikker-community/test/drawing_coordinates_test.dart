import 'package:flutter_test/flutter_test.dart';
import 'package:tikker/features/chart/drawing_coordinates.dart';
import 'package:tikker/features/chart/chart_state.dart';
import 'package:tikker/shared/models/market_models.dart';

void main() {
  final candles = List.generate(
      100,
      (i) => CandlePoint(
          timestamp:
              DateTime(2026, 1, 1).add(Duration(days: i)).toIso8601String(),
          open: 100 + i.toDouble(),
          high: 110 + i.toDouble(),
          low: 90 + i.toDouble(),
          close: 100 + i.toDouble(),
          volume: 100));
  DrawingCoordinates coordinates(int start, int end, int slots) =>
      DrawingCoordinates(
          timestamps: candles.map((c) => c.timestamp).toList(),
          start: start,
          end: end,
          slots: slots,
          scale: ChartPriceScale(candles.sublist(start, end)));
  const line = ChartDrawingAnnotation(
      tool: ChartDrawingTool.trend, startX: .2, startY: .7, endX: .7, endY: .3);

  test('time and price anchors round trip after zoom, pan and scale changes',
      () {
    final original = coordinates(0, 100, 100).capture(line);
    for (final view in [
      coordinates(20, 60, 40),
      coordinates(50, 100, 50),
      coordinates(0, 100, 200)
    ]) {
      final projected = view.project(original);
      final restored = view.capture(projected);
      expect(restored.startTime, original.startTime);
      expect(restored.endTime, original.endTime);
      expect(restored.startPrice, closeTo(original.startPrice!, .00001));
      expect(restored.endPrice, closeTo(original.endPrice!, .00001));
    }
    expect(coordinates(50, 100, 50).project(original).startX, lessThan(0));
  });

  test(
      'multi-chart missing slots and prepended history preserve anchor position',
      () {
    final anchor = coordinates(0, 100, 100).capture(line);
    final timestamps = [
      DateTime(2025, 12, 31).toIso8601String(),
      ...candles.map((c) => c.timestamp)
    ];
    final shifted = DrawingCoordinates(
            timestamps: timestamps,
            start: 1,
            end: 101,
            slots: 100,
            scale: ChartPriceScale(candles))
        .project(anchor);
    expect(shifted.startX, closeTo(line.startX, .00001));
    expect(shifted.endY, closeTo(line.endY, .00001));
  });

  test(
      'magnet snaps to OHLC at the actual trading slot, including missing slots',
      () {
    final view = DrawingCoordinates(
        timestamps: candles.map((c) => c.timestamp).toList(),
        priceCandles: candles,
        start: 0,
        end: 100,
        slots: 100,
        scale: ChartPriceScale(candles));
    final snapped = view.snap(.205, view.scale.y(128));
    expect(snapped.x, closeTo(.205, .000001));
    expect(view.scale.price(snapped.y), closeTo(130, .000001));
  });

  test('empty data never manufactures anchors', () {
    expect(coordinates(0, 0, 0).capture(line).anchored, isFalse);
  });

  test('crosshair index follows the visible window and ignores empty slots',
      () {
    final coordinates = DrawingCoordinates(
      timestamps: List.generate(
        10,
        (index) => '2026-09-${(index + 1).toString().padLeft(2, '0')}',
      ),
      start: 4,
      end: 10,
      slots: 8,
      scale: ChartPriceScale(candles),
    );

    expect(coordinates.candleIndex(0), isNull);
    expect(coordinates.candleIndex(.24), isNull);
    expect(coordinates.candleIndex(.25), 4);
    expect(coordinates.candleIndex(.99), 9);
    expect(coordinates.candleIndex(1), isNull);
  });
}
