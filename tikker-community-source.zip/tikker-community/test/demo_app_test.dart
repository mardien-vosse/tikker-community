import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:tikker/features/chart/chart_panel.dart';
import 'package:tikker/features/chart/chart_state.dart';
import 'package:tikker/features/chart/candle_chart_painter.dart';
import 'package:tikker/features/demo/demo_app.dart';
import 'package:tikker/features/demo/demo_market_data.dart';
import 'package:tikker/features/demo/demo_providers.dart';
import 'package:tikker/providers/app_preferences.dart';
import 'package:tikker/providers/market_providers.dart';

void main() {
  Future<SharedPreferencesAppPreferencesStore> store() async {
    SharedPreferences.setMockInitialValues({});
    final result = await SharedPreferencesAppPreferencesStore.create(
        namespace: demoPreferencesNamespace);
    await result.saveSelectedSymbol('DEMO001');
    await result.saveWatchlistSymbols(DemoMarketData.symbols);
    await result.saveTimeframe(ChartTimeframe.minute);
    await result.saveMultiLayout(ChartMultiLayout.fourGrid);
    return result;
  }

  Future<void> launch(
      WidgetTester tester, AppPreferencesStore preferences) async {
    await tester.pumpWidget(ProviderScope(
        overrides: demoProviderOverrides(preferences),
        child: const AppPreferencesBinder(child: TikkerDemoApp())));
    await tester.pumpAndSettle();
  }

  testWidgets('Community boot, replay and narrow resize stay local',
      (tester) async {
    await tester.binding.setSurfaceSize(const Size(1280, 900));
    addTearDown(() => tester.binding.setSurfaceSize(null));
    final preferences = await store();
    await launch(tester, preferences);
    final container =
        ProviderScope.containerOf(tester.element(find.byType(ChartPanel)));
    expect(find.text('가상 시세로 자유롭게 탐색하세요 · 실제 투자 데이터가 아닙니다'), findsOneWidget);
    for (final symbol in DemoMarketData.symbols) {
      expect(find.byKey(ValueKey('multi-chart-tile-$symbol')), findsOneWidget);
    }
    expect(find.textContaining('AI'), findsNothing);
    expect(find.textContaining('KIS'), findsNothing);
    expect(find.textContaining('LIVE'), findsNothing);
    expect(find.textContaining('주문'), findsNothing);
    expect(find.byTooltip('차트 진단'), findsNothing);
    expect(find.byType(Image), findsNothing);
    final original = container.read(candleProvider).last.close;
    await tester.tap(find.byKey(const ValueKey('demo-replay-step')));
    await tester.pumpAndSettle();
    expect(container.read(demoReplayProvider), 1);
    expect(container.read(candleProvider).last.close, isNot(original));
    await tester.tap(find.byKey(const ValueKey('demo-replay-toggle')));
    await tester.pump(const Duration(seconds: 3));
    expect(container.read(demoReplayProvider), 4);
    await tester.tap(find.byKey(const ValueKey('demo-replay-toggle')));
    await tester.pumpAndSettle();
    expect(container.read(demoReplayPlayingProvider), isFalse);
    await tester.tap(find.byKey(const ValueKey('demo-replay-reset')));
    await tester.pumpAndSettle();
    expect(container.read(candleProvider).last.close, original);
    await tester.binding.setSurfaceSize(const Size(640, 900));
    await tester.pumpAndSettle();
    expect(tester.takeException(), isNull);
    await tester.pumpWidget(const SizedBox());
    await tester.pumpAndSettle();
  });

  testWidgets(
      'watchlist selection updates the header and actual candle painter',
      (tester) async {
    await tester.binding.setSurfaceSize(const Size(1280, 900));
    addTearDown(() => tester.binding.setSurfaceSize(null));
    final preferences = await store();
    await preferences.saveMultiLayout(ChartMultiLayout.one);
    await launch(tester, preferences);
    final container =
        ProviderScope.containerOf(tester.element(find.byType(ChartPanel)));
    for (final symbol in ['DEMO003', 'DEMO002', 'DEMO001']) {
      await tester.tap(find.byKey(ValueKey('demo-watch-$symbol')));
      await tester.pumpAndSettle();
      final expected =
          DemoMarketData.candles(symbol, ChartTimeframe.minute).last.close;
      expect(container.read(selectedStockProvider).symbol, symbol);
      expect(container.read(selectedStockProvider).displayPrice, expected);
      final painters = tester
          .widgetList<CustomPaint>(find.byType(CustomPaint))
          .map((w) => w.painter)
          .whereType<CandleChartPainter>();
      expect(painters, isNotEmpty);
      expect(painters.first.candles.last.close, expected);
    }
    await tester.pumpWidget(const SizedBox());
    await tester.pumpAndSettle();
  });

  testWidgets('four-tile drawing stays per symbol during replay and reload',
      (tester) async {
    await tester.binding.setSurfaceSize(const Size(1280, 900));
    addTearDown(() => tester.binding.setSurfaceSize(null));
    final preferences = await store();
    await launch(tester, preferences);
    final tile = find.byKey(const ValueKey('multi-chart-tile-DEMO003'));
    Finder layer(String key) =>
        find.descendant(of: tile, matching: find.byKey(ValueKey(key)));
    CandleChartPainter painter() => tester
        .widgetList<CustomPaint>(
            find.descendant(of: tile, matching: find.byType(CustomPaint)))
        .map((widget) => widget.painter)
        .whereType<CandleChartPainter>()
        .single;
    await tester.tap(find.byKey(const ValueKey('multi-drawing-menu-DEMO003')));
    await tester.pumpAndSettle();
    await tester.tap(find.widgetWithText(CheckedPopupMenuItem<String>, '추세선'));
    await tester.pumpAndSettle();
    final rect = tester.getRect(layer('chart-drawing-input'));
    final start = rect.topLeft + Offset(rect.width * .3, rect.height * .7);
    final gesture =
        await tester.startGesture(start, kind: PointerDeviceKind.mouse);
    await gesture.moveTo(start + Offset(rect.width * .35, -rect.height * .35));
    await gesture.up();
    await tester.pumpAndSettle();
    final saved = preferences
        .loadDrawingAnnotations(
            symbol: 'DEMO003', timeframe: ChartTimeframe.minute)
        .single;
    expect(saved.anchored, isTrue);
    expect(
        preferences.loadDrawingAnnotations(
            symbol: 'DEMO001', timeframe: ChartTimeframe.minute),
        isEmpty);
    await tester.tap(find.byKey(const ValueKey('demo-replay-step')));
    await tester.pumpAndSettle();
    expect(painter().drawings, hasLength(1));
    await tester.tap(find.byTooltip('확대'));
    await tester.pumpAndSettle();
    await tester.pumpWidget(const SizedBox());
    await tester.pumpAndSettle();
    await launch(tester, preferences);
    expect(painter().drawings, hasLength(1));
    expect(
        preferences
            .loadDrawingAnnotations(
                symbol: 'DEMO003', timeframe: ChartTimeframe.minute)
            .single
            .endPrice,
        saved.endPrice);
    expect(tester.takeException(), isNull);
    await tester.pumpWidget(const SizedBox());
    await tester.pumpAndSettle();
  });
}
