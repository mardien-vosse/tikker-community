import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:tikker/features/chart/chart_state.dart';
import 'package:tikker/features/chart/chart_viewport.dart';
import 'package:tikker/features/demo/demo_providers.dart';
import 'package:tikker/providers/app_preferences.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  test(
      'private and QA preferences including drawings and viewports never overlap',
      () async {
    SharedPreferences.setMockInitialValues({});
    final private = await SharedPreferencesAppPreferencesStore.create();
    final demo = await SharedPreferencesAppPreferencesStore.create(
        namespace: demoPreferencesNamespace);
    await private.saveSelectedSymbol('005930');
    await demo.saveSelectedSymbol('DEMO001');
    await private.saveMultiLayout(ChartMultiLayout.one);
    await demo.saveMultiLayout(ChartMultiLayout.fourGrid);
    await demo.saveWatchlistSymbols(['DEMO004', 'DEMO001']);
    await demo.saveMultiSymbols(['DEMO004', 'DEMO001']);
    await demo.saveComparisonEnabled(true);
    await demo.saveComparisonSymbols({'DEMO004'});
    await demo.saveDrawingAnnotations(
        symbol: 'DEMO001',
        timeframe: ChartTimeframe.day,
        drawings: const [
          ChartDrawingAnnotation(
              tool: ChartDrawingTool.horizontal,
              startX: .2,
              startY: .3,
              endX: .8,
              endY: .3,
              startTime: '2025-01-06T09:00:00Z',
              endTime: '2025-01-06T10:00:00Z',
              startPrice: 1000,
              endPrice: 1000)
        ]);
    await demo.saveChartViewport(
        symbol: 'DEMO001',
        timeframe: ChartTimeframe.day,
        viewport:
            const ChartViewport(capacity: 40, endTime: '2025-01-06T09:00:00Z'));
    final reopened = await SharedPreferencesAppPreferencesStore.create(
        namespace: demoPreferencesNamespace);
    expect(private.load().selectedSymbol, '005930');
    expect(private.load().multiLayout, ChartMultiLayout.one);
    expect(reopened.load().selectedSymbol, 'DEMO001');
    expect(reopened.load().multiLayout, ChartMultiLayout.fourGrid);
    expect(reopened.load().watchlistSymbols, ['DEMO004', 'DEMO001']);
    expect(reopened.load().multiSymbols, ['DEMO004', 'DEMO001']);
    expect(reopened.load().comparisonSymbols, {'DEMO004'});
    expect(reopened.load().comparisonEnabled, isTrue);
    expect(
        reopened
            .loadDrawingAnnotations(
                symbol: 'DEMO001', timeframe: ChartTimeframe.day)
            .single
            .endPrice,
        1000);
    expect(
        private.loadDrawingAnnotations(
            symbol: 'DEMO001', timeframe: ChartTimeframe.day),
        isEmpty);
    expect(
        reopened
            .loadChartViewport(symbol: 'DEMO001', timeframe: ChartTimeframe.day)
            .capacity,
        40);
    expect(
        private
            .loadChartViewport(symbol: 'DEMO001', timeframe: ChartTimeframe.day)
            .capacity,
        isNot(40));
  });
}
