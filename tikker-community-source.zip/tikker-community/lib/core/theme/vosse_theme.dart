import 'package:flutter/material.dart';

class VosseColors {
  static const bgApp = Color(0xFF0D0E12);
  static const bgPanel = Color(0xFF14161C);
  static const bgSecondary = Color(0xFF151820);
  static const bgElevated = Color(0xFF1B1E26);
  static const border = Color(0xFF262A33);
  static const borderSubtle = Color(0xFF1F232B);
  static const textPrimary = Color(0xFFE6E8EC);
  static const textSecondary = Color(0xFFA4ABB8);
  static const textMuted = Color(0xFF8A8F9C);
  static const up = Color(0xFFF23645);
  static const down = Color(0xFF2962FF);
  static const accent = Color(0xFF00C4B4);
  static const accentPurple = Color(0xFF7B61FF);
  static const warning = Color(0xFFFFB020);
  static const ma5 = Color(0xFF7B61FF);
  static const ma20 = Color(0xFFFACC15);
}

class VosseTheme {
  static ThemeData dark() {
    const scheme = ColorScheme.dark(
      surface: VosseColors.bgApp,
      primary: VosseColors.accent,
      error: VosseColors.up,
    );
    return ThemeData(
      brightness: Brightness.dark,
      colorScheme: scheme,
      scaffoldBackgroundColor: VosseColors.bgApp,
      fontFamily: 'NotoSansKR',
      useMaterial3: true,
      textTheme: const TextTheme(
        titleLarge: TextStyle(
          color: VosseColors.textPrimary,
          fontWeight: FontWeight.w800,
          fontSize: 20,
        ),
        titleMedium: TextStyle(
          color: VosseColors.textPrimary,
          fontWeight: FontWeight.w800,
          fontSize: 16,
        ),
        bodyMedium: TextStyle(color: VosseColors.textSecondary, fontSize: 13),
        labelMedium: TextStyle(
          color: VosseColors.textMuted,
          fontSize: 12,
          fontWeight: FontWeight.w700,
        ),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Color(0xFF08090C),
        foregroundColor: VosseColors.textPrimary,
        elevation: 0,
        centerTitle: false,
      ),
      dividerTheme: const DividerThemeData(
        color: VosseColors.border,
        thickness: 1,
        space: 1,
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: VosseColors.bgPanel,
        indicatorColor: VosseColors.bgElevated,
        labelTextStyle: WidgetStateProperty.resolveWith(
          (_) => const TextStyle(fontSize: 11, fontWeight: FontWeight.w700),
        ),
      ),
    );
  }
}
