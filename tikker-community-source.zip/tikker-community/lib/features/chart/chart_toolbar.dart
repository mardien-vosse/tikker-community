import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/vosse_theme.dart';
import '../../providers/market_providers.dart';
import '../../shared/models/market_models.dart';
import '../../shared/models/market_data_source.dart';
import '../../shared/widgets/menu_help.dart';
import 'chart_state.dart';
import 'drawing_editor.dart';

class VosseChartToolbar extends ConsumerWidget {
  const VosseChartToolbar({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final drawingEnabled = ref.watch(chartDrawingEnabledProvider);
    final drawingTool = ref.watch(chartDrawingToolProvider);
    final comparisonEnabled = ref.watch(chartComparisonEnabledProvider);
    final indicators = ref.watch(chartIndicatorVisibilityProvider);
    final renderMode = ref.watch(chartRenderModeProvider);
    final timeframe = ref.watch(chartTimeframeProvider);
    final multiLayout = ref.watch(chartMultiLayoutProvider);
    final watchlist = ref.watch(displayWatchlistProvider);
    final selectedSymbol = ref.watch(selectedSymbolProvider);
    final comparisonSymbols = ref
        .watch(chartComparisonSymbolsProvider)
        .where((symbol) => symbol != selectedSymbol)
        .toSet();
    final comparisonLabel = _comparisonLabel(watchlist, comparisonSymbols);
    return LayoutBuilder(
      builder: (context, constraints) {
        final showSegmented = constraints.maxWidth >= 900;
        final showStateSummary = constraints.maxWidth >= 1040;
        return Container(
          height: 38,
          padding: const EdgeInsets.symmetric(horizontal: 10),
          decoration: const BoxDecoration(
            color: Color(0xFF0B0C10),
            border: Border(bottom: BorderSide(color: VosseColors.border)),
          ),
          child: Row(
            children: [
              Expanded(
                // Why: the resizable center pane can become narrower than the
                // full trading toolbar; horizontal scroll keeps every control
                // reachable instead of letting fixed chips overflow.
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      MenuHelp(
                        title: '그리기',
                        description: '추세선, 수평선, 피보나치 되돌림을 차트 위에 직접 표시합니다.',
                        child: _SelectChip(
                          label: drawingEnabled ? drawingTool.label : '그리기',
                          active: drawingEnabled,
                          tooltip: '그리기 도구 선택',
                          onTap: () => _openDrawingSheet(context, ref),
                        ),
                      ),
                      const SizedBox(width: 5),
                      MenuHelp(
                        title: '비교',
                        description: '현재 차트 위에 관심 종목의 가격 흐름을 함께 겹쳐 봅니다.',
                        child: _SelectChip(
                          label:
                              comparisonEnabled && comparisonSymbols.isNotEmpty
                                  ? comparisonLabel
                                  : '비교',
                          active:
                              comparisonEnabled && comparisonSymbols.isNotEmpty,
                          tooltip: '비교 종목 선택',
                          onTap: () => _openComparisonSheet(
                            context,
                            ref,
                            watchlist,
                            selectedSymbol,
                          ),
                        ),
                      ),
                      const SizedBox(width: 5),
                      MenuHelp(
                        title: '보조지표',
                        description: 'SMA, 볼린저 밴드, RSI, MACD를 한 번에 켜거나 끕니다.',
                        child: _ToggleChip(
                          label: '보조지표',
                          active: indicators.isNotEmpty,
                          onTap: () {
                            final allSelected = indicators.length ==
                                ChartIndicator.values.length;
                            toggleAllChartIndicators(ref);
                            _showToolbarFeedback(
                              context,
                              allSelected ? '보조지표를 모두 껐습니다.' : '보조지표를 모두 켰습니다.',
                            );
                          },
                        ),
                      ),
                      for (final indicator in ChartIndicator.values)
                        MenuHelp(
                          title: indicator.label,
                          description: _indicatorHelp(indicator),
                          child: _ToggleChip(
                            label: indicator.label,
                            active: indicators.contains(indicator),
                            onTap: () {
                              final wasSelected =
                                  indicators.contains(indicator);
                              toggleChartIndicator(ref, indicator);
                              _showToolbarFeedback(
                                context,
                                wasSelected
                                    ? '${indicator.label} 지표를 껐습니다.'
                                    : '${indicator.label} 지표를 켰습니다.',
                              );
                            },
                          ),
                        ),
                      if (showSegmented) ...[
                        const SizedBox(width: 6),
                        _Segmented(
                          renderMode: renderMode,
                          onSelected: (mode) {
                            final alreadySelected = mode == renderMode;
                            if (alreadySelected) {
                              _showToolbarFeedback(
                                context,
                                '${mode.label} 차트 이미 표시 중입니다.',
                              );
                              return;
                            }
                            ref.read(chartRenderModeProvider.notifier).state =
                                mode;
                            _showToolbarFeedback(
                              context,
                              '${mode.label} 차트로 변경했습니다.',
                            );
                          },
                        ),
                      ],
                      const SizedBox(width: 6),
                      _MultiChartButton(
                        selected: multiLayout,
                        onSelected: (layout) {
                          if (layout == multiLayout) {
                            _showToolbarFeedback(
                              context,
                              layout.isSingle
                                  ? '단일 차트 이미 표시 중입니다.'
                                  : '${layout.label} 멀티차트 이미 표시 중입니다.',
                            );
                            return;
                          }
                          ref.read(chartMultiLayoutProvider.notifier).state =
                              layout;
                          _showToolbarFeedback(
                            context,
                            layout.isSingle
                                ? '단일 차트로 변경했습니다.'
                                : '${layout.tileCount}개 멀티차트로 변경했습니다.',
                          );
                        },
                      ),
                      const SizedBox(width: 6),
                      _Timeframes(
                        active: timeframe,
                        onSelected: (item) {
                          if (item == timeframe) {
                            _showToolbarFeedback(
                              context,
                              '${item.title} 이미 표시 중입니다.',
                            );
                            return;
                          }
                          ref.read(chartTimeframeProvider.notifier).state =
                              item;
                          _showToolbarFeedback(
                            context,
                            '${item.title}으로 변경했습니다.',
                          );
                        },
                      ),
                      const SizedBox(width: 4),
                      _TimeframeMetaPill(timeframe: timeframe),
                    ],
                  ),
                ),
              ),
              if (showStateSummary) ...[
                const SizedBox(width: 6),
                _ToolbarSelectionSummary(
                  timeframe: timeframe,
                  renderMode: renderMode,
                  indicators: indicators,
                ),
              ],
              // Why: when the center pane is resized narrow, hidden inline
              // controls still need one reachable path through the settings sheet.
              MenuHelp(
                title: '차트 설정',
                description: '숨겨진 시간 주기, 차트 유형, 거래량, 보조지표를 한곳에서 조정합니다.',
                placement: MenuHelpPlacement.left,
                child: IconButton(
                  tooltip: '차트 설정',
                  onPressed: () => _openSettingsSheet(context, ref),
                  visualDensity: VisualDensity.compact,
                  constraints:
                      const BoxConstraints.tightFor(width: 32, height: 32),
                  padding: EdgeInsets.zero,
                  icon: const Icon(Icons.settings_outlined, size: 17),
                  color: VosseColors.textMuted,
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  String _stockLabel(List<MarketStock> watchlist, String symbol) {
    for (final stock in watchlist) {
      if (stock.symbol == symbol) return stock.name;
    }
    return symbol;
  }

  String _comparisonLabel(List<MarketStock> watchlist, Set<String> symbols) {
    if (symbols.length == 1) {
      return '비교 ${_stockLabel(watchlist, symbols.first)}';
    }
    return '비교 ${symbols.length}종목';
  }

  String _indicatorHelp(ChartIndicator indicator) {
    return switch (indicator) {
      ChartIndicator.ema => '기간 내 종가를 같은 비중으로 평균한 단순이동평균선입니다.',
      ChartIndicator.bollinger => '평균선 주변 변동성 범위를 표시해 과열과 이탈 구간을 봅니다.',
      ChartIndicator.rsi => '상승/하락 강도를 0~100으로 보여 과매수·과매도 구간을 봅니다.',
      ChartIndicator.macd => '두 이동평균의 차이로 추세 전환과 모멘텀 변화를 봅니다.',
    };
  }

  void _openDrawingSheet(BuildContext context, WidgetRef ref) {
    final rootContext = context;
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: VosseColors.bgPanel,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(8)),
      ),
      builder: (context) {
        return Consumer(
          builder: (context, ref, _) {
            final selected = ref.watch(chartDrawingToolProvider);
            final drawingCount =
                ref.watch(chartDrawingAnnotationsProvider).length;
            final selectedDrawingIndex =
                ref.watch(chartSelectedDrawingIndexProvider);
            return SafeArea(
              child: _ToolbarSheet(
                title: '그리기 도구',
                children: [
                  _SheetOption(
                    title: '자석 · OHLC 맞춤',
                    subtitle: '가까운 봉의 시가·고가·저가·종가에 끝점을 맞춥니다.',
                    selected: ref.watch(chartDrawingSnapProvider),
                    onTap: () => ref
                        .read(chartDrawingSnapProvider.notifier)
                        .state = !ref.read(chartDrawingSnapProvider),
                  ),
                  if (selectedDrawingIndex != null)
                    _SheetOption(
                      title: '선 속성 편집',
                      subtitle: '가격·날짜·색상·두께·잠금을 설정합니다.',
                      selected: false,
                      onTap: () {
                        Navigator.of(context).pop();
                        showDrawingEditor(
                            rootContext, ref, selectedDrawingIndex);
                      },
                    ),
                  if (selectedDrawingIndex != null)
                    _SheetOption(
                      title: '선택한 드로잉 삭제',
                      subtitle: '${selectedDrawingIndex + 1}번 드로잉만 제거합니다.',
                      selected: true,
                      onTap: () {
                        removeSelectedChartDrawing(ref);
                        Navigator.of(context).pop();
                        _showToolbarFeedback(rootContext, '선택한 드로잉을 삭제했습니다.');
                      },
                    ),
                  if (selectedDrawingIndex != null)
                    _SheetOption(
                      title: '선택 해제',
                      subtitle: '선택 강조만 해제하고 드로잉은 유지합니다.',
                      selected: false,
                      onTap: () {
                        selectChartDrawing(ref, null);
                        Navigator.of(context).pop();
                        _showToolbarFeedback(rootContext, '드로잉 선택을 해제했습니다.');
                      },
                    ),
                  if (drawingCount > 0)
                    _SheetOption(
                      title: '그리기 전체 삭제',
                      subtitle: '$drawingCount개 드로잉을 차트에서 제거합니다.',
                      selected: false,
                      onTap: () {
                        clearChartDrawings(ref);
                        Navigator.of(context).pop();
                        _showToolbarFeedback(
                          rootContext,
                          '드로잉 $drawingCount개를 모두 삭제했습니다.',
                        );
                      },
                    ),
                  for (var i = 0; i < drawingCount; i++)
                    _SheetOption(
                      title:
                          '${i + 1}. ${ref.watch(chartDrawingAnnotationsProvider)[i].label.isEmpty ? ref.watch(chartDrawingAnnotationsProvider)[i].tool.label : ref.watch(chartDrawingAnnotationsProvider)[i].label}',
                      subtitle:
                          ref.watch(chartDrawingAnnotationsProvider)[i].hidden
                              ? '숨김 · 선택하여 다시 표시'
                              : '선택하여 속성 편집',
                      selected: selectedDrawingIndex == i,
                      onTap: () {
                        selectChartDrawing(ref, i);
                        ref.read(chartDrawingEnabledProvider.notifier).state =
                            false;
                        Navigator.of(context).pop();
                      },
                    ),
                  for (final tool in ChartDrawingTool.values)
                    _SheetOption(
                      title: tool.label,
                      subtitle: switch (tool) {
                        ChartDrawingTool.none => '새 드로잉 입력을 멈춥니다.',
                        ChartDrawingTool.trend => '차트 위에 직접 추세선을 그립니다.',
                        ChartDrawingTool.horizontal => '차트 위에 직접 수평선을 그립니다.',
                        ChartDrawingTool.fibonacci => '차트 위에 직접 되돌림 구간을 그립니다.',
                        ChartDrawingTool.vertical => '특정 날짜와 시각을 표시합니다.',
                        ChartDrawingTool.rectangle => '드래그하여 관심 가격 구간을 표시합니다.',
                        ChartDrawingTool.range => '두 점 사이 가격 변화와 봉 수를 측정합니다.',
                        ChartDrawingTool.text => '클릭하여 메모를 놓고 속성에서 내용을 편집합니다.',
                        ChartDrawingTool.channel => '드래그하여 평행한 가격 채널을 그립니다.',
                      },
                      selected: selected == tool,
                      onTap: () {
                        if (selected == tool) {
                          _showToolbarFeedback(
                            rootContext,
                            tool == ChartDrawingTool.none
                                ? '그리기 도구가 이미 꺼져 있습니다.'
                                : '${tool.label} 그리기 도구 이미 선택 중입니다.',
                          );
                          return;
                        }
                        // Why: users need to pause capture without losing saved drawings.
                        ref.read(chartDrawingToolProvider.notifier).state =
                            tool;
                        ref.read(chartDrawingEnabledProvider.notifier).state =
                            tool != ChartDrawingTool.none;
                        Navigator.of(context).pop();
                        _showToolbarFeedback(
                          rootContext,
                          tool == ChartDrawingTool.none
                              ? '그리기 도구를 껐습니다.'
                              : '${tool.label} 그리기 도구가 켜졌습니다.',
                        );
                      },
                    ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  void _openComparisonSheet(
    BuildContext context,
    WidgetRef ref,
    List<MarketStock> watchlist,
    String selectedSymbol,
  ) {
    final rootContext = context;
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: VosseColors.bgPanel,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(8)),
      ),
      builder: (context) {
        return Consumer(
          builder: (context, ref, _) {
            final enabled = ref.watch(chartComparisonEnabledProvider);
            final comparisonSymbols = ref
                .watch(chartComparisonSymbolsProvider)
                .where((symbol) => symbol != selectedSymbol)
                .toSet();
            final hiddenSymbols =
                ref.watch(chartHiddenComparisonSymbolsProvider);
            final candidates =
                watchlist.where((stock) => stock.symbol != selectedSymbol);
            return SafeArea(
              child: _ToolbarSheet(
                title: '비교 종목',
                children: [
                  _SheetOption(
                    title: '비교 끄기',
                    subtitle: comparisonSymbols.isEmpty
                        ? '비교선이 선택되지 않았습니다.'
                        : '${comparisonSymbols.length}개 비교선을 차트에서 숨깁니다.',
                    selected: !enabled || comparisonSymbols.isEmpty,
                    onTap: () {
                      if (!enabled || comparisonSymbols.isEmpty) {
                        _showToolbarFeedback(
                          rootContext,
                          '비교선이 이미 꺼져 있습니다.',
                        );
                        return;
                      }
                      clearComparisonSymbols(ref);
                      Navigator.of(context).pop();
                      _showToolbarFeedback(rootContext, '비교선을 모두 껐습니다.');
                    },
                  ),
                  const _SheetSectionTitle('비교할 종목'),
                  for (final stock in candidates)
                    _SheetOption(
                      title: stock.name,
                      subtitle: [
                        '${stock.market} ${stock.symbol}',
                        if (comparisonSymbols.contains(stock.symbol))
                          hiddenSymbols.contains(stock.symbol) ? '숨김' : '표시 중',
                      ].join(' · '),
                      selected:
                          enabled && comparisonSymbols.contains(stock.symbol),
                      onTap: () {
                        final wasSelected =
                            enabled && comparisonSymbols.contains(stock.symbol);
                        toggleComparisonSymbol(ref, stock.symbol);
                        _showToolbarFeedback(
                          rootContext,
                          wasSelected
                              ? '${stock.name} 비교선을 해제했습니다.'
                              : '${stock.name} 비교선을 추가했습니다.',
                        );
                      },
                    ),
                  const Padding(
                    padding: EdgeInsets.only(top: 4, bottom: 10),
                    child: Text(
                      '차트 위 비교 label을 누르면 해당 비교선만 숨기거나 다시 표시할 수 있습니다.',
                      style: TextStyle(
                        color: VosseColors.textMuted,
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      onPressed: () => Navigator.of(context).pop(),
                      style: FilledButton.styleFrom(
                        backgroundColor: VosseColors.accent,
                        foregroundColor: const Color(0xFF041D1A),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(6),
                        ),
                      ),
                      child: const Text(
                        '완료',
                        style: TextStyle(fontWeight: FontWeight.w900),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  void _showToolbarFeedback(BuildContext context, String message) {
    final messenger = ScaffoldMessenger.maybeOf(context);
    if (messenger == null) return;
    messenger
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(message),
          duration: const Duration(milliseconds: 1400),
        ),
      );
  }

  void _openSettingsSheet(BuildContext context, WidgetRef ref) {
    final rootContext = context;
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: VosseColors.bgPanel,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(8)),
      ),
      builder: (context) {
        return Consumer(
          builder: (context, ref, _) {
            final volumeVisible = ref.watch(chartVolumeVisibleProvider);
            final renderMode = ref.watch(chartRenderModeProvider);
            final timeframe = ref.watch(chartTimeframeProvider);
            final indicators = ref.watch(chartIndicatorVisibilityProvider);
            return SafeArea(
              child: _ToolbarSheet(
                title: '차트 설정',
                children: [
                  const _SheetSectionTitle('차트 유형'),
                  _SheetWrap(
                    children: [
                      for (final mode in ChartRenderMode.values)
                        _SheetChip(
                          label: mode.label,
                          helpDescription: _renderModeHelp(mode),
                          selected: renderMode == mode,
                          onTap: () {
                            if (mode == renderMode) {
                              _showToolbarFeedback(
                                rootContext,
                                '${mode.label} 차트 이미 표시 중입니다.',
                              );
                              return;
                            }
                            ref.read(chartRenderModeProvider.notifier).state =
                                mode;
                            _showToolbarFeedback(
                              rootContext,
                              '${mode.label} 차트로 변경했습니다.',
                            );
                          },
                        ),
                    ],
                  ),
                  const _SheetSectionTitle('기간'),
                  _SheetWrap(
                    children: [
                      for (final item in ChartTimeframe.values)
                        _SheetChip(
                          label: item.title,
                          helpDescription: _timeframeHelp(item,
                              generated:
                                  ref.watch(selectedCandleSourceProvider) ==
                                      MarketDataSource.generated),
                          selected: timeframe == item,
                          onTap: () {
                            if (item == timeframe) {
                              _showToolbarFeedback(
                                rootContext,
                                '${item.title} 이미 표시 중입니다.',
                              );
                              return;
                            }
                            ref.read(chartTimeframeProvider.notifier).state =
                                item;
                            _showToolbarFeedback(
                              rootContext,
                              '${item.title}으로 변경했습니다.',
                            );
                          },
                        ),
                    ],
                  ),
                  const _SheetSectionTitle('표시'),
                  MenuHelp(
                    title: '거래량 표시',
                    description:
                        '캔들 아래 거래량 막대를 켜거나 끕니다. 단타에서는 가격 움직임과 거래량 증가를 함께 봅니다.',
                    placement: MenuHelpPlacement.above,
                    child: SwitchListTile.adaptive(
                      value: volumeVisible,
                      onChanged: (value) {
                        ref.read(chartVolumeVisibleProvider.notifier).state =
                            value;
                        _showToolbarFeedback(
                          rootContext,
                          value ? '거래량 막대를 켰습니다.' : '거래량 막대를 껐습니다.',
                        );
                      },
                      title: const Text('거래량 표시'),
                      dense: true,
                      contentPadding: EdgeInsets.zero,
                    ),
                  ),
                  const _SheetSectionTitle('보조지표'),
                  _SheetWrap(
                    children: [
                      for (final indicator in ChartIndicator.values)
                        _SheetChip(
                          label: indicator.label,
                          helpDescription: _indicatorHelp(indicator),
                          selected: indicators.contains(indicator),
                          onTap: () {
                            final wasSelected = indicators.contains(indicator);
                            toggleChartIndicator(ref, indicator);
                            _showToolbarFeedback(
                              rootContext,
                              wasSelected
                                  ? '${indicator.label} 지표를 껐습니다.'
                                  : '${indicator.label} 지표를 켰습니다.',
                            );
                          },
                        ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      onPressed: () {
                        Navigator.of(context).pop();
                        _showToolbarFeedback(rootContext, '차트 설정을 적용했습니다.');
                      },
                      style: FilledButton.styleFrom(
                        backgroundColor: VosseColors.accent,
                        foregroundColor: const Color(0xFF041D1A),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(6),
                        ),
                      ),
                      child: const Text(
                        '완료',
                        style: TextStyle(fontWeight: FontWeight.w900),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}

class _ToolbarSelectionSummary extends StatelessWidget {
  const _ToolbarSelectionSummary({
    required this.timeframe,
    required this.renderMode,
    required this.indicators,
  });

  final ChartTimeframe timeframe;
  final ChartRenderMode renderMode;
  final Set<ChartIndicator> indicators;

  @override
  Widget build(BuildContext context) {
    final indicatorLabel = _indicatorSummaryLabel(indicators);
    return MenuHelp(
      title: '현재 차트 선택',
      description:
          '${timeframe.title}, ${renderMode.label}, $indicatorLabel 상태입니다. 툴바를 좌우로 스크롤해도 현재 선택값은 이 요약 칩에서 확인합니다.',
      placement: MenuHelpPlacement.below,
      child: Container(
        height: 26,
        constraints: const BoxConstraints(maxWidth: 180),
        padding: const EdgeInsets.symmetric(horizontal: 8),
        decoration: BoxDecoration(
          color: VosseColors.bgElevated,
          border: Border.all(color: VosseColors.border),
          borderRadius: BorderRadius.circular(5),
        ),
        child: Center(
          child: Text(
            '${timeframe.title} · ${renderMode.label} · $indicatorLabel',
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: VosseColors.textSecondary,
              fontSize: 10,
              fontWeight: FontWeight.w900,
            ),
          ),
        ),
      ),
    );
  }
}

class _SelectChip extends StatelessWidget {
  const _SelectChip({
    required this.label,
    required this.active,
    required this.tooltip,
    required this.onTap,
  });

  final String label;
  final bool active;
  final String tooltip;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: tooltip,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(6),
        child: Container(
          height: 28,
          padding: const EdgeInsets.symmetric(horizontal: 9),
          decoration: BoxDecoration(
            color: active
                ? VosseColors.accent.withValues(alpha: .14)
                : VosseColors.bgApp,
            border: Border.all(
              color: active ? VosseColors.accent : VosseColors.border,
            ),
            borderRadius: BorderRadius.circular(6),
          ),
          child: Center(
            child: Text(
              '$label⌄',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: active ? VosseColors.accent : VosseColors.textMuted,
                fontSize: 11,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _ToolbarSheet extends StatelessWidget {
  const _ToolbarSheet({required this.title, required this.children});

  final String title;
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 36,
            height: 4,
            margin: const EdgeInsets.only(bottom: 12),
            decoration: BoxDecoration(
              color: VosseColors.border,
              borderRadius: BorderRadius.circular(999),
            ),
          ),
          Text(
            title,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 10),
          ...children,
        ],
      ),
    );
  }
}

class _SheetOption extends StatelessWidget {
  const _SheetOption({
    required this.title,
    required this.subtitle,
    required this.selected,
    required this.onTap,
  });

  final String title;
  final String subtitle;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return MenuHelp(
      title: title,
      description: subtitle,
      placement: MenuHelpPlacement.above,
      child: ListTile(
        onTap: onTap,
        dense: true,
        contentPadding: EdgeInsets.zero,
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
        subtitle: Text(
          subtitle,
          style: const TextStyle(
            color: VosseColors.textMuted,
            fontSize: 12,
            fontWeight: FontWeight.w700,
          ),
        ),
        trailing: selected
            ? const Icon(Icons.check_circle_rounded, color: VosseColors.accent)
            : const Icon(Icons.circle_outlined, color: VosseColors.textMuted),
      ),
    );
  }
}

class _SheetSectionTitle extends StatelessWidget {
  const _SheetSectionTitle(this.label);

  final String label;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 12, bottom: 8),
      child: Text(
        label,
        style: const TextStyle(
          color: VosseColors.textMuted,
          fontSize: 12,
          fontWeight: FontWeight.w900,
        ),
      ),
    );
  }
}

class _SheetWrap extends StatelessWidget {
  const _SheetWrap({required this.children});

  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return Wrap(spacing: 6, runSpacing: 6, children: children);
  }
}

class _SheetChip extends StatelessWidget {
  const _SheetChip({
    required this.label,
    required this.helpDescription,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final String helpDescription;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return MenuHelp(
      title: label,
      description: helpDescription,
      placement: MenuHelpPlacement.above,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(6),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          decoration: BoxDecoration(
            color: selected
                ? VosseColors.accent.withValues(alpha: .14)
                : VosseColors.bgElevated,
            border: Border.all(
              color: selected ? VosseColors.accent : VosseColors.border,
            ),
            borderRadius: BorderRadius.circular(6),
          ),
          child: Text(
            label,
            style: TextStyle(
              color: selected ? VosseColors.accent : VosseColors.textMuted,
              fontSize: 12,
              fontWeight: FontWeight.w900,
            ),
          ),
        ),
      ),
    );
  }
}

class _ToggleChip extends StatelessWidget {
  const _ToggleChip({
    required this.label,
    required this.onTap,
    this.active = false,
  });

  final String label;
  final VoidCallback onTap;
  final bool active;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(6),
        child: Container(
          margin: const EdgeInsets.only(right: 4),
          padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
          decoration: BoxDecoration(
            color: active
                ? VosseColors.up.withValues(alpha: .15)
                : Colors.transparent,
            borderRadius: BorderRadius.circular(6),
          ),
          child: Text(
            label,
            style: TextStyle(
              color: active ? VosseColors.up : VosseColors.textMuted,
              fontSize: 11,
              fontWeight: FontWeight.w900,
            ),
          ),
        ),
      ),
    );
  }
}

class _Segmented extends StatelessWidget {
  const _Segmented({
    required this.renderMode,
    required this.onSelected,
  });

  final ChartRenderMode renderMode;
  final ValueChanged<ChartRenderMode> onSelected;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 28,
      padding: const EdgeInsets.all(2),
      decoration: BoxDecoration(
          border: Border.all(color: VosseColors.border),
          borderRadius: BorderRadius.circular(7)),
      child: Row(
        children: [
          for (final mode in ChartRenderMode.values)
            _Segment(
              label: mode.label,
              helpDescription: _renderModeHelp(mode),
              active: renderMode == mode,
              onTap: () => onSelected(mode),
            ),
        ],
      ),
    );
  }
}

class _Segment extends StatelessWidget {
  const _Segment({
    required this.label,
    required this.helpDescription,
    required this.onTap,
    this.active = false,
  });

  final String label;
  final String helpDescription;
  final VoidCallback onTap;
  final bool active;

  @override
  Widget build(BuildContext context) {
    return MenuHelp(
      title: label,
      description: helpDescription,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(5),
        child: Container(
          height: 24,
          padding: const EdgeInsets.symmetric(horizontal: 8),
          decoration: BoxDecoration(
              color: active ? VosseColors.bgElevated : null,
              borderRadius: BorderRadius.circular(5)),
          child: Center(
              child: Text(label,
                  style: TextStyle(
                      color: active
                          ? VosseColors.textPrimary
                          : VosseColors.textMuted,
                      fontSize: 11,
                      fontWeight: FontWeight.w900))),
        ),
      ),
    );
  }
}

class _MultiChartButton extends StatelessWidget {
  const _MultiChartButton({
    required this.selected,
    required this.onSelected,
  });

  final ChartMultiLayout selected;
  final ValueChanged<ChartMultiLayout> onSelected;

  @override
  Widget build(BuildContext context) {
    return MenuHelp(
      title: '멀티차트',
      description: selected.isSingle
          ? '차트 영역을 여러 칸으로 나눠 관심종목을 동시에 봅니다.'
          : '${selected.tileCount}개 칸으로 관심종목 차트를 동시에 보고 있습니다.',
      placement: MenuHelpPlacement.below,
      child: PopupMenuButton<ChartMultiLayout>(
        tooltip: '멀티차트',
        padding: EdgeInsets.zero,
        position: PopupMenuPosition.under,
        color: const Color(0xFF171717),
        surfaceTintColor: Colors.transparent,
        elevation: 10,
        constraints: const BoxConstraints(minWidth: 278, maxWidth: 302),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(2),
        ),
        onSelected: onSelected,
        itemBuilder: (context) {
          return [
            _MultiLayoutMenuHeaderEntry(selected: selected),
            for (final group in _multiLayoutGroups)
              _MultiLayoutMenuGroupEntry(
                layouts: group,
                selected: selected,
              ),
          ];
        },
        child: Container(
          key: const ValueKey('multi-chart-button'),
          width: 32,
          height: 28,
          decoration: BoxDecoration(
            color: selected.isSingle
                ? Colors.transparent
                : VosseColors.up.withValues(alpha: .13),
            border: Border.all(
              color: selected.isSingle ? VosseColors.border : VosseColors.up,
            ),
            borderRadius: BorderRadius.circular(6),
          ),
          child: Stack(
            clipBehavior: Clip.none,
            children: [
              Center(
                child: CustomPaint(
                  size: const Size(18, 18),
                  painter: _MiniLayoutPainter(
                    layout: selected,
                    color: selected.isSingle
                        ? VosseColors.textMuted
                        : VosseColors.up,
                    strokeWidth: 1.8,
                  ),
                ),
              ),
              if (!selected.isSingle)
                Positioned(
                  right: -4,
                  top: -5,
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      color: VosseColors.down,
                      borderRadius: BorderRadius.circular(999),
                      border: Border.all(color: const Color(0xFF0B0C10)),
                    ),
                    child: SizedBox(
                      width: 15,
                      height: 15,
                      child: Center(
                        child: Text(
                          selected.tileCount.toString(),
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 9,
                            fontWeight: FontWeight.w900,
                            height: 1,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _MultiLayoutMenuHeaderEntry extends PopupMenuEntry<ChartMultiLayout> {
  const _MultiLayoutMenuHeaderEntry({required this.selected});

  final ChartMultiLayout selected;

  @override
  double get height => 48;

  @override
  bool represents(ChartMultiLayout? value) => false;

  @override
  State<_MultiLayoutMenuHeaderEntry> createState() =>
      _MultiLayoutMenuHeaderEntryState();
}

class _MultiLayoutMenuHeaderEntryState
    extends State<_MultiLayoutMenuHeaderEntry> {
  @override
  Widget build(BuildContext context) {
    final selectedLabel = widget.selected.isSingle
        ? '현재 단일 차트'
        : '현재 ${widget.selected.tileCount}분할';
    return SizedBox(
      width: 292,
      height: widget.height,
      child: DecoratedBox(
        decoration: const BoxDecoration(
          color: Color(0xFF111217),
          border: Border(
            bottom: BorderSide(color: VosseColors.borderSubtle),
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Row(
            children: [
              CustomPaint(
                size: const Size(24, 24),
                painter: _MiniLayoutPainter(
                  layout: widget.selected,
                  color: widget.selected.isSingle
                      ? VosseColors.textMuted
                      : VosseColors.up,
                  strokeWidth: 2,
                ),
              ),
              const SizedBox(width: 10),
              const Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '멀티차트',
                      style: TextStyle(
                        color: VosseColors.textPrimary,
                        fontSize: 13,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    SizedBox(height: 2),
                    Text(
                      '관심종목을 여러 칸으로 동시에 봅니다.',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: VosseColors.textMuted,
                        fontSize: 10.5,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Text(
                selectedLabel,
                style: TextStyle(
                  color: widget.selected.isSingle
                      ? VosseColors.textMuted
                      : VosseColors.up,
                  fontSize: 11,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

const _multiLayoutGroups = <List<ChartMultiLayout>>[
  [ChartMultiLayout.one],
  [ChartMultiLayout.twoColumns, ChartMultiLayout.twoRows],
  [
    ChartMultiLayout.threeColumns,
    ChartMultiLayout.threeRows,
    ChartMultiLayout.threeGrid,
  ],
  [
    ChartMultiLayout.fourGrid,
    ChartMultiLayout.fourColumns,
    ChartMultiLayout.fourRows,
  ],
  [
    ChartMultiLayout.fiveGrid,
    ChartMultiLayout.fiveColumns,
    ChartMultiLayout.fiveRows,
  ],
  [
    ChartMultiLayout.sixGrid,
    ChartMultiLayout.sixColumns,
    ChartMultiLayout.sixRows,
  ],
  [
    ChartMultiLayout.sevenGrid,
    ChartMultiLayout.sevenColumns,
    ChartMultiLayout.sevenRows,
  ],
  [
    ChartMultiLayout.eightGrid,
    ChartMultiLayout.eightColumns,
    ChartMultiLayout.eightRows,
  ],
];

class _MultiLayoutMenuGroupEntry extends PopupMenuEntry<ChartMultiLayout> {
  const _MultiLayoutMenuGroupEntry({
    required this.layouts,
    required this.selected,
  });

  final List<ChartMultiLayout> layouts;
  final ChartMultiLayout selected;

  @override
  double get height => 46;

  @override
  bool represents(ChartMultiLayout? value) {
    return value != null && layouts.contains(value);
  }

  @override
  State<_MultiLayoutMenuGroupEntry> createState() =>
      _MultiLayoutMenuGroupEntryState();
}

class _MultiLayoutMenuGroupEntryState
    extends State<_MultiLayoutMenuGroupEntry> {
  @override
  Widget build(BuildContext context) {
    final tileCount = widget.layouts.first.tileCount;
    return SizedBox(
      width: 292,
      height: widget.height,
      child: DecoratedBox(
        decoration: const BoxDecoration(
          border: Border(
            bottom: BorderSide(color: VosseColors.borderSubtle),
          ),
        ),
        child: Row(
          children: [
            SizedBox(
              width: 32,
              child: Text(
                tileCount.toString(),
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: VosseColors.textMuted,
                  fontSize: 15,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
            Container(width: 1, color: VosseColors.borderSubtle),
            const SizedBox(width: 10),
            Expanded(
              child: Wrap(
                spacing: 8,
                runSpacing: 6,
                crossAxisAlignment: WrapCrossAlignment.center,
                children: [
                  for (final layout in widget.layouts)
                    _MultiLayoutOption(
                      layout: layout,
                      selected: layout == widget.selected,
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MultiLayoutOption extends StatelessWidget {
  const _MultiLayoutOption({
    required this.layout,
    required this.selected,
  });

  final ChartMultiLayout layout;
  final bool selected;

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: _layoutDescription(layout),
      waitDuration: const Duration(milliseconds: 250),
      child: Semantics(
        button: true,
        selected: selected,
        label: _layoutDescription(layout),
        child: InkWell(
          key: ValueKey('multi-layout-option-${layout.name}'),
          borderRadius: BorderRadius.circular(6),
          onTap: () => Navigator.of(context).pop(layout),
          child: Container(
            width: 30,
            height: 30,
            padding: const EdgeInsets.all(4),
            decoration: BoxDecoration(
              color: selected
                  ? VosseColors.up.withValues(alpha: .12)
                  : Colors.transparent,
              border: Border.all(
                color: selected ? VosseColors.up : Colors.transparent,
              ),
              borderRadius: BorderRadius.circular(6),
            ),
            child: CustomPaint(
              size: const Size(22, 22),
              painter: _MiniLayoutPainter(
                layout: layout,
                color: selected ? VosseColors.up : VosseColors.textPrimary,
                strokeWidth: 2.15,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

String _layoutDescription(ChartMultiLayout layout) {
  return layout.isSingle
      ? '단일 차트'
      : '${layout.rows}행 ${layout.columns}열 · ${layout.tileCount}종목';
}

class _MiniLayoutPainter extends CustomPainter {
  const _MiniLayoutPainter({
    required this.layout,
    required this.color,
    required this.strokeWidth,
  });

  final ChartMultiLayout layout;
  final Color color;
  final double strokeWidth;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..strokeWidth = strokeWidth;
    final rect = Rect.fromLTWH(1.5, 1.5, size.width - 3, size.height - 3);
    canvas.drawRRect(
      RRect.fromRectAndRadius(rect, const Radius.circular(3)),
      paint,
    );
    for (var column = 1; column < layout.columns; column += 1) {
      final x = rect.left + rect.width * column / layout.columns;
      canvas.drawLine(Offset(x, rect.top), Offset(x, rect.bottom), paint);
    }
    for (var row = 1; row < layout.rows; row += 1) {
      final y = rect.top + rect.height * row / layout.rows;
      canvas.drawLine(Offset(rect.left, y), Offset(rect.right, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant _MiniLayoutPainter oldDelegate) {
    return oldDelegate.layout != layout ||
        oldDelegate.color != color ||
        oldDelegate.strokeWidth != strokeWidth;
  }
}

class _Timeframes extends ConsumerWidget {
  const _Timeframes({
    required this.active,
    required this.onSelected,
  });

  final ChartTimeframe active;
  final ValueChanged<ChartTimeframe> onSelected;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final dailyTimeframes = _dailyTimeframes();
    return Row(
      children: [
        MenuHelp(
          title: '분봉',
          description: active.isIntraday
              ? _timeframeHelp(active,
                  generated: ref.watch(selectedCandleSourceProvider) ==
                      MarketDataSource.generated)
              : '1분, 3분, 5분, 10분, 15분, 30분, 1시간, 2시간, 4시간 분봉을 선택합니다.',
          child: PopupMenuButton<ChartTimeframe>(
            tooltip: '분봉 선택',
            padding: EdgeInsets.zero,
            position: PopupMenuPosition.under,
            color: const Color(0xFF17181D),
            surfaceTintColor: Colors.transparent,
            elevation: 8,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(2),
            ),
            onSelected: onSelected,
            itemBuilder: (context) {
              return [
                const PopupMenuItem<ChartTimeframe>(
                  enabled: false,
                  height: 42,
                  padding: EdgeInsets.symmetric(horizontal: 14),
                  child: Text(
                    '분봉',
                    style: TextStyle(
                      color: VosseColors.textMuted,
                      fontSize: 15,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
                const PopupMenuDivider(height: 1),
                for (final item in _intradayTimeframes())
                  PopupMenuItem<ChartTimeframe>(
                    value: item,
                    height: 42,
                    padding: EdgeInsets.zero,
                    child: _TimeframeMenuItem(
                      item: item,
                      selected: item == active,
                    ),
                  ),
              ];
            },
            child: _TimeframeButton(
              label: '분봉',
              active: active.isIntraday,
            ),
          ),
        ),
        const SizedBox(width: 2),
        for (final item in dailyTimeframes)
          MenuHelp(
            title: item.title,
            description: _timeframeHelp(item,
                generated: ref.watch(selectedCandleSourceProvider) ==
                    MarketDataSource.generated),
            child: _TimeframeButton(
              label: item.label,
              active: item == active,
              onTap: () => onSelected(item),
            ),
          ),
      ],
    );
  }
}

class _TimeframeButton extends StatelessWidget {
  const _TimeframeButton({
    required this.label,
    required this.active,
    this.onTap,
  });

  final String label;
  final bool active;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final child = Container(
      height: 26,
      margin: const EdgeInsets.only(left: 2),
      padding: const EdgeInsets.symmetric(horizontal: 7),
      decoration: BoxDecoration(
        color: active ? VosseColors.bgElevated : Colors.transparent,
        border: Border.all(
          color: active ? VosseColors.accent : Colors.transparent,
        ),
        borderRadius: BorderRadius.circular(5),
      ),
      child: Center(
        child: Text(
          label,
          style: TextStyle(
            color: active ? VosseColors.textPrimary : VosseColors.textMuted,
            fontSize: 11,
            fontWeight: FontWeight.w900,
          ),
        ),
      ),
    );
    if (onTap == null) return child;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(5),
      child: child,
    );
  }
}

class _TimeframeMenuItem extends StatelessWidget {
  const _TimeframeMenuItem({
    required this.item,
    required this.selected,
  });

  final ChartTimeframe item;
  final bool selected;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 148,
      height: 42,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: Row(
          children: [
            Expanded(
              child: Text(
                item.intradayMenuLabel,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: selected ? VosseColors.up : VosseColors.textPrimary,
                  fontSize: 16,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
            if (selected)
              const Icon(
                Icons.check_rounded,
                size: 20,
                color: VosseColors.up,
              ),
          ],
        ),
      ),
    );
  }
}

class _TimeframeMetaPill extends ConsumerWidget {
  const _TimeframeMetaPill({required this.timeframe});

  final ChartTimeframe timeframe;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return MenuHelp(
      title: '시간 주기 기준',
      description: _timeframeMetaHelp(timeframe,
          generated: ref.watch(selectedCandleSourceProvider) ==
              MarketDataSource.generated),
      placement: MenuHelpPlacement.below,
      child: Container(
        height: 24,
        padding: const EdgeInsets.symmetric(horizontal: 7),
        decoration: BoxDecoration(
          color: VosseColors.accent.withValues(alpha: .08),
          border: Border.all(color: VosseColors.accent.withValues(alpha: .24)),
          borderRadius: BorderRadius.circular(5),
        ),
        child: Center(
          child: Text(
            _timeframeMetaLabel(timeframe,
                generated: ref.watch(selectedCandleSourceProvider) ==
                    MarketDataSource.generated),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: VosseColors.accent,
              fontSize: 9.5,
              fontWeight: FontWeight.w900,
            ),
          ),
        ),
      ),
    );
  }
}

String _indicatorSummaryLabel(Set<ChartIndicator> indicators) {
  if (indicators.isEmpty) return '지표 없음';
  if (indicators.length == ChartIndicator.values.length) return '지표 전체';
  final ordered = ChartIndicator.values
      .where(indicators.contains)
      .map((indicator) => indicator.label)
      .join('/');
  return '지표 $ordered';
}

List<ChartTimeframe> _intradayTimeframes() {
  return const [
    ChartTimeframe.minute,
    ChartTimeframe.threeMinute,
    ChartTimeframe.fiveMinute,
    ChartTimeframe.tenMinute,
    ChartTimeframe.fifteenMinute,
    ChartTimeframe.thirtyMinute,
    ChartTimeframe.sixtyMinute,
    ChartTimeframe.twoHour,
    ChartTimeframe.fourHour,
  ];
}

List<ChartTimeframe> _dailyTimeframes() {
  return const [
    ChartTimeframe.day,
    ChartTimeframe.week,
    ChartTimeframe.month,
    ChartTimeframe.year,
  ];
}

String _timeframeMetaLabel(ChartTimeframe timeframe, {bool generated = false}) {
  if (generated) return '직접 생성 ${timeframe.title}';
  if (timeframe == ChartTimeframe.minute) return 'KIS 1분 캔들';
  if (timeframe.isIntraday) {
    return '1분→${timeframe.aggregationLabel} 집계';
  }
  return 'KIS ${timeframe.title} 조회';
}

String _timeframeMetaHelp(ChartTimeframe timeframe, {bool generated = false}) {
  if (generated) return '선택한 시간 간격으로 독립 생성한 가상 캔들입니다. 실제 시장 거래를 집계한 데이터가 아닙니다.';
  if (timeframe == ChartTimeframe.minute) {
    return 'KIS 체결/분봉 데이터를 앱 내부 1분 캔들로 갱신하는 기준입니다.';
  }
  if (timeframe.isIntraday) {
    return 'KIS 1분 원본 캔들을 앱에서 ${timeframe.aggregationLabel}봉으로 다시 묶어 표시합니다.';
  }
  return 'KIS REST 캔들 조회에서 ${timeframe.title} 기준으로 불러온 데이터를 표시합니다.';
}

String _renderModeHelp(ChartRenderMode mode) {
  return switch (mode) {
    ChartRenderMode.candle => '시가·고가·저가·종가를 봉 하나로 보여주는 기본 매매 차트입니다.',
    ChartRenderMode.line => '종가 흐름만 선으로 연결해 큰 방향성을 빠르게 확인합니다.',
    ChartRenderMode.area => '종가 흐름을 면으로 채워 추세의 강약을 더 크게 보여줍니다.',
  };
}

String _timeframeHelp(ChartTimeframe timeframe, {bool generated = false}) {
  if (generated) return '${timeframe.title} 간격의 가상 시계열로 그리기와 탐색을 검사합니다.';
  if (timeframe.isIntraday) {
    if (timeframe == ChartTimeframe.minute) {
      return 'KIS 체결 데이터를 1분 단위 캔들로 갱신합니다.';
    }
    return '1분 실시간 캔들을 ${timeframe.aggregationLabel} 단위로 묶어 표시합니다.';
  }
  return switch (timeframe) {
    ChartTimeframe.day => '하루를 봉 하나로 묶어 중기 흐름을 봅니다.',
    ChartTimeframe.week => '한 주를 봉 하나로 묶어 추세의 큰 방향을 봅니다.',
    ChartTimeframe.month => '한 달을 봉 하나로 묶어 장기 흐름을 봅니다.',
    ChartTimeframe.year => '1년 단위 큰 가격 범위를 확인합니다.',
    _ => timeframe.title,
  };
}
