import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/vosse_theme.dart';
import '../../providers/market_providers.dart';
import 'chart_state.dart';
import 'realtime_candle_builder.dart';

class DrawingSelectionToolbar extends ConsumerWidget {
  const DrawingSelectionToolbar({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final index = ref.watch(chartSelectedDrawingIndexProvider);
    final drawings = ref.watch(chartDrawingAnnotationsProvider);
    if (index == null || index >= drawings.length) {
      return const SizedBox.shrink();
    }
    final drawing = drawings[index];
    return Container(
      height: 38,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: const BoxDecoration(
          color: VosseColors.bgPanel,
          border: Border(bottom: BorderSide(color: VosseColors.border))),
      child: Row(children: [
        Container(
            width: 7,
            height: 7,
            decoration: BoxDecoration(
                color: Color(drawing.colorValue), shape: BoxShape.circle)),
        const SizedBox(width: 8),
        Expanded(
            child: Text(
                drawing.label.isEmpty
                    ? '${drawing.tool.label} ${index + 1}'
                    : drawing.label,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 11))),
        TextButton.icon(
            onPressed: () => showDrawingEditor(context, ref, index),
            icon: const Icon(Icons.tune, size: 15),
            label: const Text('속성', style: TextStyle(fontSize: 11))),
        IconButton(
            tooltip: drawing.locked ? '선 잠금 해제' : '선 잠금',
            iconSize: 16,
            onPressed: () => updateChartDrawing(
                ref, index, drawing.copyWith(locked: !drawing.locked)),
            icon: Icon(drawing.locked ? Icons.lock_outline : Icons.lock_open,
                color: drawing.locked ? VosseColors.accent : null)),
        IconButton(
            tooltip: drawing.hidden ? '선 표시' : '선 숨김',
            iconSize: 16,
            onPressed: () => updateChartDrawing(
                ref, index, drawing.copyWith(hidden: !drawing.hidden)),
            icon: Icon(drawing.hidden
                ? Icons.visibility_off_outlined
                : Icons.visibility_outlined)),
        IconButton(
            tooltip: '선택한 선 삭제',
            iconSize: 16,
            onPressed: () => removeSelectedChartDrawing(ref),
            icon: const Icon(Icons.delete_outline)),
        IconButton(
            tooltip: '선택 해제',
            iconSize: 16,
            onPressed: () => selectChartDrawing(ref, null),
            icon: const Icon(Icons.close)),
      ]),
    );
  }
}

Future<void> showDrawingEditor(
    BuildContext context, WidgetRef ref, int index) async {
  final drawings = ref.read(chartDrawingAnnotationsProvider);
  if (index < 0 || index >= drawings.length) return;
  final original = drawings[index];
  final symbol = ref.read(selectedSymbolProvider);
  final timeframe = ref.read(chartTimeframeProvider);
  final result = await showDialog<ChartDrawingAnnotation>(
      context: context,
      builder: (_) => _DrawingEditor(
          drawing: original,
          priceDecimals: RegExp(r'^\d{6}$').hasMatch(symbol) ? 0 : 2));
  if (result == null || !context.mounted) return;
  final current = ref.read(chartDrawingAnnotationsProvider);
  if (ref.read(selectedSymbolProvider) != symbol ||
      ref.read(chartTimeframeProvider) != timeframe ||
      index >= current.length ||
      !identical(current[index], original)) {
    return;
  }
  updateChartDrawing(ref, index, result);
}

class _DrawingEditor extends StatefulWidget {
  const _DrawingEditor({required this.drawing, required this.priceDecimals});
  final ChartDrawingAnnotation drawing;
  final int priceDecimals;
  @override
  State<_DrawingEditor> createState() => _DrawingEditorState();
}

class _DrawingEditorState extends State<_DrawingEditor> {
  final form = GlobalKey<FormState>();
  late final name = TextEditingController(text: widget.drawing.label);
  late final start =
      TextEditingController(text: displayPrice(widget.drawing.startPrice));
  late final end =
      TextEditingController(text: displayPrice(widget.drawing.endPrice));
  late final startTime =
      TextEditingController(text: displayTime(widget.drawing.startTime));
  late final endTime =
      TextEditingController(text: displayTime(widget.drawing.endTime));
  late final channel =
      TextEditingController(text: displayPrice(widget.drawing.channelOffset));
  String displayPrice(double? value) =>
      value?.toStringAsFixed(widget.priceDecimals) ?? '';
  double? editedPrice(String text, double? original) =>
      text == displayPrice(original)
          ? original
          : double.parse(text.replaceAll(',', ''));
  String displayTime(String? raw) {
    final at = parseCandleTimestamp(raw ?? '');
    if (at == null) return raw ?? '';
    return '${at.year}-${at.month.toString().padLeft(2, '0')}-${at.day.toString().padLeft(2, '0')} '
        '${at.hour.toString().padLeft(2, '0')}:${at.minute.toString().padLeft(2, '0')}:${at.second.toString().padLeft(2, '0')}';
  }

  late int color = widget.drawing.colorValue;
  late double width = widget.drawing.strokeWidth;
  late bool dashed = widget.drawing.dashed;
  late bool locked = widget.drawing.locked;
  @override
  void dispose() {
    for (final c in [name, start, end, startTime, endTime, channel]) {
      c.dispose();
    }
    super.dispose();
  }

  String? priceError(String? value) {
    final price = double.tryParse((value ?? '').replaceAll(',', ''));
    return price == null || !price.isFinite || price <= 0
        ? '0보다 큰 가격을 입력하세요.'
        : null;
  }

  String? timeError(String? value) {
    final raw = (value ?? '').trim();
    final parsed = parseCandleTimestamp(raw);
    final digits = raw.replaceAll(RegExp(r'[^0-9]'), '');
    if (parsed == null || digits.length < 8) return '유효한 날짜·시각을 입력하세요.';
    final expected = '${parsed.year.toString().padLeft(4, '0')}'
        '${parsed.month.toString().padLeft(2, '0')}${parsed.day.toString().padLeft(2, '0')}';
    if (digits.substring(0, 8) != expected) return '존재하지 않는 날짜입니다.';
    if (digits.length >= 12 &&
        (int.parse(digits.substring(8, 10)) != parsed.hour ||
            int.parse(digits.substring(10, 12)) != parsed.minute)) {
      return '유효한 시각을 입력하세요.';
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    final horizontal = widget.drawing.tool == ChartDrawingTool.horizontal;
    return AlertDialog(
      backgroundColor: VosseColors.bgPanel,
      title: Row(children: [
        const Icon(Icons.tune, size: 19),
        const SizedBox(width: 9),
        Text('${widget.drawing.tool.label} 속성',
            style: const TextStyle(fontSize: 17))
      ]),
      content: SizedBox(
          width: 420,
          child: SingleChildScrollView(
              child: Form(
                  key: form,
                  child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        TextFormField(
                            controller: name,
                            maxLength: 40,
                            decoration: const InputDecoration(
                                labelText: '이름', hintText: '예: 주요 지지선')),
                        const SizedBox(height: 12),
                        Row(children: [
                          Expanded(
                              child: TextFormField(
                                  controller: start,
                                  enabled: widget.drawing.anchored,
                                  validator: widget.drawing.anchored
                                      ? priceError
                                      : null,
                                  keyboardType:
                                      const TextInputType.numberWithOptions(
                                          decimal: true),
                                  decoration: InputDecoration(
                                      labelText: horizontal ? '가격' : '시작 가격'))),
                          if (!horizontal) ...[
                            const SizedBox(width: 12),
                            Expanded(
                                child: TextFormField(
                                    controller: end,
                                    enabled: widget.drawing.anchored,
                                    validator: widget.drawing.anchored
                                        ? priceError
                                        : null,
                                    keyboardType:
                                        const TextInputType.numberWithOptions(
                                            decimal: true),
                                    decoration: const InputDecoration(
                                        labelText: '끝 가격')))
                          ]
                        ]),
                        if (widget.drawing.tool ==
                            ChartDrawingTool.channel) ...[
                          const SizedBox(height: 12),
                          TextFormField(
                              controller: channel,
                              validator: priceError,
                              decoration:
                                  const InputDecoration(labelText: '채널 가격 간격')),
                        ],
                        if (widget.drawing.anchored) ...[
                          const SizedBox(height: 12),
                          TextFormField(
                              controller: startTime,
                              validator: timeError,
                              decoration: const InputDecoration(
                                  labelText: '시작 날짜·시각',
                                  helperText:
                                      '거래소 시각 · 예: 2026-10-16 15:30:00')),
                          const SizedBox(height: 8),
                          TextFormField(
                              controller: endTime,
                              validator: timeError,
                              decoration:
                                  const InputDecoration(labelText: '끝 날짜·시각')),
                        ],
                        const SizedBox(height: 20),
                        const Text('선 색상',
                            style: TextStyle(
                                fontSize: 12, color: VosseColors.textMuted)),
                        const SizedBox(height: 8),
                        Wrap(spacing: 10, children: [
                          for (final value in [
                            0xFF00C4B4,
                            0xFFF87171,
                            0xFFFBBF24,
                            0xFF60A5FA,
                            0xFFA78BFA,
                            0xFFE5E7EB
                          ])
                            Semantics(
                                label: '선 색상 ${value.toRadixString(16)}',
                                selected: value == color,
                                child: InkWell(
                                    onTap: () => setState(() => color = value),
                                    borderRadius: BorderRadius.circular(20),
                                    child: Container(
                                        width: 28,
                                        height: 28,
                                        decoration: BoxDecoration(
                                            color: Color(value),
                                            shape: BoxShape.circle,
                                            border: Border.all(
                                                color: value == color
                                                    ? Colors.white
                                                    : Colors.transparent,
                                                width: 3)))))
                        ]),
                        const SizedBox(height: 14),
                        Row(children: [
                          const Text('두께', style: TextStyle(fontSize: 12)),
                          Expanded(
                              child: Slider(
                                  value: width,
                                  min: 1,
                                  max: 4,
                                  divisions: 6,
                                  label: width.toStringAsFixed(1),
                                  onChanged: (v) => setState(() => width = v))),
                          Text('${width.toStringAsFixed(1)} px',
                              style: const TextStyle(fontSize: 11))
                        ]),
                        SwitchListTile.adaptive(
                            contentPadding: EdgeInsets.zero,
                            dense: true,
                            title: const Text('점선'),
                            value: dashed,
                            onChanged: (v) => setState(() => dashed = v)),
                        SwitchListTile.adaptive(
                            contentPadding: EdgeInsets.zero,
                            dense: true,
                            title: const Text('위치 잠금'),
                            subtitle: const Text('차트에서 실수로 선이 움직이지 않게 합니다.'),
                            value: locked,
                            onChanged: (v) => setState(() => locked = v)),
                      ])))),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(context), child: const Text('취소')),
        FilledButton(
            onPressed: () {
              if (!form.currentState!.validate()) return;
              Navigator.pop(
                  context,
                  widget.drawing.copyWith(
                      channelOffset:
                          widget.drawing.tool == ChartDrawingTool.channel
                              ? editedPrice(
                                  channel.text, widget.drawing.channelOffset)
                              : null,
                      label: name.text.trim(),
                      colorValue: color,
                      strokeWidth: width,
                      dashed: dashed,
                      locked: locked,
                      startPrice: widget.drawing.anchored
                          ? editedPrice(start.text, widget.drawing.startPrice)
                          : null,
                      endPrice: widget.drawing.anchored
                          ? editedPrice(
                              horizontal ? start.text : end.text,
                              horizontal
                                  ? widget.drawing.startPrice
                                  : widget.drawing.endPrice)
                          : null,
                      startTime: widget.drawing.anchored
                          ? (startTime.text ==
                                  displayTime(widget.drawing.startTime)
                              ? widget.drawing.startTime
                              : startTime.text.trim())
                          : null,
                      endTime: widget.drawing.anchored
                          ? (endTime.text == displayTime(widget.drawing.endTime)
                              ? widget.drawing.endTime
                              : endTime.text.trim())
                          : null));
            },
            child: const Text('적용'))
      ],
    );
  }
}
