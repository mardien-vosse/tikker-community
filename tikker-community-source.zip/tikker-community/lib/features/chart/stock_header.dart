import 'package:flutter/material.dart';

import '../../core/theme/vosse_theme.dart';
import '../../shared/models/market_models.dart';
import '../../shared/utils/formatters.dart';
import '../../shared/widgets/menu_help.dart';
import '../../shared/widgets/stock_avatar.dart';

class StockHeader extends StatelessWidget {
  const StockHeader({
    required this.stock,
    required this.color,
    this.showActions = true,
    super.key,
  });

  final MarketStock stock;
  final Color color;
  final bool showActions;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final compact = constraints.maxWidth < 820;
        final tiny = constraints.maxWidth < 500;
        return Container(
          constraints:
              BoxConstraints(minHeight: tiny ? 48 : (compact ? 50 : 44)),
          padding: EdgeInsets.symmetric(
            horizontal: compact ? 8 : 11,
            vertical: compact ? 4 : 5,
          ),
          decoration: const BoxDecoration(
            color: VosseColors.bgPanel,
            border: Border(bottom: BorderSide(color: VosseColors.border)),
          ),
          child: Row(
            children: [
              StockAvatar(
                label: stock.name,
                size: tiny ? 22 : (compact ? 24 : 26),
                logoUrl: stock.logoUrl,
              ),
              SizedBox(width: compact ? 7 : 8),
              Expanded(
                child: _StockSummary(
                  stock: stock,
                  color: color,
                  compact: compact,
                  tiny: tiny,
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _StockSummary extends StatelessWidget {
  const _StockSummary({
    required this.stock,
    required this.color,
    required this.compact,
    required this.tiny,
  });

  final MarketStock stock;
  final Color color;
  final bool compact;
  final bool tiny;

  @override
  Widget build(BuildContext context) {
    final deltaArrow = stock.rising ? '▲' : '▼';
    final hasPrice = stock.displayPrice > 0;
    final deltaText = hasPrice
        ? '$deltaArrow ${decimalPriceText(stock.displayChange.abs())}'
        : '--';
    final changePercent = hasPrice ? percentText(stock.changePercent) : '--';
    final turnover = _turnoverText(stock);
    final volume = hasPrice ? _commaInt(stock.volume) : '--';

    return LayoutBuilder(
      builder: (context, constraints) {
        final width = constraints.maxWidth;
        if (compact) {
          return Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _FitLine(
                width: width,
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _NameText(stock.name, fontSize: tiny ? 14 : 17),
                    _Dot(spacing: tiny ? 5 : 7),
                    _PriceText(stock, fontSize: tiny ? 15 : 20),
                    const SizedBox(width: 7),
                    _ToneText(
                      changePercent,
                      color: color,
                      fontSize: tiny ? 12 : 13,
                    ),
                    const SizedBox(width: 6),
                    _ToneText(
                      deltaText,
                      color: color,
                      fontSize: tiny ? 12 : 13,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 4),
              MenuTermHelp(
                term: '거래대금',
                description: '거래량은 체결 수량, 거래대금은 체결 수량에 가격을 곱한 유동성 규모입니다.',
                child: _FitLine(
                  width: width,
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _MetaPair(label: '거래대금', value: turnover),
                      const SizedBox(width: 12),
                      _MetaPair(label: '거래량', value: volume),
                    ],
                  ),
                ),
              ),
            ],
          );
        }

        return MenuTermHelp(
          term: '거래대금',
          description: '거래량은 체결 수량, 거래대금은 체결 수량에 가격을 곱한 유동성 규모입니다.',
          child: _FitLine(
            width: width,
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                _NameText(stock.name, fontSize: 18),
                const _Dot(spacing: 9),
                _PriceText(stock, fontSize: 19),
                const SizedBox(width: 9),
                _ToneText(
                  changePercent,
                  color: color,
                  fontSize: 15,
                ),
                const SizedBox(width: 8),
                _ToneText(deltaText, color: color, fontSize: 14.5),
                const _Dot(spacing: 10),
                _MetaPair(label: '거래대금', value: turnover),
                const SizedBox(width: 14),
                _MetaPair(label: '거래량', value: volume),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _FitLine extends StatelessWidget {
  const _FitLine({required this.width, required this.child});

  final double width;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      child: FittedBox(
        fit: BoxFit.scaleDown,
        alignment: Alignment.centerLeft,
        child: child,
      ),
    );
  }
}

class _NameText extends StatelessWidget {
  const _NameText(this.value, {required this.fontSize});

  final String value;
  final double fontSize;

  @override
  Widget build(BuildContext context) {
    return Text(
      value,
      maxLines: 1,
      style: TextStyle(
        color: Colors.white,
        fontSize: fontSize,
        fontWeight: FontWeight.w900,
        height: 1,
      ),
    );
  }
}

class _PriceText extends StatelessWidget {
  const _PriceText(this.stock, {required this.fontSize});

  final MarketStock stock;
  final double fontSize;

  @override
  Widget build(BuildContext context) {
    return Text(
      stockPriceText(stock),
      maxLines: 1,
      style: TextStyle(
        color: VosseColors.textPrimary,
        fontSize: fontSize,
        fontWeight: FontWeight.w900,
        height: 1,
      ),
    );
  }
}

class _ToneText extends StatelessWidget {
  const _ToneText(this.value, {required this.color, required this.fontSize});

  final String value;
  final Color color;
  final double fontSize;

  @override
  Widget build(BuildContext context) {
    return Text(
      value,
      maxLines: 1,
      style: TextStyle(
        color: color,
        fontSize: fontSize,
        fontWeight: FontWeight.w800,
        height: 1,
      ),
    );
  }
}

class _MetaPair extends StatelessWidget {
  const _MetaPair({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          label,
          style: const TextStyle(
            color: VosseColors.textMuted,
            fontSize: 14,
            fontWeight: FontWeight.w700,
            height: 1,
          ),
        ),
        const SizedBox(width: 6),
        Text(
          value,
          style: const TextStyle(
            color: VosseColors.textSecondary,
            fontSize: 14,
            fontWeight: FontWeight.w700,
            height: 1,
          ),
        ),
      ],
    );
  }
}

class _Dot extends StatelessWidget {
  const _Dot({required this.spacing});

  final double spacing;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: spacing),
      child: const Text(
        '·',
        style: TextStyle(
          color: VosseColors.textMuted,
          fontSize: 14,
          fontWeight: FontWeight.w900,
          height: 1,
        ),
      ),
    );
  }
}

String _turnoverText(MarketStock stock) {
  final amount = stock.turnover;
  if (stock.displayPrice <= 0 ||
      amount == null ||
      !amount.isFinite ||
      amount < 0) {
    return '--';
  }
  return _wonAmountText(amount.round());
}

String _wonAmountText(int won) {
  final eok = won ~/ 100000000;
  if (eok >= 10000) {
    final jo = eok ~/ 10000;
    final restEok = eok % 10000;
    return restEok == 0
        ? '${_commaInt(jo)}조'
        : '${_commaInt(jo)}조 ${_commaInt(restEok)}억';
  }
  if (eok >= 1) return '${_commaInt(eok)}억';
  final man = won ~/ 10000;
  if (man >= 1) return '${_commaInt(man)}만';
  return '${_commaInt(won)}원';
}

String _commaInt(int value) {
  final raw = value.abs().toString();
  final buffer = StringBuffer();
  for (var i = 0; i < raw.length; i += 1) {
    if (i > 0 && (raw.length - i) % 3 == 0) buffer.write(',');
    buffer.write(raw[i]);
  }
  return value < 0 ? '-$buffer' : buffer.toString();
}
