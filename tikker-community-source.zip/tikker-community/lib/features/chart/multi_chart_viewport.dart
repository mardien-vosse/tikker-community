import '../../shared/models/market_models.dart';
import 'chart_state.dart';
import 'chart_viewport.dart';
import 'realtime_candle_builder.dart';

// Intraday feeds use exchange-local wall time, not a shared UTC timestamp.
String multiChartTimeGroup(MarketStock stock, ChartTimeframe timeframe) =>
    timeframe.isIntraday
        ? (stock.isDomesticKisTicker ? 'KR' : 'US')
        : 'calendar';

class MultiChartTimeline {
  MultiChartTimeline(Iterable<List<CandlePoint>> series, this.timeframe) {
    final unique = <String>{};
    for (final candles in series) {
      for (final candle in candles) {
        final key = timeKey(candle.timestamp);
        if (key != null) unique.add(key);
      }
    }
    timestamps = unique.toList()..sort();
  }

  final ChartTimeframe timeframe;
  late final List<String> timestamps;

  String? timeKey(String timestamp) {
    final parsed = parseCandleTimestamp(timestamp);
    if (parsed == null) return null;
    var date = DateTime.utc(parsed.year, parsed.month, parsed.day);
    if (timeframe.isIntraday) {
      date = date.add(Duration(hours: parsed.hour, minutes: parsed.minute));
    } else if (timeframe == ChartTimeframe.week) {
      date = date.subtract(Duration(days: date.weekday - 1));
    } else if (timeframe == ChartTimeframe.month) {
      date = DateTime.utc(date.year, date.month);
    } else if (timeframe == ChartTimeframe.year) {
      date = DateTime.utc(date.year);
    }
    // A sortable calendar key, deliberately without a timezone suffix.
    return date.toIso8601String().substring(0, 19);
  }

  MultiChartWindow window(ChartViewport viewport) =>
      MultiChartWindow(this, viewport);
}

class MultiChartWindow {
  MultiChartWindow(this.timeline, this.viewport)
      : range = viewport.resolveTimestamps(timeline.timestamps);

  final MultiChartTimeline timeline;
  final ChartViewport viewport;
  final ChartVisibleRange range;

  List<String> get timestamps =>
      timeline.timestamps.sublist(range.start, range.end);

  MultiChartSeries project(List<CandlePoint> source) {
    final keys = timestamps;
    final slotsByTime = {
      for (var i = 0; i < keys.length; i++)
        keys[i]: i + range.slots - keys.length,
    };
    final byTime = <String, CandlePoint>{};
    for (final candle in source) {
      final key = timeline.timeKey(candle.timestamp);
      if (key != null) byTime[key] = candle;
    }
    final ordered = byTime.keys.toList()..sort();
    final visibleKeys = ordered.where(slotsByTime.containsKey).toList();
    return MultiChartSeries(
      candles: [for (final key in visibleKeys) byTime[key]!],
      history: [
        if (keys.isNotEmpty)
          for (final key in ordered)
            if (key.compareTo(keys.first) < 0) byTime[key]!,
      ],
      slots: [for (final key in visibleKeys) slotsByTime[key]!],
      showLastPrice: visibleKeys.isNotEmpty &&
          range.end == timeline.timestamps.length &&
          visibleKeys.last == keys.last,
    );
  }
}

class MultiChartSeries {
  const MultiChartSeries({
    required this.candles,
    required this.history,
    required this.slots,
    required this.showLastPrice,
  });

  final List<CandlePoint> candles;
  final List<CandlePoint> history;
  final List<int> slots;
  final bool showLastPrice;
}
