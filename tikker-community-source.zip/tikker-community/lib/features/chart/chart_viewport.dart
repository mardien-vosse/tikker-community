import 'dart:math' as math;

import '../../shared/models/market_models.dart';
import 'realtime_candle_builder.dart';

/// A time-anchored window stays put when live bars arrive or history is prepended.
class ChartViewport {
  const ChartViewport({this.capacity = 72, this.endTime});

  final int capacity;
  final String? endTime;
  bool get followsLatest => endTime == null;

  ChartVisibleRange resolve(List<CandlePoint> candles) =>
      resolveTimestamps(candles.map((c) => c.timestamp).toList());

  ChartVisibleRange resolveTimestamps(List<String> timestamps) {
    if (timestamps.isEmpty) return const ChartVisibleRange(0, 0, 20);
    var end = timestamps.length;
    if (endTime != null) {
      final exact = timestamps.indexOf(endTime!);
      final anchor = parseCandleTimestamp(endTime!);
      final after = anchor == null
          ? -1
          : timestamps.indexWhere((timestamp) =>
              parseCandleTimestamp(timestamp)?.isAfter(anchor) ?? false);
      if (exact >= 0) {
        end = exact + 1;
      } else if (after >= 0) {
        end = math.max(1, after);
      }
    }
    final start = math.max(0, end - capacity);
    return ChartVisibleRange(start, end, math.max(20, end - start));
  }

  ChartViewport pan(List<CandlePoint> candles, int bars) {
    return panTimestamps(candles.map((c) => c.timestamp).toList(), bars);
  }

  ChartViewport panTimestamps(List<String> timestamps, int bars) {
    if (timestamps.isEmpty || bars == 0) return this;
    final range = resolveTimestamps(timestamps);
    final end = (range.end + bars)
        .clamp(math.min(capacity, timestamps.length), timestamps.length)
        .toInt();
    return ChartViewport(
      capacity: capacity,
      endTime: end == timestamps.length ? null : timestamps[end - 1],
    );
  }

  ChartViewport zoom(List<CandlePoint> candles, double factor,
      {double anchor = 1}) {
    return zoomTimestamps(candles.map((c) => c.timestamp).toList(), factor,
        anchor: anchor);
  }

  ChartViewport zoomTimestamps(List<String> timestamps, double factor,
      {double anchor = 1}) {
    if (timestamps.isEmpty) return this;
    final next = (capacity * factor).round().clamp(20, 600);
    final range = resolveTimestamps(timestamps);
    final position = anchor.clamp(0.0, 1.0);
    final anchoredBar = range.start + (range.end - range.start) * position;
    final end = (anchoredBar + next * (1 - position))
        .round()
        .clamp(math.min(next, timestamps.length), timestamps.length)
        .toInt();
    return ChartViewport(
      capacity: next,
      endTime: end == timestamps.length ? null : timestamps[end - 1],
    );
  }

  ChartViewport latest() => ChartViewport(capacity: capacity);
}

class ChartVisibleRange {
  const ChartVisibleRange(this.start, this.end, this.slots);

  final int start;
  final int end;
  final int slots;
}
