import 'package:flutter_riverpod/flutter_riverpod.dart';

enum ChartTimeframe {
  minute('분', '1분봉', '2026.05.30 09:00 - 15:20'),
  threeMinute('3분', '3분봉', '실시간 3분 집계'),
  fiveMinute('5분', '5분봉', '실시간 5분 집계'),
  tenMinute('10분', '10분봉', '실시간 10분 집계'),
  fifteenMinute('15분', '15분봉', '실시간 15분 집계'),
  thirtyMinute('30분', '30분봉', '실시간 30분 집계'),
  sixtyMinute('60분', '60분봉', '실시간 60분 집계'),
  twoHour('2시간', '2시간봉', '실시간 2시간 집계'),
  fourHour('4시간', '4시간봉', '실시간 4시간 집계'),
  day('일', '일봉', '2026.02.01 - 2026.05.30'),
  week('주', '주봉', '2025.07.01 - 2026.05.30'),
  month('월', '월봉', '2023.01.01 - 2026.05.30'),
  year('년', '년봉', '2019.01.01 - 2026.05.30');

  const ChartTimeframe(this.label, this.title, this.rangeLabel);

  final String label;
  final String title;
  final String rangeLabel;

  bool get isIntraday =>
      this == ChartTimeframe.minute ||
      this == ChartTimeframe.threeMinute ||
      this == ChartTimeframe.fiveMinute ||
      this == ChartTimeframe.tenMinute ||
      this == ChartTimeframe.fifteenMinute ||
      this == ChartTimeframe.thirtyMinute ||
      this == ChartTimeframe.sixtyMinute ||
      this == ChartTimeframe.twoHour ||
      this == ChartTimeframe.fourHour;

  int get aggregationMinutes {
    return switch (this) {
      ChartTimeframe.threeMinute => 3,
      ChartTimeframe.fiveMinute => 5,
      ChartTimeframe.tenMinute => 10,
      ChartTimeframe.fifteenMinute => 15,
      ChartTimeframe.thirtyMinute => 30,
      ChartTimeframe.sixtyMinute => 60,
      ChartTimeframe.twoHour => 120,
      ChartTimeframe.fourHour => 240,
      _ => 1,
    };
  }

  String get aggregationLabel {
    return switch (this) {
      ChartTimeframe.sixtyMinute => '1시간',
      ChartTimeframe.twoHour => '2시간',
      ChartTimeframe.fourHour => '4시간',
      _ => '$aggregationMinutes분',
    };
  }

  String get intradayMenuLabel {
    return switch (this) {
      ChartTimeframe.minute => '1분',
      ChartTimeframe.sixtyMinute => '1시간 (1시)',
      ChartTimeframe.twoHour => '2시간 (2시)',
      ChartTimeframe.fourHour => '4시간 (4시)',
      _ => label,
    };
  }

  String get kisRestTimeframe {
    return isIntraday ? ChartTimeframe.minute.name : name;
  }
}

enum ChartRenderMode {
  candle('캔들'),
  line('라인'),
  area('영역');

  const ChartRenderMode(this.label);

  final String label;
}

enum ChartDrawingTool {
  none('없음'),
  trend('추세선'),
  horizontal('수평선'),
  fibonacci('피보나치'),
  vertical('수직선'),
  rectangle('사각형'),
  range('가격·기간 측정'),
  text('텍스트'),
  channel('평행 채널');

  const ChartDrawingTool(this.label);

  final String label;
}

enum ChartIndicator {
  ema('SMA'),
  bollinger('밴드'),
  rsi('RSI'),
  macd('MACD');

  const ChartIndicator(this.label);

  final String label;
}

enum ChartMultiLayout {
  one(1, 1, 1, '1'),
  twoColumns(2, 1, 2, '2열'),
  twoRows(2, 2, 1, '2행'),
  threeColumns(3, 1, 3, '3열'),
  threeRows(3, 3, 1, '3행'),
  threeGrid(3, 2, 2, '3분할'),
  fourGrid(4, 2, 2, '2x2'),
  fourColumns(4, 1, 4, '4열'),
  fourRows(4, 4, 1, '4행'),
  fiveGrid(5, 2, 3, '5분할'),
  fiveColumns(5, 1, 5, '5열'),
  fiveRows(5, 5, 1, '5행'),
  sixGrid(6, 2, 3, '2x3'),
  sixColumns(6, 1, 6, '6열'),
  sixRows(6, 6, 1, '6행'),
  sevenGrid(7, 2, 4, '7분할'),
  sevenColumns(7, 1, 7, '7열'),
  sevenRows(7, 7, 1, '7행'),
  eightGrid(8, 2, 4, '2x4'),
  eightColumns(8, 1, 8, '8열'),
  eightRows(8, 8, 1, '8행');

  const ChartMultiLayout(this.tileCount, this.rows, this.columns, this.label);

  final int tileCount;
  final int rows;
  final int columns;
  final String label;

  bool get isSingle => tileCount == 1;
}

class ChartDrawingAnnotation {
  const ChartDrawingAnnotation({
    required this.tool,
    required this.startX,
    required this.startY,
    required this.endX,
    required this.endY,
    this.startTime,
    this.startPrice,
    this.endTime,
    this.endPrice,
    this.channelOffset = 0,
    this.colorValue = 0xFF00C4B4,
    this.strokeWidth = 1.5,
    this.dashed = false,
    this.locked = false,
    this.hidden = false,
    this.label = '',
  });

  final double channelOffset;
  final int colorValue;
  final double strokeWidth;
  final bool dashed, locked, hidden;
  final String label;
  final ChartDrawingTool tool;
  final double startX;
  final double startY;
  final double endX;
  final double endY;
  final String? startTime;
  final double? startPrice;
  final String? endTime;
  final double? endPrice;
  bool get anchored =>
      startTime != null &&
      startPrice != null &&
      endTime != null &&
      endPrice != null;

  ChartDrawingAnnotation copyWith({
    ChartDrawingTool? tool,
    double? startX,
    double? startY,
    double? endX,
    double? endY,
    String? startTime,
    double? startPrice,
    String? endTime,
    double? endPrice,
    double? channelOffset,
    int? colorValue,
    double? strokeWidth,
    bool? dashed,
    bool? locked,
    bool? hidden,
    String? label,
  }) {
    return ChartDrawingAnnotation(
      channelOffset: channelOffset ?? this.channelOffset,
      colorValue: colorValue ?? this.colorValue,
      strokeWidth: strokeWidth ?? this.strokeWidth,
      dashed: dashed ?? this.dashed,
      locked: locked ?? this.locked,
      hidden: hidden ?? this.hidden,
      label: label ?? this.label,
      tool: tool ?? this.tool,
      startX: startX ?? this.startX,
      startY: startY ?? this.startY,
      endX: endX ?? this.endX,
      endY: endY ?? this.endY,
      startTime: startTime ?? this.startTime,
      startPrice: startPrice ?? this.startPrice,
      endTime: endTime ?? this.endTime,
      endPrice: endPrice ?? this.endPrice,
    );
  }
}

class ChartCrosshairSnapshot {
  const ChartCrosshairSnapshot({
    required this.x,
    required this.y,
    required this.candleIndex,
  });

  final double x;
  final double y;
  final int candleIndex;
}

final chartTimeframeProvider =
    StateProvider<ChartTimeframe>((ref) => ChartTimeframe.day);

final chartRenderModeProvider =
    StateProvider<ChartRenderMode>((ref) => ChartRenderMode.candle);

final chartDrawingSnapProvider = StateProvider<bool>((ref) => false);

final chartDrawingEnabledProvider = StateProvider<bool>((ref) => false);

final chartDrawingToolProvider =
    StateProvider<ChartDrawingTool>((ref) => ChartDrawingTool.none);

final chartDrawingAnnotationsProvider =
    StateProvider<List<ChartDrawingAnnotation>>((ref) => const []);

final chartDraftDrawingProvider =
    StateProvider<ChartDrawingAnnotation?>((ref) => null);

final chartSelectedDrawingIndexProvider = StateProvider<int?>((ref) => null);

final chartCrosshairProvider =
    StateProvider<ChartCrosshairSnapshot?>((ref) => null);

final chartComparisonEnabledProvider = StateProvider<bool>((ref) => false);

final chartComparisonSymbolProvider = StateProvider<String>((ref) => '035420');

final chartComparisonSymbolsProvider =
    StateProvider<Set<String>>((ref) => const {'035420'});

final chartHiddenComparisonSymbolsProvider =
    StateProvider<Set<String>>((ref) => const {});

final chartVolumeVisibleProvider = StateProvider<bool>((ref) => true);

final chartMultiLayoutProvider =
    StateProvider<ChartMultiLayout>((ref) => ChartMultiLayout.one);

final chartMultiSymbolsProvider =
    StateProvider<List<String>>((ref) => const []);

final chartIndicatorVisibilityProvider = StateProvider<Set<ChartIndicator>>(
  (ref) => const {ChartIndicator.ema},
);

List<String> resolveChartMultiSymbols({
  required String selectedSymbol,
  required Iterable<String> watchlistSymbols,
  required ChartMultiLayout layout,
  required Iterable<String> configuredSymbols,
}) {
  final knownSymbols = <String>{};
  void markKnown(String symbol) {
    final trimmed = symbol.trim();
    if (trimmed.isNotEmpty) knownSymbols.add(trimmed);
  }

  markKnown(selectedSymbol);
  for (final symbol in watchlistSymbols) {
    markKnown(symbol);
  }

  final symbols = <String>[];
  void add(String symbol) {
    final trimmed = symbol.trim();
    if (symbols.length >= layout.tileCount) return;
    if (!knownSymbols.contains(trimmed) || symbols.contains(trimmed)) return;
    symbols.add(trimmed);
  }

  // Why: user-picked tile symbols should win, then empty slots are filled by
  // the current symbol and watchlist so the multi-chart never opens blank.
  for (final symbol in configuredSymbols) {
    add(symbol);
  }
  add(selectedSymbol);
  for (final symbol in watchlistSymbols) {
    add(symbol);
  }
  return symbols;
}

void toggleChartIndicator(WidgetRef ref, ChartIndicator indicator) {
  final selected = ref.read(chartIndicatorVisibilityProvider);
  final next = {...selected};
  if (next.contains(indicator)) {
    next.remove(indicator);
  } else {
    next.add(indicator);
  }
  ref.read(chartIndicatorVisibilityProvider.notifier).state = next;
}

void toggleAllChartIndicators(WidgetRef ref) {
  const all = {
    ChartIndicator.ema,
    ChartIndicator.bollinger,
    ChartIndicator.rsi,
    ChartIndicator.macd,
  };
  final selected = ref.read(chartIndicatorVisibilityProvider);
  // Why: one tap should work as a real master switch, not only highlight a chip.
  ref.read(chartIndicatorVisibilityProvider.notifier).state =
      selected.length == all.length ? const {} : all;
}

void addChartDrawing(WidgetRef ref, ChartDrawingAnnotation annotation) {
  if (annotation.tool == ChartDrawingTool.none) return;
  final current = ref.read(chartDrawingAnnotationsProvider);
  // Why: unbounded drawing history makes resize/repaint work grow forever.
  final next = [
    ...current.take(29),
    annotation,
  ];
  ref.read(chartDrawingAnnotationsProvider.notifier).state = next;
  ref.read(chartSelectedDrawingIndexProvider.notifier).state = next.length - 1;
}

void selectChartDrawing(WidgetRef ref, int? index) {
  final drawings = ref.read(chartDrawingAnnotationsProvider);
  if (index == null || index < 0 || index >= drawings.length) {
    ref.read(chartSelectedDrawingIndexProvider.notifier).state = null;
    return;
  }
  ref.read(chartSelectedDrawingIndexProvider.notifier).state = index;
}

void updateChartDrawing(
  WidgetRef ref,
  int index,
  ChartDrawingAnnotation annotation,
) {
  final current = ref.read(chartDrawingAnnotationsProvider);
  if (index < 0 || index >= current.length) return;
  ref.read(chartDrawingAnnotationsProvider.notifier).state = [
    for (var i = 0; i < current.length; i += 1)
      if (i == index) annotation else current[i],
  ];
  ref.read(chartSelectedDrawingIndexProvider.notifier).state = index;
}

void removeSelectedChartDrawing(WidgetRef ref) {
  final selected = ref.read(chartSelectedDrawingIndexProvider);
  final current = ref.read(chartDrawingAnnotationsProvider);
  if (selected == null || selected < 0 || selected >= current.length) return;
  final next = [
    for (var i = 0; i < current.length; i += 1)
      if (i != selected) current[i],
  ];
  ref.read(chartDrawingAnnotationsProvider.notifier).state = next;
  ref.read(chartSelectedDrawingIndexProvider.notifier).state = null;
}

void clearChartDrawings(WidgetRef ref) {
  ref.read(chartDrawingAnnotationsProvider.notifier).state = const [];
  ref.read(chartDraftDrawingProvider.notifier).state = null;
  ref.read(chartSelectedDrawingIndexProvider.notifier).state = null;
}

void setChartCrosshair(WidgetRef ref, ChartCrosshairSnapshot? snapshot) {
  ref.read(chartCrosshairProvider.notifier).state = snapshot;
}

void toggleComparisonSymbol(WidgetRef ref, String symbol) {
  final enabled = ref.read(chartComparisonEnabledProvider);
  final current = ref.read(chartComparisonSymbolsProvider);
  final hidden = {...ref.read(chartHiddenComparisonSymbolsProvider)};
  final next = enabled ? {...current} : <String>{};
  if (next.contains(symbol)) {
    next.remove(symbol);
    hidden.remove(symbol);
  } else {
    next.add(symbol);
    hidden.remove(symbol);
  }

  // Why: the legacy single-symbol provider still backs older call sites/tests.
  ref.read(chartComparisonSymbolProvider.notifier).state =
      next.isEmpty ? symbol : next.last;
  ref.read(chartComparisonSymbolsProvider.notifier).state = next;
  ref.read(chartHiddenComparisonSymbolsProvider.notifier).state = hidden;
  ref.read(chartComparisonEnabledProvider.notifier).state = next.isNotEmpty;
}

void toggleComparisonSymbolVisibility(WidgetRef ref, String symbol) {
  final selected = ref.read(chartComparisonSymbolsProvider);
  if (!selected.contains(symbol)) return;
  final hidden = {...ref.read(chartHiddenComparisonSymbolsProvider)};
  if (hidden.contains(symbol)) {
    hidden.remove(symbol);
  } else {
    hidden.add(symbol);
  }
  ref.read(chartHiddenComparisonSymbolsProvider.notifier).state = hidden;
}

void clearComparisonSymbols(WidgetRef ref) {
  ref.read(chartComparisonSymbolsProvider.notifier).state = const {};
  ref.read(chartHiddenComparisonSymbolsProvider.notifier).state = const {};
  ref.read(chartComparisonEnabledProvider.notifier).state = false;
}
