import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/vosse_theme.dart';
import '../../providers/market_providers.dart';
import '../../shared/models/market_models.dart';
import '../../shared/utils/formatters.dart';
import '../../shared/widgets/menu_help.dart';
import 'chart_state.dart';

class ChartQuoteTape extends ConsumerWidget {
  const ChartQuoteTape({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final timeframe = ref.watch(chartTimeframeProvider);
    final crosshair = ref.watch(chartCrosshairProvider);
    final liveCandles = ref.watch(liveCandleProvider).valueOrNull;
    final List<CandlePoint> candles = liveCandles ?? const [];
    if (candles.isEmpty) return const SizedBox.shrink();

    final index = _focusedIndex(crosshair, candles.length);
    final candle = candles[index];
    final previousClose = index > 0 ? candles[index - 1].close : candle.open;
    final tone =
        candle.close >= candle.open ? VosseColors.up : VosseColors.down;
    final source = ref.watch(selectedCandleSourceProvider);
    final mode = crosshair == null ? '현재' : '커서';

    return Container(
      height: 32,
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: const BoxDecoration(
        color: Color(0xFF0A0B0F),
        border: Border(bottom: BorderSide(color: VosseColors.border)),
      ),
      child: Row(
        children: [
          MenuHelp(
            title: 'OHLCV 테이프',
            description:
                '선택 종목의 기준 캔들 시가, 고가, 저가, 종가, 거래량을 한 줄로 보여줍니다. 차트 위에 마우스를 올리면 커서가 가리키는 캔들 값으로 바뀝니다.',
            placement: MenuHelpPlacement.below,
            child: _TapeBadge(
              label: '$mode ${timeframe.label}',
              color: tone,
            ),
          ),
          const SizedBox(width: 6),
          Expanded(
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  _TapeMetric(
                    label: '시',
                    value: _price(candle.open),
                    delta: _percentChange(candle.open, previousClose),
                    help: '시가: 이 캔들이 시작된 가격입니다.',
                  ),
                  _TapeMetric(
                    label: '고',
                    value: _price(candle.high),
                    delta: _percentChange(candle.high, previousClose),
                    help: '고가: 이 캔들 구간에서 가장 높게 거래된 가격입니다.',
                  ),
                  _TapeMetric(
                    label: '저',
                    value: _price(candle.low),
                    delta: _percentChange(candle.low, previousClose),
                    help: '저가: 이 캔들 구간에서 가장 낮게 거래된 가격입니다.',
                  ),
                  _TapeMetric(
                    label: '종',
                    value: _price(candle.close),
                    delta: _percentChange(candle.close, previousClose),
                    help: '종가: 이 캔들의 마지막 가격입니다. 실시간 1분봉에서는 최신 체결로 계속 갱신됩니다.',
                  ),
                  _TapeMetric(
                    label: '거래량',
                    value: compactVolume(candle.volume.round()),
                    delta: null,
                    help: '거래량: 이 캔들 구간에 체결된 수량입니다.',
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 6),
          MenuHelp(
            title: '캔들 데이터 소스',
            description:
                '${source.label} 기준으로 표시 중입니다. KIS 실시간 체결이 들어오면 장중 캔들이 갱신됩니다.',
            placement: MenuHelpPlacement.left,
            child: Text(
              source.label,
              style: const TextStyle(
                color: VosseColors.textMuted,
                fontSize: 10.5,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
        ],
      ),
    );
  }

  int _focusedIndex(ChartCrosshairSnapshot? crosshair, int count) {
    if (count <= 0) return 0;
    return (crosshair?.candleIndex ?? count - 1).clamp(0, count - 1).toInt();
  }

  String _price(double value) => decimalPriceText(value);

  double _percentChange(double value, double base) {
    if (base == 0) return 0;
    return ((value - base) / base) * 100;
  }
}

class _TapeBadge extends StatelessWidget {
  const _TapeBadge({required this.label, required this.color});

  final String label;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 22,
      padding: const EdgeInsets.symmetric(horizontal: 7),
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: color.withValues(alpha: .13),
        border: Border.all(color: color.withValues(alpha: .38)),
        borderRadius: BorderRadius.circular(5),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: color,
          fontSize: 10.5,
          fontWeight: FontWeight.w900,
        ),
      ),
    );
  }
}

class _TapeMetric extends StatelessWidget {
  const _TapeMetric({
    required this.label,
    required this.value,
    required this.help,
    this.delta,
  });

  final String label;
  final String value;
  final String help;
  final double? delta;

  @override
  Widget build(BuildContext context) {
    final deltaValue = delta;
    final color = deltaValue == null
        ? VosseColors.textPrimary
        : deltaValue >= 0
            ? VosseColors.up
            : VosseColors.down;
    return Padding(
      padding: const EdgeInsets.only(right: 10),
      child: MenuHelp(
        title: label,
        description: help,
        placement: MenuHelpPlacement.below,
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              '$label ',
              style: const TextStyle(
                color: VosseColors.textMuted,
                fontSize: 10.5,
                fontWeight: FontWeight.w900,
              ),
            ),
            Text(
              value,
              style: TextStyle(
                color: color,
                fontSize: 11,
                fontWeight: FontWeight.w900,
              ),
            ),
            if (deltaValue != null) ...[
              const SizedBox(width: 3),
              Text(
                '(${percentText(deltaValue)})',
                style: TextStyle(
                  color: color,
                  fontSize: 10.5,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
