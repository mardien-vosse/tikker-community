import '../../shared/models/market_models.dart';

String candleDateRangeLabel(List<CandlePoint> candles) {
  if (candles.isEmpty) return '기간 확인 불가';
  final first = parseCandleTimestamp(candles.first.timestamp);
  final last = parseCandleTimestamp(candles.last.timestamp);
  if (first == null || last == null) return '기간 확인 불가';
  String label(DateTime time, String timestamp) {
    final date = '${time.year}.${time.month.toString().padLeft(2, '0')}.'
        '${time.day.toString().padLeft(2, '0')}';
    if (timestamp.length <= 8) return date;
    return '$date ${time.hour.toString().padLeft(2, '0')}:'
        '${time.minute.toString().padLeft(2, '0')}';
  }

  return '${label(first, candles.first.timestamp)} - '
      '${label(last, candles.last.timestamp)}';
}

class RealtimeTradeTick {
  const RealtimeTradeTick({
    required this.price,
    required this.volume,
    required this.occurredAt,
    this.cumulativeVolume,
    this.sessionOpen,
    this.sessionHigh,
    this.sessionLow,
  });

  final double price;
  final double volume;
  final DateTime occurredAt;
  final double? cumulativeVolume;
  final double? sessionOpen;
  final double? sessionHigh;
  final double? sessionLow;
}

RealtimeTradeTick? tradeTickFromQuote(
  Map<String, dynamic> quote, {
  DateTime Function()? now,
}) {
  final ticks = tradeTicksFromQuote(quote, now: now);
  return ticks.isEmpty ? null : ticks.first;
}

List<RealtimeTradeTick> tradeTicksFromQuote(
  Map<String, dynamic> quote, {
  DateTime Function()? now,
}) {
  final channel = quote['channel']?.toString();
  if (channel != 'domestic_trade' && channel != 'overseas_trade') {
    return const [];
  }
  final rows = _tradeRows(quote);
  final clock = now ??
      () => channel == 'domestic_trade'
          ? DateTime.now().toUtc().add(const Duration(hours: 9))
          : DateTime.now();
  final ticks = <MapEntry<int, RealtimeTradeTick>>[];
  for (var i = 0; i < rows.length; i += 1) {
    final row = rows[i];
    final price = _doubleValue(row['STCK_PRPR']) ??
        _doubleValue(row['LAST']) ??
        _doubleValue(row['current_price']) ??
        _doubleValue(quote['current_price']);
    if (price == null || price <= 0) continue;

    final volume = _doubleValue(row['CNTG_VOL']) ??
        _doubleValue(row['EVOL']) ??
        _doubleValue(row['trade_volume']) ??
        _doubleValue(quote['trade_volume']) ??
        0;
    ticks.add(
      MapEntry(
        i,
        RealtimeTradeTick(
          price: price,
          volume: volume < 0 ? 0 : volume,
          occurredAt: _tradeTime(row, now: clock),
          cumulativeVolume: _doubleValue(row['ACML_VOL'] ?? row['TVOL']),
          sessionOpen: _doubleValue(row['STCK_OPRC'] ?? row['OPEN']),
          sessionHigh: _doubleValue(row['STCK_HGPR'] ?? row['HIGH']),
          sessionLow: _doubleValue(row['STCK_LWPR'] ?? row['LOW']),
        ),
      ),
    );
  }
  // Why: KIS batched trade rows can arrive out of order during bursts; applying
  // them chronologically prevents a newer row from making older rows look stale.
  ticks.sort((left, right) {
    final timeOrder = left.value.occurredAt.compareTo(right.value.occurredAt);
    return timeOrder == 0 ? left.key.compareTo(right.key) : timeOrder;
  });
  return [for (final entry in ticks) entry.value];
}

List<CandlePoint> mergeRealtimeTradeTick(
  List<CandlePoint> candles,
  RealtimeTradeTick tick, {
  int maxCandles = 240,
}) {
  final bucket = _bucketStart(tick.occurredAt, 1);
  final bucketTimestamp = _formatTimestamp(bucket);
  final next = [...candles];
  final last = next.isEmpty ? null : next.last;
  final lastBucket = last == null ? null : candleBucketStart(last, minutes: 1);

  // Why: reconnects or buffered packets can contain older trades; appending them
  // would make the visible chart jump backwards and create a false last candle.
  if (lastBucket != null && bucket.isBefore(lastBucket)) return candles;

  if (last != null && lastBucket != null && lastBucket == bucket) {
    next[next.length - 1] = last.copyWith(
      high: tick.price > last.high ? tick.price : last.high,
      low: tick.price < last.low ? tick.price : last.low,
      close: tick.price,
      volume: last.volume + tick.volume,
      timestamp: last.timestamp.isNotEmpty ? last.timestamp : bucketTimestamp,
    );
  } else {
    next.add(
      CandlePoint(
        open: tick.price,
        high: tick.price,
        low: tick.price,
        close: tick.price,
        volume: tick.volume,
        timestamp: bucketTimestamp,
      ),
    );
  }

  if (next.length <= maxCandles) return next;
  return next.sublist(next.length - maxCandles);
}

List<CandlePoint> mergeRealtimePeriodTick(
  List<CandlePoint> candles,
  RealtimeTradeTick tick, {
  required String period,
}) {
  final bucket = _periodStart(tick.occurredAt, period);
  final last = candles.isEmpty ? null : candles.last;
  final lastTime = last == null ? null : parseCandleTimestamp(last.timestamp);
  if (last != null && lastTime == null) return candles;
  final lastBucket = lastTime == null ? null : _periodStart(lastTime, period);
  if (lastBucket != null && bucket.isBefore(lastBucket)) return candles;
  final high = tick.sessionHigh != null && tick.sessionHigh! > tick.price
      ? tick.sessionHigh!
      : tick.price;
  final low = tick.sessionLow != null &&
          tick.sessionLow! > 0 &&
          tick.sessionLow! < tick.price
      ? tick.sessionLow!
      : tick.price;
  if (last == null || lastBucket != bucket) {
    return [
      ...candles,
      CandlePoint(
        open: (tick.sessionOpen ?? 0) > 0 ? tick.sessionOpen! : tick.price,
        high: high,
        low: low,
        close: tick.price,
        volume: tick.cumulativeVolume ?? tick.volume,
        timestamp: _formatTimestamp(bucket),
      ),
    ];
  }
  return [
    ...candles.take(candles.length - 1),
    last.copyWith(
      high: high > last.high ? high : last.high,
      low: low < last.low ? low : last.low,
      close: tick.price,
      // Multi-day totals are refreshed from REST, not reconstructed from a
      // partial session. Daily volume comes directly from the exchange total.
      volume:
          period == 'day' ? tick.cumulativeVolume ?? last.volume : last.volume,
    ),
  ];
}

DateTime _periodStart(DateTime timestamp, String period) {
  final day = DateTime(timestamp.year, timestamp.month, timestamp.day);
  return switch (period) {
    'week' => day.subtract(Duration(days: day.weekday - DateTime.monday)),
    'month' => DateTime(timestamp.year, timestamp.month),
    'year' => DateTime(timestamp.year),
    _ => day,
  };
}

List<CandlePoint> aggregateCandlesByMinutes(
  List<CandlePoint> candles,
  int minutes,
) {
  if (minutes <= 1 || candles.isEmpty) return candles;
  if (candles.any((candle) => parseCandleTimestamp(candle.timestamp) == null)) {
    return aggregateCandlesByWindow(candles, minutes);
  }

  final aggregated = <CandlePoint>[];
  DateTime? activeBucket;
  CandlePoint? active;
  for (final candle in candles) {
    final timestamp = parseCandleTimestamp(candle.timestamp);
    if (timestamp == null) continue;
    final bucket = _bucketStart(timestamp, minutes);
    if (active == null || activeBucket != bucket) {
      if (active != null) aggregated.add(active);
      activeBucket = bucket;
      active = candle.copyWith(timestamp: _formatTimestamp(bucket));
      continue;
    }
    active = active.copyWith(
      high: candle.high > active.high ? candle.high : active.high,
      low: candle.low < active.low ? candle.low : active.low,
      close: candle.close,
      volume: active.volume + candle.volume,
    );
  }
  if (active != null) aggregated.add(active);
  return aggregated;
}

List<CandlePoint> aggregateCandlesByWindow(
  List<CandlePoint> candles,
  int window,
) {
  if (window <= 1) return candles;
  final aggregated = <CandlePoint>[];
  for (var i = 0; i < candles.length; i += window) {
    final slice = candles.sublist(
      i,
      i + window > candles.length ? candles.length : i + window,
    );
    if (slice.isEmpty) continue;
    aggregated.add(
      CandlePoint(
        open: slice.first.open,
        high:
            slice.map((candle) => candle.high).reduce((a, b) => a > b ? a : b),
        low: slice.map((candle) => candle.low).reduce((a, b) => a < b ? a : b),
        close: slice.last.close,
        volume: slice.map((candle) => candle.volume).reduce((a, b) => a + b),
        timestamp: slice.first.timestamp,
      ),
    );
  }
  return aggregated;
}

DateTime? candleBucketStart(CandlePoint candle, {required int minutes}) {
  final timestamp = parseCandleTimestamp(candle.timestamp);
  if (timestamp == null) return null;
  return _bucketStart(timestamp, minutes);
}

DateTime? parseCandleTimestamp(String raw) {
  final value = raw.trim();
  if (value.isEmpty) return null;
  final iso = DateTime.tryParse(value);
  if (iso != null) return iso;
  final digits = value.replaceAll(RegExp(r'[^0-9]'), '');
  if (digits.length < 8) return null;
  final year = int.tryParse(digits.substring(0, 4));
  final month = int.tryParse(digits.substring(4, 6));
  final day = int.tryParse(digits.substring(6, 8));
  if (year == null || month == null || day == null) return null;
  final hour = digits.length >= 10 ? int.tryParse(digits.substring(8, 10)) : 0;
  final minute =
      digits.length >= 12 ? int.tryParse(digits.substring(10, 12)) : 0;
  final second =
      digits.length >= 14 ? int.tryParse(digits.substring(12, 14)) : 0;
  if (hour == null || minute == null || second == null) return null;
  if (month < 1 ||
      month > 12 ||
      day < 1 ||
      hour < 0 ||
      hour > 23 ||
      minute < 0 ||
      minute > 59 ||
      second < 0 ||
      second > 59) {
    return null;
  }
  final parsed = DateTime(year, month, day, hour, minute, second);
  if (parsed.year != year || parsed.month != month || parsed.day != day) {
    return null;
  }
  return parsed;
}

List<Map<String, dynamic>> _tradeRows(Map<String, dynamic> quote) {
  final payload = quote['payload'];
  if (payload is Map) {
    final rows = payload['rows'];
    if (rows is List && rows.isNotEmpty) {
      return rows
          .whereType<Map>()
          .map((row) => Map<String, dynamic>.from(row))
          .toList(growable: false);
    }
  }
  return [quote];
}

DateTime _tradeTime(
  Map<String, dynamic>? row, {
  required DateTime Function() now,
}) {
  final clock = now();
  final date =
      row?['BSOP_DATE']?.toString().trim() ?? row?['XYMD']?.toString().trim();
  final rawTime = row?['STCK_CNTG_HOUR']?.toString().trim() ??
      row?['XHMS']?.toString().trim() ??
      row?['event_time']?.toString().trim();
  final dateDigits = date == null || date.length < 8
      ? _dateDigits(clock)
      : date.replaceAll(RegExp(r'[^0-9]'), '').padRight(8, '0').substring(0, 8);
  final timeDigits = _normalizedTradeTimeDigits(rawTime, fallback: clock);
  return parseCandleTimestamp('$dateDigits$timeDigits') ?? clock;
}

String _normalizedTradeTimeDigits(String? rawTime,
    {required DateTime fallback}) {
  final digits = rawTime?.replaceAll(RegExp(r'[^0-9]'), '').trim() ?? '';
  if (digits.isEmpty) return _timeDigits(fallback);
  // Why: some relay payloads drop the leading zero before 10:00. Padding on the
  // left preserves 09:58:30, while right-padding would create an invalid hour.
  if (digits.length < 6) return digits.padLeft(6, '0');
  return digits.substring(0, 6);
}

DateTime _bucketStart(DateTime timestamp, int minutes) {
  final minute = timestamp.minute - (timestamp.minute % minutes);
  return DateTime(
    timestamp.year,
    timestamp.month,
    timestamp.day,
    timestamp.hour,
    minute,
  );
}

String _formatTimestamp(DateTime timestamp) {
  return '${timestamp.year.toString().padLeft(4, '0')}'
      '${timestamp.month.toString().padLeft(2, '0')}'
      '${timestamp.day.toString().padLeft(2, '0')}'
      '${timestamp.hour.toString().padLeft(2, '0')}'
      '${timestamp.minute.toString().padLeft(2, '0')}'
      '${timestamp.second.toString().padLeft(2, '0')}';
}

String _dateDigits(DateTime timestamp) {
  return '${timestamp.year.toString().padLeft(4, '0')}'
      '${timestamp.month.toString().padLeft(2, '0')}'
      '${timestamp.day.toString().padLeft(2, '0')}';
}

String _timeDigits(DateTime timestamp) {
  return '${timestamp.hour.toString().padLeft(2, '0')}'
      '${timestamp.minute.toString().padLeft(2, '0')}'
      '${timestamp.second.toString().padLeft(2, '0')}';
}

double? _doubleValue(Object? value) {
  if (value == null) return null;
  final parsed = value is num
      ? value.toDouble()
      : double.tryParse(value.toString().replaceAll(',', '').trim());
  return parsed != null && parsed.isFinite ? parsed : null;
}
