import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/vosse_theme.dart';
import '../../providers/market_providers.dart';
import '../../providers/app_preferences.dart';
import '../../shared/models/market_data_source.dart';
import '../../shared/models/market_models.dart';
import '../../shared/utils/formatters.dart';
import '../../shared/widgets/menu_help.dart';
import '../../shared/widgets/stock_avatar.dart';
import 'candle_chart_painter.dart';
import 'chart_quote_tape.dart';
import 'chart_status_bar.dart';
import 'chart_state.dart';
import 'realtime_candle_builder.dart';
import 'chart_toolbar.dart';
import 'stock_header.dart';
import 'chart_viewport.dart';
import 'multi_chart_viewport.dart';
import 'drawing_coordinates.dart';
import 'chart_metrics.dart';
import 'drawing_editor.dart';

class ChartPanel extends ConsumerStatefulWidget {
  const ChartPanel(
      {super.key,
      this.initialDiagnostics = false,
      this.allowDiagnostics = true,
      this.showHeaderActions = true,
      this.onToggleInfo,
      this.infoVisible = true});

  final bool initialDiagnostics;
  final bool allowDiagnostics;
  final bool showHeaderActions;
  final VoidCallback? onToggleInfo;
  final bool infoVisible;

  @override
  ConsumerState<ChartPanel> createState() => _ChartPanelState();
}

class _ChartPanelState extends ConsumerState<ChartPanel> {
  final _viewports = <String, ChartViewport>{};
  final _viewportSaveTimers = <String, Timer>{};
  (String, String)? _multiHover;
  late bool _diagnostics = widget.allowDiagnostics && widget.initialDiagnostics;

  @override
  void dispose() {
    for (final timer in _viewportSaveTimers.values) {
      timer.cancel();
    }
    super.dispose();
  }

  void _updateViewport(String key, ChartViewport viewport) {
    setChartCrosshair(ref, null);
    setState(() {
      _viewports[key] = viewport;
      _multiHover = null;
    });
    final separator = key.lastIndexOf(':');
    if (separator <= 0) return;
    final timeframeName = key.substring(separator + 1);
    ChartTimeframe? timeframe;
    for (final value in ChartTimeframe.values) {
      if (value.name == timeframeName) {
        timeframe = value;
        break;
      }
    }
    if (timeframe == null) return;
    final symbol = key.substring(0, separator);
    _viewportSaveTimers[key]?.cancel();
    _viewportSaveTimers[key] = Timer(const Duration(milliseconds: 250), () {
      _viewportSaveTimers.remove(key);
      unawaited(ref.read(appPreferencesStoreProvider).saveChartViewport(
            symbol: symbol,
            timeframe: timeframe!,
            viewport: viewport,
          ));
    });
  }

  @override
  Widget build(BuildContext context) {
    final selectedSymbol = ref.watch(selectedSymbolProvider);
    final fallbackStock = ref.watch(selectedStockProvider);
    final restStock = ref.watch(liveSelectedStockProvider).valueOrNull;
    // A websocket quote cached in fallbackStock is newer than the periodic REST
    // snapshot and must drive the visible header price immediately.
    final stock =
        fallbackStock.quotePrice != null && fallbackStock.displayPrice > 0
            ? fallbackStock
            : restStock?.symbol == selectedSymbol
                ? restStock!
                : fallbackStock;
    final renderMode = ref.watch(chartRenderModeProvider);
    final indicators = ref.watch(chartIndicatorVisibilityProvider);
    final drawingEnabled = ref.watch(chartDrawingEnabledProvider);
    final drawingTool = ref.watch(chartDrawingToolProvider);
    final drawingAnnotations = ref.watch(chartDrawingAnnotationsProvider);
    final draftDrawing = ref.watch(chartDraftDrawingProvider);
    final selectedDrawingIndex = ref.watch(chartSelectedDrawingIndexProvider);
    final crosshair = ref.watch(chartCrosshairProvider);
    final multiLayout = ref.watch(chartMultiLayoutProvider);
    final comparisonEnabled = ref.watch(chartComparisonEnabledProvider);
    final comparisonSymbols = ref
        .watch(chartComparisonSymbolsProvider)
        .where((symbol) => symbol != selectedSymbol)
        .toSet();
    final hiddenComparisonSymbols =
        ref.watch(chartHiddenComparisonSymbolsProvider);
    final volumeVisible = ref.watch(chartVolumeVisibleProvider);
    final watchlist = ref.watch(displayWatchlistProvider);
    final configuredMultiSymbols = ref.watch(chartMultiSymbolsProvider);
    final comparisonLabels = _stockLabels(watchlist, comparisonSymbols);
    final candleState = ref.watch(liveCandleProvider);
    // A dependency reload can retain the previous symbol/timeframe's value.
    // Only same-scope background refreshes may keep their existing candles.
    final List<CandlePoint> candles = candleState.when(
      skipLoadingOnReload: false,
      skipError: false,
      data: (value) => value,
      loading: () => const [],
      error: (_, __) => const [],
    );
    final timeframe = ref.watch(chartTimeframeProvider);
    final viewportKey = '$selectedSymbol:${timeframe.name}';
    final viewport = _viewports.putIfAbsent(
      viewportKey,
      () => ref.read(appPreferencesStoreProvider).loadChartViewport(
            symbol: selectedSymbol,
            timeframe: timeframe,
          ),
    );
    final navigable =
        !_diagnostics && !comparisonEnabled && multiLayout.isSingle;
    final range = navigable
        ? viewport.resolve(candles)
        : ChartVisibleRange(0, candles.length, candles.length);
    final visibleCandles = candles.sublist(range.start, range.end);
    final drawingTimes = MultiChartTimeline([candles], timeframe).timestamps;
    final legacyCoordinates = DrawingCoordinates(
        timestamps: drawingTimes,
        start: 0,
        end: candles.length,
        slots: candles.length,
        scale: ChartPriceScale(candles, legacy: true));
    final anchoredDrawings = drawingAnnotations
        .map((d) => d.anchored ? d : legacyCoordinates.capture(d))
        .toList();
    if (legacyCoordinates.usable &&
        drawingAnnotations.any((d) => !d.anchored)) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted ||
            ref.read(selectedSymbolProvider) != selectedSymbol ||
            ref.read(chartTimeframeProvider) != timeframe ||
            !identical(ref.read(chartDrawingAnnotationsProvider),
                drawingAnnotations)) {
          return;
        }
        ref.read(chartDrawingAnnotationsProvider.notifier).state =
            anchoredDrawings;
      });
    }
    final drawingCoordinates = DrawingCoordinates(
        priceCandles: candles,
        timestamps: drawingTimes,
        start: range.start,
        end: range.end,
        slots: range.slots,
        scale: ChartPriceScale(visibleCandles));
    final localCrosshair = crosshair == null ||
            crosshair.candleIndex < range.start ||
            crosshair.candleIndex >= range.end
        ? null
        : ChartCrosshairSnapshot(
            x: crosshair.x,
            y: crosshair.y,
            candleIndex: crosshair.candleIndex - range.start);
    final comparisonCandleSets = comparisonEnabled
        ? ref.watch(liveComparisonCandlesProvider).valueOrNull ??
            const <String, List<CandlePoint>>{}
        : const <String, List<CandlePoint>>{};
    final multiChartCandleSets =
        ref.watch(multiChartCandlesProvider).valueOrNull ??
            const <String, List<CandlePoint>>{};
    final multiStocks = _multiChartStocks(
        watchlist, stock, multiLayout, configuredMultiSymbols);
    final groupedSeries = <String, List<List<CandlePoint>>>{};
    if (!multiLayout.isSingle) {
      for (final tileStock in multiStocks) {
        final group = multiChartTimeGroup(tileStock, timeframe);
        groupedSeries.putIfAbsent(group, () => []).add(
              tileStock.symbol == selectedSymbol
                  ? candles
                  : multiChartCandleSets[tileStock.symbol] ?? const [],
            );
      }
    }
    final multiWindows = <String, MultiChartWindow>{};
    for (final entry in groupedSeries.entries) {
      final key = '@multi-${entry.key}:${timeframe.name}';
      final view = _viewports.putIfAbsent(
          key,
          () => ref.read(appPreferencesStoreProvider).loadChartViewport(
              symbol: '@multi-${entry.key}', timeframe: timeframe));
      multiWindows[entry.key] =
          MultiChartTimeline(entry.value, timeframe).window(view);
    }
    void panMulti(int bars) {
      for (final entry in multiWindows.entries) {
        _updateViewport(
            '@multi-${entry.key}:${timeframe.name}',
            entry.value.viewport
                .panTimestamps(entry.value.timeline.timestamps, bars));
      }
    }

    void zoomMulti(double factor, double anchor) {
      for (final entry in multiWindows.entries) {
        _updateViewport(
            '@multi-${entry.key}:${timeframe.name}',
            entry.value.viewport.zoomTimestamps(
                entry.value.timeline.timestamps, factor,
                anchor: anchor));
      }
    }

    final multiNavigation = multiWindows[multiChartTimeGroup(stock, timeframe)];
    final navigationView = multiNavigation?.viewport ?? viewport;
    final canGoBack = multiLayout.isSingle
        ? range.start > 0
        : multiWindows.values.any((window) => window.range.start > 0);
    final canGoForward = multiLayout.isSingle
        ? range.end < candles.length
        : multiWindows.values.any(
            (window) => window.range.end < window.timeline.timestamps.length);
    final hasNavigationData = multiLayout.isSingle
        ? candles.isNotEmpty
        : multiWindows.values
            .any((window) => window.timeline.timestamps.isNotEmpty);
    void panNavigation(int bars) => multiLayout.isSingle
        ? _updateViewport(viewportKey, viewport.pan(candles, bars))
        : panMulti(bars);
    void zoomNavigation(double factor) => multiLayout.isSingle
        ? _updateViewport(viewportKey, viewport.zoom(candles, factor))
        : zoomMulti(factor, 1);
    final drawings = [
      ...anchoredDrawings,
      if (draftDrawing != null) draftDrawing,
    ];
    final color = stock.rising ? VosseColors.up : VosseColors.down;
    return Column(
      children: [
        StockHeader(
            stock: stock, color: color, showActions: widget.showHeaderActions),
        if (_diagnostics) const ChartQuoteTape(),
        const VosseChartToolbar(),
        if (multiLayout.isSingle && selectedDrawingIndex != null)
          const DrawingSelectionToolbar(),
        if (_diagnostics) const ChartStatusBar(),
        Expanded(
          child: Container(
            color: VosseColors.bgApp,
            child: LayoutBuilder(
              builder: (context, constraints) {
                if (!multiLayout.isSingle) {
                  return _MultiChartGrid(
                    layout: multiLayout,
                    stocks: multiStocks,
                    candidateStocks: _multiChartCandidates(watchlist, stock),
                    onStockSelected: (index, nextStock) {
                      _setMultiChartStock(ref, multiStocks, index, nextStock);
                    },
                    onStockActivated: (nextStock) {
                      if (nextStock.symbol == selectedSymbol) {
                        _showChartPanelFeedback(
                          context,
                          '${nextStock.name} 차트가 이미 기준입니다.',
                        );
                        return;
                      }
                      ref.read(selectedSymbolProvider.notifier).state =
                          nextStock.symbol;
                      _showChartPanelFeedback(
                        context,
                        '${nextStock.name} 차트를 기준 종목으로 전환했습니다.',
                      );
                    },
                    selectedSymbol: selectedSymbol,
                    selectedCandles: candles,
                    candleSets: multiChartCandleSets,
                    renderMode: renderMode,
                    indicators: indicators,
                    volumeVisible: volumeVisible,
                    timeframe: timeframe,
                    windows: multiWindows,
                    drawingSets: {
                      for (final s in multiStocks)
                        s.symbol: s.symbol == selectedSymbol
                            ? anchoredDrawings
                            : ref
                                .read(appPreferencesStoreProvider)
                                .loadDrawingAnnotations(
                                    symbol: s.symbol, timeframe: timeframe),
                    },
                    onDrawingsChanged: (symbol, next) async {
                      // Capture the tile scope before awaiting storage or changing focus.
                      if (symbol == ref.read(selectedSymbolProvider)) {
                        ref
                            .read(chartDrawingAnnotationsProvider.notifier)
                            .state = next;
                      }
                      try {
                        await ref
                            .read(appPreferencesStoreProvider)
                            .saveDrawingAnnotations(
                                symbol: symbol,
                                timeframe: timeframe,
                                drawings: next);
                        if (mounted) setState(() {});
                      } catch (_) {
                        if (context.mounted) {
                          _showChartPanelFeedback(
                              context, '드로잉 저장에 실패했습니다. 다시 시도해 주세요.');
                        }
                      }
                    },
                    onPan: panMulti,
                    onZoom: zoomMulti,
                    hover: _multiHover,
                    onHover: (next) {
                      if (_multiHover != next) {
                        setState(() => _multiHover = next);
                      }
                    },
                  );
                }
                final hasLowerIndicators =
                    indicators.contains(ChartIndicator.rsi) ||
                        indicators.contains(ChartIndicator.macd);
                final chartInputWidth = (constraints.maxWidth - chartAxisWidth)
                    .clamp(1.0, double.infinity);
                final chartInputSize = Size(
                  chartInputWidth.toDouble(),
                  constraints.maxHeight * (hasLowerIndicators ? .62 : .74),
                );
                return Stack(
                  children: [
                    Positioned.fill(
                      child: CustomPaint(
                        painter: CandleChartPainter(
                          visibleCandles,
                          priceDecimals: stock.isDomesticKisTicker ? 0 : 2,
                          history: candles.sublist(0, range.start),
                          slotCount: range.slots,
                          showLastPrice: range.end == candles.length,
                          showSummary: !_diagnostics,
                          renderMode: renderMode,
                          indicators: indicators,
                          drawingEnabled: drawingEnabled,
                          drawingTool: drawingTool,
                          drawings:
                              drawings.map(drawingCoordinates.project).toList(),
                          selectedDrawingIndex: selectedDrawingIndex,
                          crosshair: localCrosshair,
                          comparisonEnabled: comparisonEnabled,
                          comparisonLabels: comparisonLabels,
                          comparisonCandleSets: comparisonCandleSets,
                          volumeVisible: volumeVisible,
                        ),
                        child: const SizedBox.expand(),
                      ),
                    ),
                    if (drawingEnabled && drawingTool != ChartDrawingTool.none)
                      Positioned(
                        left: 0,
                        top: 0,
                        width: chartInputSize.width,
                        height: chartInputSize.height,
                        child: _DrawingInputLayer(
                          tool: drawingTool,
                          size: chartInputSize,
                          coordinates: drawingCoordinates,
                        ),
                      ),
                    if ((!drawingEnabled ||
                            drawingTool == ChartDrawingTool.none) &&
                        drawingAnnotations.isNotEmpty)
                      Positioned(
                        left: 0,
                        top: 0,
                        width: chartInputSize.width,
                        height: chartInputSize.height,
                        child: _DrawingSelectionLayer(
                          drawings: anchoredDrawings
                              .map(drawingCoordinates.project)
                              .toList(),
                          size: chartInputSize,
                          coordinates: drawingCoordinates,
                          onPan: (bars) => _updateViewport(
                              viewportKey, viewport.pan(candles, bars)),
                          onZoom: (factor, anchor) => _updateViewport(
                              viewportKey,
                              viewport.zoom(candles, factor, anchor: anchor)),
                        ),
                      ),
                    if ((!drawingEnabled ||
                            drawingTool == ChartDrawingTool.none) &&
                        drawingAnnotations.isEmpty)
                      Positioned(
                        left: 0,
                        top: 0,
                        width: chartInputSize.width,
                        height: chartInputSize.height,
                        child: _CrosshairInputLayer(
                          size: chartInputSize,
                          candleCount: visibleCandles.length,
                          indexOffset: range.start,
                          slotCount: range.slots,
                          onPan: navigable
                              ? (bars) => _updateViewport(
                                  viewportKey, viewport.pan(candles, bars))
                              : null,
                          onZoom: navigable
                              ? (factor, anchor) => _updateViewport(
                                  viewportKey,
                                  viewport.zoom(candles, factor,
                                      anchor: anchor))
                              : null,
                        ),
                      ),
                    if (comparisonEnabled && comparisonLabels.isNotEmpty)
                      Positioned(
                        left: 12,
                        top: 42,
                        child: _ComparisonLegendOverlay(
                          labels: comparisonLabels,
                          hiddenSymbols: hiddenComparisonSymbols,
                        ),
                      ),
                    if (candles.isEmpty)
                      Positioned.fill(
                        child: ColoredBox(
                          color: VosseColors.bgApp,
                          child: Center(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                    candleState.isLoading
                                        ? Icons.hourglass_top
                                        : Icons.info_outline,
                                    color: VosseColors.textMuted),
                                const SizedBox(height: 12),
                                Text(
                                  candleState.isLoading
                                      ? '${stock.name} 차트 불러오는 중'
                                      : candleState.hasError
                                          ? '${stock.name} 차트를 불러오지 못했습니다.'
                                          : '${stock.name} 표시할 캔들이 없습니다.',
                                ),
                                if (!candleState.isLoading)
                                  TextButton.icon(
                                    onPressed: () =>
                                        ref.invalidate(liveCandleProvider),
                                    icon: const Icon(Icons.refresh),
                                    label: const Text('차트 다시 불러오기'),
                                  ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    if (_diagnostics &&
                        constraints.maxWidth >= 760 &&
                        constraints.maxHeight >= 300)
                      const Positioned(
                        right: 86,
                        top: 10,
                        child: _RealtimeCandleHud(),
                      ),
                  ],
                );
              },
            ),
          ),
        ),
        if (_diagnostics) const ChartStatusBar(bottom: true),
        IconButtonTheme(
          data: IconButtonThemeData(
              style: IconButton.styleFrom(
                  minimumSize: const Size(32, 32),
                  maximumSize: const Size(32, 32),
                  padding: EdgeInsets.zero)),
          child: SizedBox(
            height: 36,
            child: Row(children: [
              if (widget.allowDiagnostics)
                IconButton(
                  tooltip: _diagnostics ? '차트 진단 닫기' : '차트 진단',
                  icon: Icon(Icons.monitor_heart_outlined,
                      size: 17,
                      color: _diagnostics
                          ? VosseColors.accent
                          : VosseColors.textMuted),
                  onPressed: () => setState(() => _diagnostics = !_diagnostics),
                ),
              if (!_diagnostics)
                const Expanded(child: ChartConnectionSummary()),
              if (_diagnostics) const Spacer(),
              if (widget.onToggleInfo != null)
                IconButton(
                    tooltip: widget.infoVisible ? '정보 패널 숨기기' : '정보 패널 열기',
                    icon: Icon(Icons.view_sidebar_outlined,
                        size: 18,
                        color: widget.infoVisible
                            ? VosseColors.accent
                            : VosseColors.textMuted),
                    onPressed: widget.onToggleInfo),
              if (navigable || !multiLayout.isSingle) ...[
                IconButton(
                    tooltip: '이전 구간',
                    icon: const Icon(Icons.chevron_left, size: 18),
                    onPressed: !canGoBack
                        ? null
                        : () => panNavigation(-(navigationView.capacity ~/ 3))),
                IconButton(
                    tooltip: '축소',
                    icon: const Icon(Icons.remove, size: 18),
                    onPressed:
                        !hasNavigationData || navigationView.capacity >= 600
                            ? null
                            : () => zoomNavigation(1.25)),
                IconButton(
                    tooltip: '확대',
                    icon: const Icon(Icons.add, size: 18),
                    onPressed:
                        !hasNavigationData || navigationView.capacity <= 20
                            ? null
                            : () => zoomNavigation(.8)),
                IconButton(
                    tooltip: '다음 구간',
                    icon: const Icon(Icons.chevron_right, size: 18),
                    onPressed: !canGoForward
                        ? null
                        : () => panNavigation(navigationView.capacity ~/ 3)),
                IconButton(
                    tooltip: '최신 봉으로',
                    icon: Icon(Icons.last_page,
                        size: 18,
                        color: !canGoForward ? VosseColors.accent : null),
                    onPressed: !hasNavigationData
                        ? null
                        : () {
                            if (multiLayout.isSingle) {
                              _updateViewport(viewportKey, viewport.latest());
                            } else {
                              for (final entry in multiWindows.entries) {
                                _updateViewport(
                                    '@multi-${entry.key}:${timeframe.name}',
                                    entry.value.viewport.latest());
                              }
                            }
                          }),
              ],
            ]),
          ),
        ),
      ],
    );
  }

  Map<String, String> _stockLabels(
    List<MarketStock> watchlist,
    Set<String> symbols,
  ) {
    final labels = <String, String>{};
    for (final symbol in symbols) {
      labels[symbol] = symbol;
      for (final stock in watchlist) {
        if (stock.symbol == symbol) {
          labels[symbol] = stock.name;
          break;
        }
      }
    }
    return labels;
  }

  List<MarketStock> _multiChartStocks(
    List<MarketStock> watchlist,
    MarketStock selected,
    ChartMultiLayout layout,
    List<String> configuredSymbols,
  ) {
    final bySymbol = {
      selected.symbol: selected,
      for (final stock in watchlist) stock.symbol: stock,
    };
    final symbols = resolveChartMultiSymbols(
      selectedSymbol: selected.symbol,
      watchlistSymbols: watchlist.map((stock) => stock.symbol),
      layout: layout,
      configuredSymbols: configuredSymbols,
    );
    return [
      for (final symbol in symbols)
        if (bySymbol[symbol] != null) bySymbol[symbol]!,
    ];
  }

  List<MarketStock> _multiChartCandidates(
    List<MarketStock> watchlist,
    MarketStock selected,
  ) {
    final stocks = <MarketStock>[];
    final seen = <String>{};
    void add(MarketStock stock) {
      if (seen.add(stock.symbol)) stocks.add(stock);
    }

    add(selected);
    for (final stock in watchlist) {
      add(stock);
    }
    return stocks;
  }

  void _setMultiChartStock(
    WidgetRef ref,
    List<MarketStock> currentStocks,
    int index,
    MarketStock nextStock,
  ) {
    if (index < 0) return;
    final symbols = [for (final stock in currentStocks) stock.symbol];
    if (index < symbols.length) {
      symbols[index] = nextStock.symbol;
    } else {
      symbols.add(nextStock.symbol);
    }
    final seen = <String>{};
    ref.read(chartMultiSymbolsProvider.notifier).state = [
      for (final symbol in symbols)
        if (seen.add(symbol)) symbol,
    ];
  }

  void _showChartPanelFeedback(BuildContext context, String message) {
    final messenger = ScaffoldMessenger.maybeOf(context);
    if (messenger == null) return;
    messenger
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(message),
          duration: const Duration(milliseconds: 1400),
        ),
      );
  }
}

class _MultiChartGrid extends StatelessWidget {
  const _MultiChartGrid({
    required this.layout,
    required this.stocks,
    required this.candidateStocks,
    required this.onStockSelected,
    required this.onStockActivated,
    required this.selectedSymbol,
    required this.selectedCandles,
    required this.candleSets,
    required this.renderMode,
    required this.indicators,
    required this.volumeVisible,
    required this.timeframe,
    required this.windows,
    required this.drawingSets,
    required this.onDrawingsChanged,
    required this.onPan,
    required this.onZoom,
    required this.hover,
    required this.onHover,
  });

  final ChartMultiLayout layout;
  final List<MarketStock> stocks;
  final List<MarketStock> candidateStocks;
  final void Function(int index, MarketStock stock) onStockSelected;
  final ValueChanged<MarketStock> onStockActivated;
  final String selectedSymbol;
  final List<CandlePoint> selectedCandles;
  final Map<String, List<CandlePoint>> candleSets;
  final ChartRenderMode renderMode;
  final Set<ChartIndicator> indicators;
  final bool volumeVisible;
  final ChartTimeframe timeframe;
  final Map<String, MultiChartWindow> windows;
  final Map<String, List<ChartDrawingAnnotation>> drawingSets;
  final void Function(String, List<ChartDrawingAnnotation>) onDrawingsChanged;
  final ValueChanged<int> onPan;
  final void Function(double, double) onZoom;
  final (String, String)? hover;
  final ValueChanged<(String, String)?> onHover;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final tileWidth = constraints.maxWidth / layout.columns;
        final tileHeight = constraints.maxHeight / layout.rows;
        final aspectRatio =
            tileHeight <= 0 ? 1.0 : (tileWidth / tileHeight).clamp(.45, 3.0);
        return GridView.builder(
          key: ValueKey('multi-chart-grid-${layout.name}'),
          padding: EdgeInsets.zero,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: layout.tileCount,
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: layout.columns,
            childAspectRatio: aspectRatio.toDouble(),
            crossAxisSpacing: 1,
            mainAxisSpacing: 1,
          ),
          itemBuilder: (context, index) {
            if (index >= stocks.length) {
              return _EmptyMultiChartTile(
                slotIndex: index,
                candidateStocks: candidateStocks,
                onStockSelected: (nextStock) {
                  onStockSelected(index, nextStock);
                },
              );
            }
            final stock = stocks[index];
            final tileCandles = stock.symbol == selectedSymbol
                ? selectedCandles
                // Why: a missing secondary symbol fetch must not reuse the
                // active symbol chart; that makes failed U.S. tiles look real.
                : candleSets[stock.symbol] ?? const <CandlePoint>[];
            final group = multiChartTimeGroup(stock, timeframe);
            final window = windows[group]!;
            final series = window.project(tileCandles);
            final coordinates = DrawingCoordinates(
                priceCandles: tileCandles,
                timestamps: window.timeline.timestamps,
                start: window.range.start,
                end: window.range.end,
                slots: window.range.slots,
                scale: ChartPriceScale(series.candles));
            final legacy = DrawingCoordinates(
                timestamps:
                    MultiChartTimeline([tileCandles], timeframe).timestamps,
                start: 0,
                end: tileCandles.length,
                slots: tileCandles.length,
                scale: ChartPriceScale(tileCandles, legacy: true));
            final hoverIndex =
                hover?.$1 == group ? window.timestamps.indexOf(hover!.$2) : -1;
            return _MultiChartTile(
              key: ValueKey('drawing-scope-${stock.symbol}-${timeframe.name}'),
              coordinates: coordinates,
              onDrawingsChanged: (next) =>
                  onDrawingsChanged(stock.symbol, next),
              slotIndex: index,
              stock: stock,
              candidateStocks: candidateStocks,
              onStockSelected: (nextStock) {
                onStockSelected(index, nextStock);
              },
              onStockActivated: onStockActivated,
              candles: series.candles,
              history: series.history,
              drawings: (drawingSets[stock.symbol] ??
                      const <ChartDrawingAnnotation>[])
                  .map((d) => d.anchored ? d : legacy.capture(d))
                  .toList(),
              candleSlots: series.slots,
              window: window,
              showLastPrice: series.showLastPrice,
              hoverSlot: hoverIndex < 0
                  ? null
                  : hoverIndex + window.range.slots - window.timestamps.length,
              onPan: onPan,
              onZoom: onZoom,
              onSlotHover: (slot) {
                final index = slot == null
                    ? -1
                    : slot - (window.range.slots - window.timestamps.length);
                onHover(index < 0 || index >= window.timestamps.length
                    ? null
                    : (group, window.timestamps[index]));
              },
              selected: stock.symbol == selectedSymbol,
              renderMode: renderMode,
              indicators: _compactIndicators(indicators, tileHeight),
              volumeVisible: volumeVisible,
            );
          },
        );
      },
    );
  }

  Set<ChartIndicator> _compactIndicators(
    Set<ChartIndicator> source,
    double tileHeight,
  ) {
    if (tileHeight >= 260) return source;
    // Why: RSI/MACD lower panes make dense multi-chart tiles unreadable.
    return source
        .where(
          (indicator) =>
              indicator == ChartIndicator.ema ||
              indicator == ChartIndicator.bollinger,
        )
        .toSet();
  }
}

class _MultiChartTile extends ConsumerStatefulWidget {
  const _MultiChartTile({
    super.key,
    required this.coordinates,
    required this.onDrawingsChanged,
    required this.slotIndex,
    required this.stock,
    required this.candidateStocks,
    required this.onStockSelected,
    required this.onStockActivated,
    required this.candles,
    required this.history,
    required this.drawings,
    required this.candleSlots,
    required this.window,
    required this.showLastPrice,
    required this.hoverSlot,
    required this.onPan,
    required this.onZoom,
    required this.onSlotHover,
    required this.selected,
    required this.renderMode,
    required this.indicators,
    required this.volumeVisible,
  });

  final DrawingCoordinates coordinates;
  final ValueChanged<List<ChartDrawingAnnotation>> onDrawingsChanged;
  final int slotIndex;
  final MarketStock stock;
  final List<MarketStock> candidateStocks;
  final ValueChanged<MarketStock> onStockSelected;
  final ValueChanged<MarketStock> onStockActivated;
  final List<CandlePoint> candles;
  final List<CandlePoint> history;
  final List<ChartDrawingAnnotation> drawings;
  final List<int> candleSlots;
  final MultiChartWindow window;
  final bool showLastPrice;
  final int? hoverSlot;
  final ValueChanged<int> onPan;
  final void Function(double, double) onZoom;
  final ValueChanged<int?> onSlotHover;
  final bool selected;
  final ChartRenderMode renderMode;
  final Set<ChartIndicator> indicators;
  final bool volumeVisible;

  @override
  ConsumerState<_MultiChartTile> createState() => _MultiChartTileState();
}

class _MultiChartTileState extends ConsumerState<_MultiChartTile> {
  ChartDrawingTool? _tool;
  ChartDrawingAnnotation? _draft;
  int? _selectedIndex;

  void _change(List<ChartDrawingAnnotation> next) {
    widget.onDrawingsChanged(next);
  }

  void _chooseTool(ChartDrawingTool tool) {
    setState(() {
      _tool = tool;
      _draft = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    final globalTool = ref.watch(chartDrawingEnabledProvider)
        ? ref.watch(chartDrawingToolProvider)
        : ChartDrawingTool.none;
    ref.listen(chartDrawingToolProvider, (_, next) {
      setState(() {
        _tool = null;
        _draft = null;
      });
    });
    final tool = _tool ?? globalTool;
    final projected = widget.drawings.map(widget.coordinates.project).toList();
    final color = widget.stock.rising ? VosseColors.up : VosseColors.down;
    return Semantics(
      button: true,
      selected: widget.selected,
      label: '멀티차트 ${widget.slotIndex + 1}번 ${widget.stock.name}',
      child: GestureDetector(
        key: ValueKey('multi-chart-tile-${widget.stock.symbol}'),
        behavior: HitTestBehavior.opaque,
        onTap: () => widget.onStockActivated(widget.stock),
        child: DecoratedBox(
          decoration: BoxDecoration(
            color: VosseColors.bgApp,
            border: Border.all(
              color:
                  widget.selected ? VosseColors.up : VosseColors.borderSubtle,
              width: widget.selected ? 1.2 : 1,
            ),
          ),
          child: Column(
            children: [
              Tooltip(
                message: widget.selected
                    ? '현재 기준 차트'
                    : '${widget.stock.name}을 기준 차트로 전환',
                waitDuration: const Duration(milliseconds: 250),
                child: Container(
                  height: 30,
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  decoration: BoxDecoration(
                    color: widget.selected
                        ? VosseColors.up.withValues(alpha: .07)
                        : const Color(0xFF0B0C10),
                    border: const Border(
                      bottom: BorderSide(color: VosseColors.borderSubtle),
                    ),
                  ),
                  child: Row(
                    children: [
                      StockAvatar(
                        label: widget.stock.name,
                        logoUrl: widget.stock.logoUrl,
                        size: 18,
                      ),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          widget.stock.name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: VosseColors.textPrimary,
                            fontSize: 12,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        stockPriceText(widget.stock),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: color,
                          fontSize: 11,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      const SizedBox(width: 6),
                      Text(
                        widget.stock.displayPrice > 0
                            ? percentText(widget.stock.changePercent)
                            : '--',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: color,
                          fontSize: 10.5,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      SizedBox(
                        width: 26,
                        height: 28,
                        child: PopupMenuButton<String>(
                          key: ValueKey(
                              'multi-drawing-menu-${widget.stock.symbol}'),
                          tooltip: '${widget.stock.name} 드로잉',
                          padding: EdgeInsets.zero,
                          iconSize: 15,
                          icon: Icon(Icons.draw_outlined,
                              color: tool == ChartDrawingTool.none
                                  ? VosseColors.textMuted
                                  : VosseColors.up),
                          onSelected: (value) {
                            if (value == 'delete') {
                              _change([
                                for (var i = 0; i < widget.drawings.length; i++)
                                  if (i != _selectedIndex) widget.drawings[i]
                              ]);
                              setState(() => _selectedIndex = null);
                            } else {
                              _chooseTool(
                                  ChartDrawingTool.values.byName(value));
                            }
                          },
                          itemBuilder: (_) => [
                            for (final option in ChartDrawingTool.values)
                              CheckedPopupMenuItem(
                                  value: option.name,
                                  checked: tool == option,
                                  enabled: option == ChartDrawingTool.none ||
                                      (widget.candles.isNotEmpty &&
                                          widget.coordinates.usable),
                                  child: Text(option == ChartDrawingTool.none
                                      ? '선택 · 이동'
                                      : option.label)),
                            const PopupMenuDivider(),
                            PopupMenuItem(
                                value: 'delete',
                                enabled: _selectedIndex != null &&
                                    _selectedIndex! < widget.drawings.length,
                                child: const Text('선택 드로잉 삭제')),
                          ],
                        ),
                      ),
                      const SizedBox(width: 2),
                      SizedBox(
                        width: 24,
                        child: _MultiChartStockMenuButton(
                          slotIndex: widget.slotIndex,
                          selectedStock: widget.stock,
                          candidateStocks: widget.candidateStocks,
                          onStockSelected: widget.onStockSelected,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Expanded(
                child: LayoutBuilder(
                  builder: (context, constraints) {
                    final inputWidth = (constraints.maxWidth - chartAxisWidth)
                        .clamp(1.0, double.infinity)
                        .toDouble();
                    final hasLowerIndicators =
                        widget.indicators.contains(ChartIndicator.rsi) ||
                            widget.indicators.contains(ChartIndicator.macd);
                    final inputHeight = constraints.maxHeight *
                        (hasLowerIndicators ? .62 : .74);
                    return Stack(
                      fit: StackFit.expand,
                      children: [
                        CustomPaint(
                          painter: CandleChartPainter(
                            widget.candles,
                            priceDecimals:
                                widget.stock.isDomesticKisTicker ? 0 : 2,
                            compact: true,
                            history: widget.history,
                            slotCount: widget.window.range.slots,
                            candleSlots: widget.candleSlots,
                            timeAxisTimestamps: widget.window.timestamps,
                            linkedCrosshairSlot: widget.hoverSlot,
                            showLastPrice: widget.showLastPrice,
                            renderMode: widget.renderMode,
                            indicators: widget.indicators,
                            drawingEnabled: tool != ChartDrawingTool.none,
                            drawingTool: tool,
                            drawings: [
                              ...projected,
                              if (_draft != null)
                                widget.coordinates.project(_draft!)
                            ],
                            selectedDrawingIndex: _selectedIndex,
                            crosshair: null,
                            comparisonEnabled: false,
                            comparisonLabels: const {},
                            comparisonCandleSets: const {},
                            volumeVisible: widget.volumeVisible,
                          ),
                          child: const SizedBox.expand(),
                        ),
                        if (widget.candles.isEmpty)
                          Center(
                            key: ValueKey(
                                'multi-chart-no-candles-${widget.stock.symbol}'),
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 10,
                                vertical: 6,
                              ),
                              decoration: BoxDecoration(
                                color: const Color(0xD9111217),
                                border: Border.all(
                                  color: VosseColors.borderSubtle,
                                ),
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Text(
                                '${widget.stock.name} 차트 데이터 없음',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  color: VosseColors.textMuted,
                                  fontSize: 11,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                            ),
                          ),
                        Positioned(
                          left: 0,
                          top: 0,
                          width: inputWidth,
                          height: inputHeight,
                          child: widget.candles.isNotEmpty &&
                                  tool != ChartDrawingTool.none
                              ? _DrawingInputLayer(
                                  key: ValueKey(tool),
                                  tool: tool,
                                  size: Size(inputWidth, inputHeight),
                                  coordinates: widget.coordinates,
                                  onDraft: (next) =>
                                      setState(() => _draft = next),
                                  onAdd: (drawing) {
                                    final next = [
                                      ...widget.drawings.take(29),
                                      drawing
                                    ];
                                    _change(next);
                                    setState(() {
                                      _selectedIndex = next.length - 1;
                                      _draft = null;
                                      _tool = ChartDrawingTool.none;
                                    });
                                  },
                                  onSlotHover: widget.onSlotHover,
                                )
                              : widget.candles.isNotEmpty &&
                                      widget.drawings.isNotEmpty
                                  ? _DrawingSelectionLayer(
                                      drawings: projected,
                                      size: Size(inputWidth, inputHeight),
                                      coordinates: widget.coordinates,
                                      selectedIndex: _selectedIndex,
                                      onSelect: (index) => setState(
                                          () => _selectedIndex = index),
                                      onUpdate: (index, drawing) {
                                        _change([
                                          for (var i = 0;
                                              i < widget.drawings.length;
                                              i++)
                                            if (i == index)
                                              drawing
                                            else
                                              widget.drawings[i]
                                        ]);
                                      },
                                      onSlotHover: widget.onSlotHover,
                                      onPan: widget.onPan,
                                      onZoom: widget.onZoom,
                                    )
                                  : _CrosshairInputLayer(
                                      size: Size(inputWidth, inputHeight),
                                      candleCount: widget.window.range.slots,
                                      slotCount: widget.window.range.slots,
                                      onPan: widget.onPan,
                                      onZoom: widget.onZoom,
                                      onSlotHover: widget.onSlotHover,
                                      onTap: () =>
                                          widget.onStockActivated(widget.stock),
                                    ),
                        ),
                      ],
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _EmptyMultiChartTile extends StatelessWidget {
  const _EmptyMultiChartTile({
    required this.slotIndex,
    required this.candidateStocks,
    required this.onStockSelected,
  });

  final int slotIndex;
  final List<MarketStock> candidateStocks;
  final ValueChanged<MarketStock> onStockSelected;

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      key: ValueKey('multi-chart-empty-slot-${slotIndex + 1}'),
      decoration: BoxDecoration(
        color: VosseColors.bgApp,
        border: Border.all(color: VosseColors.borderSubtle),
      ),
      child: Center(
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            color: const Color(0xFF111217),
            border: Border.all(color: VosseColors.borderSubtle),
            borderRadius: BorderRadius.circular(6),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              _MultiChartStockMenuButton(
                slotIndex: slotIndex,
                selectedStock: null,
                candidateStocks: candidateStocks,
                onStockSelected: onStockSelected,
                icon: const Icon(
                  Icons.add,
                  size: 17,
                  color: VosseColors.textPrimary,
                ),
              ),
              const SizedBox(width: 6),
              const Text(
                '종목 선택',
                style: TextStyle(
                  color: VosseColors.textMuted,
                  fontSize: 12,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _MultiChartStockMenuButton extends StatelessWidget {
  const _MultiChartStockMenuButton({
    required this.slotIndex,
    required this.selectedStock,
    required this.candidateStocks,
    required this.onStockSelected,
    this.icon = const Icon(
      Icons.unfold_more,
      size: 14,
      color: VosseColors.textMuted,
    ),
  });

  final int slotIndex;
  final MarketStock? selectedStock;
  final List<MarketStock> candidateStocks;
  final ValueChanged<MarketStock> onStockSelected;
  final Widget icon;

  @override
  Widget build(BuildContext context) {
    return PopupMenuButton<String>(
      tooltip: '멀티차트 ${slotIndex + 1}번 종목 선택',
      color: const Color(0xFF17181E),
      padding: EdgeInsets.zero,
      constraints: const BoxConstraints(
        minWidth: 190,
        maxWidth: 260,
      ),
      icon: icon,
      onSelected: (symbol) {
        for (final candidate in candidateStocks) {
          if (candidate.symbol == symbol) {
            onStockSelected(candidate);
            break;
          }
        }
      },
      itemBuilder: (context) {
        return [
          for (final candidate in candidateStocks)
            PopupMenuItem<String>(
              value: candidate.symbol,
              child: Row(
                children: [
                  StockAvatar(
                    label: candidate.name,
                    logoUrl: candidate.logoUrl,
                    size: 18,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      candidate.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: candidate.symbol == selectedStock?.symbol
                            ? VosseColors.up
                            : VosseColors.textPrimary,
                        fontSize: 12,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    candidate.market,
                    style: const TextStyle(
                      color: VosseColors.textMuted,
                      fontSize: 10.5,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ],
              ),
            ),
        ];
      },
    );
  }
}

class _RealtimeCandleHud extends ConsumerWidget {
  const _RealtimeCandleHud();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final timeframe = ref.watch(chartTimeframeProvider);
    final source = ref.watch(selectedCandleSourceProvider);
    final candles = ref.watch(liveCandleProvider).valueOrNull;
    final updates = ref.watch(realtimeCandleUpdateCountProvider);
    final lastTrade = ref.watch(lastRealtimeTradeTickProvider);
    final receivedAt = ref.watch(lastRealtimeCandleReceivedAtProvider);
    final now = ref.watch(realtimeCandleFreshnessClockProvider).valueOrNull ??
        DateTime.now();
    final latest = candles == null || candles.isEmpty ? null : candles.last;
    final isLive = source == MarketDataSource.kisLive && updates > 0;
    final freshness = _hudFreshnessLabel(
      source: source,
      timeframe: timeframe,
      receivedAt: receivedAt,
      now: now,
    );
    final tone = _hudTone(
      source: source,
      isLive: isLive,
      receivedAt: receivedAt,
      now: now,
    );
    final current = latest == null
        ? '실시간봉 대기'
        : '실시간봉 ${_hudCandleTime(latest.timestamp)} · '
            'C ${_hudPrice(latest.close)}';
    final trade = lastTrade == null
        ? '체결 대기'
        : '체결 ${_hudPrice(lastTrade.price)} · '
            '${_hudTradeTime(lastTrade.occurredAt)}';
    final badge = isLive ? '${source.label} · $updates회' : source.label;

    return MenuHelp(
      title: '실시간 캔들 HUD',
      description: _hudHelp(timeframe, freshness),
      placement: MenuHelpPlacement.left,
      child: TweenAnimationBuilder<double>(
        key: ValueKey('realtime-candle-hud-$updates'),
        tween: Tween<double>(begin: isLive ? 1 : 0, end: 0),
        duration: const Duration(milliseconds: 650),
        curve: Curves.easeOutCubic,
        builder: (context, pulse, _) {
          return Transform.scale(
            scale: 1 + (pulse * .018),
            child: Semantics(
              label: isLive ? '실시간 캔들 업데이트 $updates회' : '캔들 상태 ${source.label}',
              child: Container(
                width: 188,
                padding: const EdgeInsets.fromLTRB(9, 8, 9, 8),
                decoration: BoxDecoration(
                  color: Color.lerp(
                    VosseColors.bgApp.withValues(alpha: .86),
                    tone.withValues(alpha: .18),
                    pulse,
                  ),
                  border: Border.all(
                    color: tone.withValues(alpha: .38 + (pulse * .34)),
                  ),
                  borderRadius: BorderRadius.circular(6),
                  boxShadow: [
                    BoxShadow(
                      color: tone.withValues(alpha: .12 + (pulse * .24)),
                      blurRadius: 14 + (pulse * 12),
                      offset: const Offset(0, 8),
                    ),
                    BoxShadow(
                      color: Colors.black.withValues(alpha: .28),
                      blurRadius: 14,
                      offset: const Offset(0, 8),
                    ),
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 7,
                          height: 7,
                          decoration: BoxDecoration(
                            color: tone,
                            shape: BoxShape.circle,
                          ),
                        ),
                        const SizedBox(width: 6),
                        Expanded(
                          child: Text(
                            isLive ? '실시간 캔들' : '캔들 상태',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: VosseColors.textPrimary,
                              fontSize: 10.5,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ),
                        Text(
                          badge,
                          style: TextStyle(
                            color: tone,
                            fontSize: 9.5,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 5),
                    Text(
                      _hudFlowLabel(timeframe),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: VosseColors.textSecondary,
                        fontSize: 10,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      current,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: tone,
                        fontSize: 10.5,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      isLive ? '$trade · $freshness' : freshness,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: VosseColors.textMuted,
                        fontSize: 9.5,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

String _hudHelp(ChartTimeframe timeframe, String freshness) {
  if (!timeframe.isIntraday) {
    return '${timeframe.title}은 조회 캔들을 표시합니다. 분봉으로 전환하면 KIS 체결틱이 앱 내부 캔들에 반영됩니다. $freshness 상태입니다.';
  }
  if (timeframe == ChartTimeframe.minute) {
    return 'KIS 체결틱을 앱 내부 1분봉으로 바로 반영합니다. $freshness 상태입니다.';
  }
  return 'KIS 체결틱을 먼저 앱 내부 1분봉으로 만들고, 선택한 분봉에 맞춰 ${timeframe.aggregationLabel} 단위로 집계합니다. $freshness 상태입니다.';
}

String _hudFlowLabel(ChartTimeframe timeframe) {
  if (!timeframe.isIntraday) return '${timeframe.title} 조회 캔들';
  if (timeframe == ChartTimeframe.minute) return '1분 체결 캔들 갱신';
  return '1분 체결→${timeframe.aggregationLabel}봉 집계';
}

Color _hudTone({
  required MarketDataSource source,
  required bool isLive,
  required DateTime? receivedAt,
  required DateTime now,
}) {
  if (source == MarketDataSource.unavailable) return VosseColors.up;
  if (!isLive) {
    return source == MarketDataSource.kisRest
        ? VosseColors.warning
        : VosseColors.textMuted;
  }
  if (receivedAt == null) return VosseColors.warning;
  return now.difference(receivedAt).inMinutes >= 3
      ? VosseColors.warning
      : VosseColors.accent;
}

String _hudFreshnessLabel({
  required MarketDataSource source,
  required ChartTimeframe timeframe,
  required DateTime? receivedAt,
  required DateTime now,
}) {
  if (receivedAt == null) {
    if (!timeframe.isIntraday) return '조회 캔들 표시';
    if (source == MarketDataSource.kisRest) return '실시간 체결 대기';
    return '수신 확인 중';
  }
  final elapsed = now.difference(receivedAt);
  if (elapsed.inSeconds < 10) return '수신 방금';
  if (elapsed.inSeconds < 60) return '수신 ${elapsed.inSeconds}초전';
  if (elapsed.inMinutes < 3) return '수신 ${elapsed.inMinutes}분전';
  return '수신 지연 ${elapsed.inMinutes}분전';
}

String _hudCandleTime(String timestamp) {
  final parsed = parseCandleTimestamp(timestamp);
  if (parsed == null) return '최신';
  final hour = parsed.hour.toString().padLeft(2, '0');
  final minute = parsed.minute.toString().padLeft(2, '0');
  return '$hour:$minute';
}

String _hudTradeTime(DateTime value) {
  final local = value.toLocal();
  final hour = local.hour.toString().padLeft(2, '0');
  final minute = local.minute.toString().padLeft(2, '0');
  final second = local.second.toString().padLeft(2, '0');
  return '$hour:$minute:$second';
}

String _hudPrice(double value) {
  final fixed = value.toStringAsFixed(0);
  return fixed.replaceAllMapped(
    RegExp(r'\B(?=(\d{3})+(?!\d))'),
    (_) => ',',
  );
}

enum _DrawingEditHandle { start, end, horizontal }

class _DrawingEditHit {
  const _DrawingEditHit(this.index, this.handle);

  final int index;
  final _DrawingEditHandle handle;
}

class _DrawingSelectionLayer extends ConsumerStatefulWidget {
  const _DrawingSelectionLayer({
    required this.drawings,
    this.selectedIndex,
    this.onSelect,
    this.onUpdate,
    this.onSlotHover,
    required this.size,
    required this.coordinates,
    required this.onPan,
    required this.onZoom,
  });

  final int? selectedIndex;
  final ValueChanged<int?>? onSelect;
  final void Function(int, ChartDrawingAnnotation)? onUpdate;
  final ValueChanged<int?>? onSlotHover;
  final List<ChartDrawingAnnotation> drawings;
  final Size size;
  final DrawingCoordinates coordinates;
  final ValueChanged<int> onPan;
  final void Function(double, double) onZoom;

  @override
  ConsumerState<_DrawingSelectionLayer> createState() =>
      _DrawingSelectionLayerState();
}

class _DrawingSelectionLayerState
    extends ConsumerState<_DrawingSelectionLayer> {
  _DrawingEditHit? _activeEdit;
  double _dragRemainder = 0;

  void _select(int? index) {
    if (widget.onSelect != null) {
      widget.onSelect!(index);
    } else {
      selectChartDrawing(ref, index);
    }
  }

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      onHover: (event) => _setCrosshair(event.localPosition),
      onExit: (_) {
        if (widget.onSlotHover != null) {
          widget.onSlotHover!(null);
        } else {
          setChartCrosshair(ref, null);
        }
      },
      child: Listener(
        behavior: HitTestBehavior.opaque,
        onPointerSignal: (event) {
          if (event is PointerScrollEvent) {
            GestureBinding.instance.pointerSignalResolver.register(event, (_) {
              if (event.scrollDelta.dx.abs() > event.scrollDelta.dy.abs()) {
                _dragRemainder += event.scrollDelta.dx *
                    widget.coordinates.slots /
                    widget.size.width;
                final bars = _dragRemainder.truncate();
                if (bars != 0) {
                  _dragRemainder -= bars;
                  widget.onPan(bars);
                }
              } else if (event.scrollDelta.dy != 0) {
                widget.onZoom(
                    event.scrollDelta.dy > 0 ? 1.15 : 1 / 1.15,
                    (event.localPosition.dx / widget.size.width)
                        .clamp(0.0, 1.0));
              }
            });
          }
        },
        child: GestureDetector(
          key: const ValueKey('chart-drawing-selection'),
          dragStartBehavior: DragStartBehavior.down,
          behavior: HitTestBehavior.translucent,
          onTapDown: (details) {
            final point = _normalise(details.localPosition);
            _setCrosshair(details.localPosition);
            _select(_hitTest(point));
          },
          onPanDown: (details) {
            _dragRemainder = 0;
            final point = _normalise(details.localPosition);
            _setCrosshair(details.localPosition);
            final hit = _editHitTest(point);
            _activeEdit = hit;
            _select(hit?.index ?? _hitTest(point));
          },
          onPanStart: (details) {
            if (_activeEdit != null) return;
            final point = _normalise(details.localPosition);
            final hit = _editHitTest(point);
            _activeEdit = hit;
            _select(hit?.index ?? _hitTest(point));
          },
          onPanUpdate: (details) {
            final activeEdit = _activeEdit;
            if (activeEdit == null) {
              _dragRemainder -= details.delta.dx *
                  widget.coordinates.slots /
                  widget.size.width;
              final bars = _dragRemainder.truncate();
              if (bars != 0) {
                _dragRemainder -= bars;
                widget.onPan(bars);
              }
              return;
            }
            final point = _normalise(details.localPosition);
            _setCrosshair(details.localPosition);
            final drawings = widget.drawings;
            if (activeEdit.index < 0 || activeEdit.index >= drawings.length) {
              return;
            }
            final updated = widget.coordinates.capture(_updatedDrawing(
                widget.drawings[activeEdit.index], activeEdit.handle, point));
            if (widget.onUpdate != null) {
              widget.onUpdate!(activeEdit.index, updated);
            } else {
              updateChartDrawing(ref, activeEdit.index, updated);
            }
          },
          onPanEnd: (_) => _activeEdit = null,
          onPanCancel: () => _activeEdit = null,
          child: const SizedBox.expand(),
        ),
      ),
    );
  }

  Offset _normalise(Offset localPosition) {
    final dx = (localPosition.dx / widget.size.width).clamp(0.0, 1.0);
    final dy = (localPosition.dy / widget.size.height).clamp(0.0, 1.0);
    if (ref.read(chartDrawingSnapProvider)) {
      final snapped = widget.coordinates.snap(dx, dy);
      return Offset(snapped.x, snapped.y);
    }
    return Offset(dx, dy);
  }

  void _setCrosshair(Offset localPosition) {
    final point = _normalise(localPosition);
    if (widget.onSlotHover != null) {
      widget.onSlotHover!((point.dx * widget.coordinates.slots)
          .floor()
          .clamp(0, widget.coordinates.slots - 1));
      return;
    }
    final candleIndex = widget.coordinates.candleIndex(point.dx);
    setChartCrosshair(
      ref,
      candleIndex == null
          ? null
          : ChartCrosshairSnapshot(
              x: point.dx,
              y: point.dy,
              candleIndex: candleIndex,
            ),
    );
  }

  int? _hitTest(Offset point) {
    for (var i = widget.drawings.length - 1; i >= 0; i -= 1) {
      if (_contains(widget.drawings[i], point)) return i;
    }
    return null;
  }

  _DrawingEditHit? _editHitTest(Offset point) {
    for (var i = widget.drawings.length - 1; i >= 0; i -= 1) {
      final drawing = widget.drawings[i];
      if (drawing.hidden || drawing.locked) continue;
      if (drawing.tool == ChartDrawingTool.text && _contains(drawing, point)) {
        return _DrawingEditHit(i, _DrawingEditHandle.end);
      }
      if (drawing.tool == ChartDrawingTool.horizontal &&
          (point.dy - drawing.endY).abs() <= .035) {
        return _DrawingEditHit(i, _DrawingEditHandle.horizontal);
      }
      if (_nearPoint(point, Offset(drawing.startX, drawing.startY))) {
        return _DrawingEditHit(i, _DrawingEditHandle.start);
      }
      if (_nearPoint(point, Offset(drawing.endX, drawing.endY))) {
        return _DrawingEditHit(i, _DrawingEditHandle.end);
      }
    }
    final selectedIndex = widget.onSelect != null
        ? widget.selectedIndex
        : ref.read(chartSelectedDrawingIndexProvider);
    if (selectedIndex != null &&
        selectedIndex >= 0 &&
        selectedIndex < widget.drawings.length) {
      final selected = widget.drawings[selectedIndex];
      if (!selected.locked && !selected.hidden && _contains(selected, point)) {
        final startDistance =
            (point - Offset(selected.startX, selected.startY)).distance;
        final endDistance =
            (point - Offset(selected.endX, selected.endY)).distance;
        return _DrawingEditHit(
          selectedIndex,
          startDistance <= endDistance
              ? _DrawingEditHandle.start
              : _DrawingEditHandle.end,
        );
      }
    }
    return null;
  }

  ChartDrawingAnnotation _updatedDrawing(
    ChartDrawingAnnotation drawing,
    _DrawingEditHandle handle,
    Offset point,
  ) {
    return switch (handle) {
      _DrawingEditHandle.start => drawing.copyWith(
          startX: point.dx,
          startY: point.dy,
        ),
      _DrawingEditHandle.end => drawing.copyWith(
          endX: point.dx,
          endY: point.dy,
        ),
      _DrawingEditHandle.horizontal => drawing.copyWith(
          startY: point.dy,
          endY: point.dy,
        ),
    };
  }

  bool _contains(ChartDrawingAnnotation drawing, Offset point) {
    if (drawing.hidden) return false;
    return switch (drawing.tool) {
      ChartDrawingTool.none => false,
      ChartDrawingTool.trend => _nearSegment(
          point,
          Offset(drawing.startX, drawing.startY),
          Offset(drawing.endX, drawing.endY),
        ),
      ChartDrawingTool.horizontal => (point.dy - drawing.endY).abs() <= .025,
      ChartDrawingTool.fibonacci => _nearFibLevel(drawing, point),
      ChartDrawingTool.vertical => (point.dx - drawing.startX).abs() <= .02,
      ChartDrawingTool.text =>
        (point - Offset(drawing.endX, drawing.endY)).distance < .05,
      ChartDrawingTool.rectangle || ChartDrawingTool.range => _nearSegment(
              point,
              Offset(drawing.startX, drawing.startY),
              Offset(drawing.endX, drawing.startY)) ||
          _nearSegment(point, Offset(drawing.startX, drawing.endY),
              Offset(drawing.endX, drawing.endY)) ||
          _nearSegment(point, Offset(drawing.startX, drawing.startY),
              Offset(drawing.startX, drawing.endY)) ||
          _nearSegment(point, Offset(drawing.endX, drawing.startY),
              Offset(drawing.endX, drawing.endY)),
      ChartDrawingTool.channel => _nearSegment(
              point,
              Offset(drawing.startX, drawing.startY),
              Offset(drawing.endX, drawing.endY)) ||
          _nearSegment(
              point,
              Offset(
                  drawing.startX,
                  drawing.startY -
                      drawing.channelOffset / widget.coordinates.scale.span),
              Offset(
                  drawing.endX,
                  drawing.endY -
                      drawing.channelOffset / widget.coordinates.scale.span)),
    };
  }

  bool _nearFibLevel(ChartDrawingAnnotation drawing, Offset point) {
    final left = drawing.startX < drawing.endX ? drawing.startX : drawing.endX;
    final right = drawing.startX > drawing.endX ? drawing.startX : drawing.endX;
    final top = drawing.startY < drawing.endY ? drawing.startY : drawing.endY;
    final bottom =
        drawing.startY > drawing.endY ? drawing.startY : drawing.endY;
    final fullWidth = (right - left).abs() < .04;
    if (!fullWidth && (point.dx < left - .02 || point.dx > right + .02)) {
      return false;
    }
    const levels = [0.0, .236, .382, .5, .618, .786, 1.0];
    for (final level in levels) {
      final y = top + (bottom - top) * level;
      if ((point.dy - y).abs() <= .025) return true;
    }
    return false;
  }

  bool _nearSegment(Offset point, Offset start, Offset end) {
    final dx = end.dx - start.dx;
    final dy = end.dy - start.dy;
    final lengthSquared = dx * dx + dy * dy;
    if (lengthSquared <= .0001) {
      return (point - start).distance <= .025;
    }
    final rawT = ((point.dx - start.dx) * dx + (point.dy - start.dy) * dy) /
        lengthSquared;
    final t = rawT.clamp(0.0, 1.0);
    final closest = Offset(start.dx + dx * t, start.dy + dy * t);
    return (point - closest).distance <= .025;
  }

  bool _nearPoint(Offset point, Offset target) {
    return (point - target).distance <= .04;
  }
}

class _DrawingInputLayer extends ConsumerStatefulWidget {
  const _DrawingInputLayer({
    super.key,
    this.onAdd,
    this.onDraft,
    this.onSlotHover,
    required this.tool,
    required this.size,
    required this.coordinates,
  });

  final ValueChanged<ChartDrawingAnnotation>? onAdd;
  final ValueChanged<ChartDrawingAnnotation?>? onDraft;
  final ValueChanged<int?>? onSlotHover;
  final ChartDrawingTool tool;
  final Size size;
  final DrawingCoordinates coordinates;

  @override
  ConsumerState<_DrawingInputLayer> createState() => _DrawingInputLayerState();
}

class _DrawingInputLayerState extends ConsumerState<_DrawingInputLayer> {
  bool get _singlePoint =>
      widget.tool == ChartDrawingTool.horizontal ||
      widget.tool == ChartDrawingTool.vertical ||
      widget.tool == ChartDrawingTool.text;
  Offset? _start;
  ChartDrawingAnnotation? _draft;

  void _setDraft(ChartDrawingAnnotation? next) {
    _draft = next;
    if (widget.onDraft != null) {
      widget.onDraft!(next);
    } else {
      ref.read(chartDraftDrawingProvider.notifier).state = next;
    }
  }

  void _add(ChartDrawingAnnotation drawing) {
    if (widget.onAdd != null) {
      widget.onAdd!(drawing);
    } else {
      addChartDrawing(ref, drawing);
    }
  }

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      cursor: SystemMouseCursors.precise,
      onHover: (event) => _setCrosshair(event.localPosition),
      onExit: (_) {
        if (widget.onSlotHover != null) {
          widget.onSlotHover!(null);
        } else {
          setChartCrosshair(ref, null);
        }
      },
      child: GestureDetector(
        key: const ValueKey('chart-drawing-input'),
        dragStartBehavior: DragStartBehavior.down,
        behavior: HitTestBehavior.translucent,
        onTapDown: _singlePoint
            ? (details) {
                final point = _normalise(details.localPosition);
                _setCrosshair(details.localPosition);
                final annotation = _annotationFor(point, point);
                if (widget.coordinates.usable) _add(annotation);
              }
            : null,
        onPanDown: _singlePoint
            ? null
            : (details) {
                // Keep the actual mouse-down anchor, even if a fast drag
                // crosses the gesture threshold in a single movement.
                _start = _normalise(details.localPosition);
              },
        onPanStart: _singlePoint
            ? null
            : (details) {
                _start ??= _normalise(details.localPosition);
                _setCrosshair(details.localPosition);
                _setDraft(
                    _annotationFor(_start!, _normalise(details.localPosition)));
              },
        onPanUpdate: _singlePoint
            ? null
            : (details) {
                final start = _start;
                if (start == null) return;
                final end = _normalise(details.localPosition);
                _setCrosshair(details.localPosition);
                _setDraft(_annotationFor(start, end));
              },
        onPanEnd: _singlePoint
            ? null
            : (_) {
                final draft = _draft;
                if (draft != null &&
                    widget.coordinates.usable &&
                    _hasMeaningfulDistance(draft)) {
                  _add(draft);
                }
                _start = null;
                _setDraft(null);
              },
        onPanCancel: () {
          _start = null;
          _setDraft(null);
        },
        child: const SizedBox.expand(),
      ),
    );
  }

  Offset _normalise(Offset localPosition) {
    final dx = (localPosition.dx / widget.size.width).clamp(0.0, 1.0);
    final dy = (localPosition.dy / widget.size.height).clamp(0.0, 1.0);
    if (ref.read(chartDrawingSnapProvider)) {
      final point = widget.coordinates.snap(dx, dy);
      return Offset(point.x, point.y);
    }
    return Offset(dx, dy);
  }

  void _setCrosshair(Offset localPosition) {
    final point = _normalise(localPosition);
    if (widget.onSlotHover != null) {
      widget.onSlotHover!((point.dx * widget.coordinates.slots)
          .floor()
          .clamp(0, widget.coordinates.slots - 1));
      return;
    }
    final candleIndex = widget.coordinates.candleIndex(point.dx);
    setChartCrosshair(
      ref,
      candleIndex == null
          ? null
          : ChartCrosshairSnapshot(
              x: point.dx,
              y: point.dy,
              candleIndex: candleIndex,
            ),
    );
  }

  ChartDrawingAnnotation _annotationFor(Offset start, Offset end) {
    if (widget.tool == ChartDrawingTool.horizontal) {
      return widget.coordinates.capture(ChartDrawingAnnotation(
        tool: widget.tool,
        startX: 0,
        startY: end.dy,
        endX: 1,
        endY: end.dy,
      ));
    }
    final captured = widget.coordinates.capture(ChartDrawingAnnotation(
      tool: widget.tool,
      label: widget.tool == ChartDrawingTool.text ? '메모' : '',
      startX: start.dx,
      startY: start.dy,
      endX: end.dx,
      endY: end.dy,
    ));
    if (widget.tool == ChartDrawingTool.channel && captured.anchored) {
      final delta = (captured.endPrice! - captured.startPrice!).abs();
      return captured.copyWith(
          channelOffset: delta > 0 ? delta * .4 : captured.startPrice! * .01);
    }
    return captured;
  }

  bool _hasMeaningfulDistance(ChartDrawingAnnotation annotation) {
    return (annotation.startX - annotation.endX).abs() > .015 ||
        (annotation.startY - annotation.endY).abs() > .015;
  }
}

class _CrosshairInputLayer extends ConsumerStatefulWidget {
  const _CrosshairInputLayer({
    required this.size,
    required this.candleCount,
    this.indexOffset = 0,
    this.slotCount,
    this.onPan,
    this.onZoom,
    this.onSlotHover,
    this.onTap,
  });

  final Size size;
  final int candleCount;
  final int indexOffset;
  final int? slotCount;
  final ValueChanged<int>? onPan;
  final void Function(double factor, double anchor)? onZoom;
  final ValueChanged<int?>? onSlotHover;
  final VoidCallback? onTap;

  @override
  ConsumerState<_CrosshairInputLayer> createState() =>
      _CrosshairInputLayerState();
}

class _CrosshairInputLayerState extends ConsumerState<_CrosshairInputLayer> {
  double _dragRemainder = 0;

  void _clearCrosshair() {
    if (widget.onSlotHover != null) {
      widget.onSlotHover!(null);
    } else {
      setChartCrosshair(ref, null);
    }
  }

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      cursor: widget.onPan == null
          ? SystemMouseCursors.precise
          : SystemMouseCursors.grab,
      onHover: (event) => _setCrosshair(ref, event.localPosition),
      onExit: (_) => _clearCrosshair(),
      child: Listener(
        behavior: HitTestBehavior.opaque,
        onPointerSignal: (event) {
          if (event is PointerScrollEvent && widget.onZoom != null) {
            GestureBinding.instance.pointerSignalResolver.register(event, (_) {
              if (event.scrollDelta.dx.abs() > event.scrollDelta.dy.abs()) {
                _dragRemainder += event.scrollDelta.dx *
                    (widget.slotCount ?? widget.candleCount) /
                    widget.size.width;
                final bars = _dragRemainder.truncate();
                if (bars != 0) {
                  _dragRemainder -= bars;
                  widget.onPan?.call(bars);
                }
              } else if (event.scrollDelta.dy != 0) {
                widget.onZoom!(event.scrollDelta.dy > 0 ? 1.15 : 1 / 1.15,
                    event.localPosition.dx / widget.size.width);
              }
            });
          }
        },
        child: GestureDetector(
          key: const ValueKey('chart-crosshair-input'),
          dragStartBehavior: DragStartBehavior.down,
          behavior: HitTestBehavior.translucent,
          onTapDown: (details) => _setCrosshair(ref, details.localPosition),
          onTap: widget.onTap,
          onPanDown: (details) => _setCrosshair(ref, details.localPosition),
          onPanStart: (_) => _dragRemainder = 0,
          onPanUpdate: (details) {
            if (widget.onPan == null) {
              _setCrosshair(ref, details.localPosition);
              return;
            }
            _dragRemainder -= details.delta.dx *
                (widget.slotCount ?? widget.candleCount) /
                widget.size.width;
            final bars = _dragRemainder.truncate();
            if (bars != 0) {
              _dragRemainder -= bars;
              widget.onPan!(bars);
            }
          },
          onPanEnd: (_) => _clearCrosshair(),
          onPanCancel: () => _clearCrosshair(),
          child: const SizedBox.expand(),
        ),
      ),
    );
  }

  void _setCrosshair(WidgetRef ref, Offset localPosition) {
    final dx = (localPosition.dx / widget.size.width).clamp(0.0, 1.0);
    final dy = (localPosition.dy / widget.size.height).clamp(0.0, 1.0);
    final slots = widget.slotCount ?? widget.candleCount;
    if (widget.onSlotHover != null) {
      final slot = (dx * slots).floor();
      widget.onSlotHover!(slot >= slots ? null : slot);
      return;
    }
    final leading = (slots - widget.candleCount).clamp(0, slots);
    final index = (dx * slots).floor() - leading;
    setChartCrosshair(
        ref,
        index < 0 || index >= widget.candleCount
            ? null
            : ChartCrosshairSnapshot(
                x: dx, y: dy, candleIndex: index + widget.indexOffset));
  }
}

class _ComparisonLegendOverlay extends ConsumerWidget {
  const _ComparisonLegendOverlay({
    required this.labels,
    required this.hiddenSymbols,
  });

  final Map<String, String> labels;
  final Set<String> hiddenSymbols;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final entries = labels.entries.take(4).toList(growable: false);
    final visibleSymbols = [
      for (final entry in entries)
        if (!hiddenSymbols.contains(entry.key)) entry.key,
    ];
    return Material(
      color: Colors.transparent,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          for (final entry in entries)
            Padding(
              padding: const EdgeInsets.only(bottom: 4),
              child: _ComparisonLegendChip(
                symbol: entry.key,
                label: entry.value,
                hidden: hiddenSymbols.contains(entry.key),
                color: _legendColor(entry.key, visibleSymbols),
                onTap: () => toggleComparisonSymbolVisibility(ref, entry.key),
              ),
            ),
        ],
      ),
    );
  }

  Color _legendColor(String symbol, List<String> visibleSymbols) {
    final visibleIndex = visibleSymbols.indexOf(symbol);
    if (visibleIndex < 0) return VosseColors.textMuted;
    return CandleChartPainter.comparisonColorFor(visibleIndex);
  }
}

class _ComparisonLegendChip extends StatelessWidget {
  const _ComparisonLegendChip({
    required this.symbol,
    required this.label,
    required this.hidden,
    required this.color,
    required this.onTap,
  });

  final String symbol;
  final String label;
  final bool hidden;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final textColor = hidden
        ? VosseColors.textMuted.withValues(alpha: .55)
        : VosseColors.textMuted;
    return Tooltip(
      message: hidden ? '$label 비교선 다시 표시' : '$label 비교선 숨김',
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(4),
        child: Container(
          height: 22,
          constraints: const BoxConstraints(maxWidth: 148),
          padding: const EdgeInsets.symmetric(horizontal: 8),
          decoration: BoxDecoration(
            color: VosseColors.bgPanel.withValues(alpha: hidden ? .52 : .86),
            border: Border.all(
              color: hidden
                  ? VosseColors.borderSubtle
                  : color.withValues(alpha: .72),
            ),
            borderRadius: BorderRadius.circular(4),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 18,
                height: 2,
                color: color.withValues(alpha: hidden ? .32 : 1),
              ),
              const SizedBox(width: 6),
              Flexible(
                child: Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: textColor,
                    fontSize: 10,
                    fontWeight: FontWeight.w900,
                    decoration: hidden
                        ? TextDecoration.lineThrough
                        : TextDecoration.none,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
