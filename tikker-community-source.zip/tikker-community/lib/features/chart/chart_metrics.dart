import 'dart:math' as math;

// Shared by the canvas and gesture layers so price coordinates stay aligned.
const chartAxisWidth = 88.0;

List<double> chartPriceTicks(double low, double high, {int target = 6}) {
  if (!low.isFinite || !high.isFinite || high <= low) return const [];
  final raw = (high - low) / math.max(1, target - 1);
  final power = math.pow(10, (math.log(raw) / math.ln10).floor()).toDouble();
  final unit = raw / power;
  final choices = [1.0, 2.0, 2.5, 5.0, 10.0]..sort((a, b) =>
      (math.log(a / unit)).abs().compareTo((math.log(b / unit)).abs()));
  final step = choices.first * power;
  final first = (low / step).ceil();
  final last = (high / step).floor();
  return [for (var i = first; i <= last; i++) i * step];
}

/// No partial-window average: a period means exactly that many observations.
List<double?> simpleMovingAverage(List<double> values, int period) {
  assert(period > 0);
  var sum = 0.0;
  return [
    for (var i = 0; i < values.length; i++)
      (() {
        sum += values[i];
        if (i >= period) sum -= values[i - period];
        return i + 1 < period ? null : sum / period;
      })()
  ];
}
