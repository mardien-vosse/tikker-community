import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../core/theme/vosse_theme.dart';
import '../../shared/models/market_models.dart';
import '../../shared/utils/formatters.dart';
import 'chart_state.dart';
import 'chart_metrics.dart';
import 'drawing_coordinates.dart';
import 'realtime_candle_builder.dart';

class CandleChartPainter extends CustomPainter {
  CandleChartPainter(
    this.candles, {
    required this.renderMode,
    required this.indicators,
    required this.drawingEnabled,
    required this.drawingTool,
    required this.drawings,
    required this.selectedDrawingIndex,
    required this.crosshair,
    required this.comparisonEnabled,
    required this.comparisonLabels,
    required this.comparisonCandleSets,
    required this.volumeVisible,
    this.compact = false,
    this.priceDecimals = 2,
    this.history = const [],
    this.slotCount,
    this.showSummary = true,
    this.showLastPrice = true,
    this.candleSlots,
    this.timeAxisTimestamps,
    this.linkedCrosshairSlot,
  });

  final List<CandlePoint> candles;
  final ChartRenderMode renderMode;
  final Set<ChartIndicator> indicators;
  final bool drawingEnabled;
  final ChartDrawingTool drawingTool;
  final List<ChartDrawingAnnotation> drawings;
  final int? selectedDrawingIndex;
  final ChartCrosshairSnapshot? crosshair;
  final bool comparisonEnabled;
  final Map<String, String> comparisonLabels;
  final Map<String, List<CandlePoint>> comparisonCandleSets;
  final bool volumeVisible;
  final bool compact;
  final int priceDecimals;
  final List<CandlePoint> history;
  final int? slotCount;
  final bool showSummary;
  final bool showLastPrice;
  final List<int>? candleSlots;
  final List<String>? timeAxisTimestamps;
  final int? linkedCrosshairSlot;
  late final _indicatorCandles = [...history, ...candles];
  int get _slots => math.max(1, slotCount ?? candles.length);
  int get _leadingSlots => math.max(0, _slots - candles.length);
  double _x(int index, double step) =>
      ((candleSlots != null && index < candleSlots!.length)
              ? candleSlots![index]
              : _leadingSlots + index) *
          step +
      step / 2;

  double _previousClose(int index) => index > 0
      ? candles[index - 1].close
      : history.isNotEmpty
          ? history.last.close
          : candles[index].open;

  List<CandlePoint> _lookback(int index, int period) {
    final end = history.length + index + 1;
    return _indicatorCandles.sublist(math.max(0, end - period), end);
  }

  static Color comparisonColorFor(int index) {
    const colors = [
      Color(0xFF38BDF8),
      VosseColors.accentPurple,
      VosseColors.warning,
      Color(0xFF22C55E),
    ];
    return colors[index % colors.length];
  }

  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.clipRect(Offset.zero & size);
    if (candles.isEmpty) {
      _paintTimeAxis(canvas, size, math.max(1.0, size.width - chartAxisWidth));
      _paintLinkedCrosshair(canvas, size, size.height * .74);
      canvas.restore();
      return;
    }
    final compactLabels = compact || size.width < 480 || size.height < 280;
    const axisWidth = chartAxisWidth;
    final chartWidth = math.max(1.0, size.width - axisWidth);
    final hasLowerIndicators = indicators.contains(ChartIndicator.rsi) ||
        indicators.contains(ChartIndicator.macd);
    final priceHeight = size.height * (hasLowerIndicators ? .62 : .74);
    final step = chartWidth / _slots;
    final focusedIndex = (crosshair?.candleIndex ?? candles.length - 1)
        .clamp(0, candles.length - 1)
        .toInt();
    // Why: the chart should read like the reference trading app, where price
    // movement is prioritized over boxed grid scaffolding.
    final scale = ChartPriceScale(candles);
    final high = scale.top;
    final low = scale.bottom;
    final maxVolume =
        candles.map((c) => c.volume).reduce((a, b) => a > b ? a : b);
    final gap = (high - low) <= 0 ? 1.0 : high - low;
    final chartSize = Size(chartWidth, priceHeight);
    final volumeTop = _volumeTop(size, hasLowerIndicators);
    final volumeHeight = math.max(18.0, size.height - volumeTop - 30);
    final comparisonEntries = comparisonEnabled
        ? comparisonCandleSets.entries
            .where((entry) => entry.value.isNotEmpty)
            .toList(growable: false)
        : <MapEntry<String, List<CandlePoint>>>[];
    if (renderMode == ChartRenderMode.candle) {
      for (var i = 0; i < candles.length; i += 1) {
        _paintCandle(canvas, chartSize, candles[i], i, step, low, gap);
      }
    } else {
      _paintCloseSeries(canvas, chartSize, step, low, gap);
    }
    if (volumeVisible) {
      if (!compactLabels) {
        _paintVolumePane(
            canvas, size, chartWidth, volumeTop, volumeHeight, maxVolume);
      }
      for (var i = 0; i < candles.length; i += 1) {
        _paintVolume(
          canvas,
          candles[i],
          i,
          step,
          maxVolume,
          volumeTop,
          volumeHeight,
        );
      }
    }
    canvas.save();
    canvas.clipRect(Offset.zero & chartSize);
    for (var i = 0; i < comparisonEntries.length; i += 1) {
      _paintComparisonLine(
        canvas,
        chartSize,
        step,
        low,
        gap,
        comparisonEntries[i].value,
        comparisonColorFor(i),
      );
    }
    if (indicators.contains(ChartIndicator.bollinger)) {
      _paintBollingerBands(canvas, chartSize, step, low, gap);
    }
    if (indicators.contains(ChartIndicator.ema)) {
      _paintMovingAverages(canvas, chartSize, step, low, gap);
    }
    canvas.restore();
    if (indicators.contains(ChartIndicator.rsi)) {
      _paintRsi(canvas, size, chartWidth);
    }
    if (indicators.contains(ChartIndicator.macd)) {
      _paintMacd(canvas, size, chartWidth);
    }
    if (drawings.isNotEmpty) {
      canvas.save();
      canvas.clipRect(Offset.zero & chartSize);
      _paintDrawingAnnotations(
        canvas,
        chartSize,
        drawings,
        selectedDrawingIndex,
      );
      canvas.restore();
    }
    if (!compactLabels) _paintWatermark(canvas, size);
    _paintAxis(canvas, size, high, low, axisWidth, priceHeight);
    if (showLastPrice) {
      _paintCurrentPrice(
        canvas,
        size,
        candles.last.close,
        candles.length > 1
            ? candles[candles.length - 2].close
            : candles.last.open,
        high,
        low,
        axisWidth,
        priceHeight,
      );
    }
    if (!compactLabels) _paintHighLowMarkers(canvas, chartSize, step, low, gap);
    _paintTimeAxis(canvas, size, chartWidth);
    _paintLinkedCrosshair(canvas, size, priceHeight);
    if (!compactLabels && showSummary) {
      _paintTopInfo(canvas, chartWidth, focusedIndex);
      if (indicators.contains(ChartIndicator.ema)) {
        _paintMovingAverageLegend(canvas, chartWidth);
      }
    }
    _paintCrosshair(canvas, size, chartSize, step, high, low, axisWidth);
    canvas.restore();
  }

  void _paintCandle(Canvas canvas, Size size, CandlePoint c, int index,
      double step, double low, double gap) {
    final x = _x(index, step);
    double y(double value) => size.height - ((value - low) / gap) * size.height;
    final rising = c.close >= c.open;
    final paint = Paint()
      ..color = rising ? VosseColors.up : VosseColors.down
      ..strokeWidth = 1.2;
    canvas.drawLine(Offset(x, y(c.high)), Offset(x, y(c.low)), paint);
    final top = y(rising ? c.close : c.open);
    final bottom = y(rising ? c.open : c.close);
    final bodyBottom = bottom < top + 2 ? top + 2 : bottom;
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTRB(x - step * .26, top, x + step * .26,
            bodyBottom > size.height ? size.height : bodyBottom),
        const Radius.circular(2),
      ),
      paint,
    );
  }

  void _paintVolume(
    Canvas canvas,
    CandlePoint c,
    int index,
    double step,
    double maxVolume,
    double volumeTop,
    double volumeHeight,
  ) {
    final x = _x(index, step);
    final rising = c.close >= c.open;
    final paint = Paint()
      ..color =
          (rising ? VosseColors.up : VosseColors.down).withValues(alpha: .54);
    final height = maxVolume <= 0 ? 0 : (c.volume / maxVolume) * volumeHeight;
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTRB(x - step * .26, volumeTop + volumeHeight - height,
            x + step * .26, volumeTop + volumeHeight),
        const Radius.circular(2),
      ),
      paint,
    );
  }

  double _volumeTop(Size size, bool hasLowerIndicators) {
    return size.height * (hasLowerIndicators ? .80 : .76);
  }

  void _paintVolumePane(Canvas canvas, Size size, double chartWidth,
      double volumeTop, double volumeHeight, double maxVolume) {
    canvas.drawLine(
      Offset(0, volumeTop - 1),
      Offset(chartWidth, volumeTop - 1),
      Paint()..color = VosseColors.borderSubtle,
    );
    final latest = candles.last;
    final previous = candles.length > 1
        ? candles[candles.length - 2]
        : history.isNotEmpty
            ? history.last
            : latest;
    final volumeChange = _percentChange(latest.volume, previous.volume);
    final volumeColor = _deltaColor(volumeChange);
    _drawText(
      canvas,
      '거래량',
      Offset(12, volumeTop + 8),
      const TextStyle(
        color: VosseColors.textSecondary,
        fontSize: 11.5,
        fontWeight: FontWeight.w500,
      ),
      maxWidth: 48,
    );
    _drawText(
      canvas,
      '${_formatKoreanNumber(latest.volume)} (${_formatPercent(volumeChange)})',
      Offset(60, volumeTop + 8),
      TextStyle(
        color: volumeColor,
        fontSize: 11.5,
        fontWeight: FontWeight.w500,
      ),
      maxWidth: math.max(72.0, chartWidth - 84),
    );
    if (maxVolume <= 0) return;
    _drawText(
      canvas,
      compactVolume(maxVolume.round()),
      Offset(chartWidth + 10, volumeTop + 8),
      const TextStyle(
        color: VosseColors.textMuted,
        fontSize: 11,
        fontWeight: FontWeight.w700,
      ),
      maxWidth: size.width - chartWidth - 12,
    );
    _drawText(
      canvas,
      compactVolume((maxVolume / 2).round()),
      Offset(chartWidth + 10, volumeTop + volumeHeight / 2 - 6),
      const TextStyle(
        color: VosseColors.textMuted,
        fontSize: 11,
        fontWeight: FontWeight.w700,
      ),
      maxWidth: size.width - chartWidth - 12,
    );
  }

  void _paintCloseSeries(
      Canvas canvas, Size size, double step, double low, double gap) {
    final path = _closePath(size, step, low, gap);
    if (renderMode == ChartRenderMode.area) {
      final areaPath = Path.from(path)
        ..lineTo(_x(candles.length - 1, step), size.height)
        ..lineTo(_x(0, step), size.height)
        ..close();
      canvas.drawPath(
        areaPath,
        Paint()..color = VosseColors.accent.withValues(alpha: .12),
      );
    }
    canvas.drawPath(
      path,
      Paint()
        ..color = VosseColors.accent
        ..strokeWidth = 2
        ..style = PaintingStyle.stroke,
    );
  }

  Path _closePath(Size size, double step, double low, double gap) {
    final path = Path();
    for (var i = 0; i < candles.length; i += 1) {
      final x = _x(i, step);
      final y = size.height - ((candles[i].close - low) / gap) * size.height;
      if (i == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }
    return path;
  }

  void _paintMovingAverages(
      Canvas canvas, Size size, double step, double low, double gap) {
    const specs = [
      _MovingAverageSpec(5, VosseColors.ma5),
      _MovingAverageSpec(10, Color(0xFFFF7A00)),
      _MovingAverageSpec(20, VosseColors.ma20),
      _MovingAverageSpec(60, Color(0xFF00D36F)),
      _MovingAverageSpec(120, Color(0xFF00B7D8)),
    ];
    for (final spec in specs) {
      _paintMovingAverage(canvas, size, step, low, gap, spec);
    }
  }

  void _paintMovingAverage(Canvas canvas, Size size, double step, double low,
      double gap, _MovingAverageSpec spec) {
    final averages = simpleMovingAverage(
        _indicatorCandles.map((c) => c.close).toList(), spec.period);
    final path = Path();
    var started = false;
    for (var i = 0; i < candles.length; i += 1) {
      final average = averages[history.length + i];
      if (average == null) continue;
      final x = _x(i, step);
      final y = size.height - ((average - low) / gap) * size.height;
      if (!started) {
        path.moveTo(x, y);
        started = true;
      } else {
        path.lineTo(x, y);
      }
    }
    canvas.drawPath(
      path,
      Paint()
        ..color = spec.color
        ..strokeWidth = spec.period <= 20 ? 1.65 : 1.35
        ..style = PaintingStyle.stroke,
    );
  }

  void _paintBollingerBands(
      Canvas canvas, Size size, double step, double low, double gap) {
    final upper = Path();
    final lower = Path();
    final fill = Path();
    var started = false;
    for (var i = 0; i < candles.length; i += 1) {
      final slice = _lookback(i, 20);
      final average =
          slice.map((c) => c.close).reduce((a, b) => a + b) / slice.length;
      final variance = slice
              .map((c) => math.pow(c.close - average, 2).toDouble())
              .reduce((a, b) => a + b) /
          slice.length;
      final deviation = math.sqrt(variance);
      final upperValue = average + deviation * 2;
      final lowerValue = average - deviation * 2;
      final x = _x(i, step);
      final yUpper = size.height - ((upperValue - low) / gap) * size.height;
      final yLower = size.height - ((lowerValue - low) / gap) * size.height;
      if (!started) {
        upper.moveTo(x, yUpper);
        lower.moveTo(x, yLower);
        fill.moveTo(x, yUpper);
        started = true;
      } else {
        upper.lineTo(x, yUpper);
        lower.lineTo(x, yLower);
        fill.lineTo(x, yUpper);
      }
    }
    for (var i = candles.length - 1; i >= 0; i -= 1) {
      final slice = _lookback(i, 20);
      final average =
          slice.map((c) => c.close).reduce((a, b) => a + b) / slice.length;
      final variance = slice
              .map((c) => math.pow(c.close - average, 2).toDouble())
              .reduce((a, b) => a + b) /
          slice.length;
      final deviation = math.sqrt(variance);
      final lowerValue = average - deviation * 2;
      final x = _x(i, step);
      final yLower = size.height - ((lowerValue - low) / gap) * size.height;
      fill.lineTo(x, yLower);
    }
    fill.close();
    canvas.drawPath(
      fill,
      Paint()..color = VosseColors.accentPurple.withValues(alpha: .07),
    );
    final paint = Paint()
      ..color = VosseColors.accentPurple.withValues(alpha: .72)
      ..strokeWidth = 1.2
      ..style = PaintingStyle.stroke;
    canvas.drawPath(upper, paint);
    canvas.drawPath(lower, paint);
  }

  void _paintComparisonLine(
    Canvas canvas,
    Size size,
    double step,
    double low,
    double gap,
    List<CandlePoint> comparisonCandles,
    Color color,
  ) {
    final count = math.min(candles.length, comparisonCandles.length);
    if (count < 2) return;
    final baseClose = candles.first.close;
    final comparisonBase = comparisonCandles.first.close;
    if (baseClose <= 0 || comparisonBase <= 0) return;

    final path = Path();
    for (var i = 0; i < count; i += 1) {
      final normalizedValue =
          baseClose * (comparisonCandles[i].close / comparisonBase);
      final x = _x(i, step);
      final rawY = size.height - ((normalizedValue - low) / gap) * size.height;
      final y = rawY.clamp(0.0, size.height);
      if (i == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }
    canvas.drawPath(
      path,
      Paint()
        ..color = color
        ..strokeWidth = 1.5
        ..style = PaintingStyle.stroke,
    );
  }

  void _paintRsi(Canvas canvas, Size size, double chartWidth) {
    final panel = Rect.fromLTWH(0, size.height * .64, chartWidth, 38);
    _paintIndicatorPanel(canvas, panel, 'RSI');
    final values = _rsiValues();
    if (values.isEmpty) return;
    final path = Path();
    final step = chartWidth / _slots;
    for (var i = 0; i < values.length; i += 1) {
      final x = panel.left + _x(i, step);
      final y = panel.bottom - (values[i] / 100) * panel.height;
      if (i == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }
    canvas.drawLine(
      Offset(panel.left, panel.top + panel.height * .3),
      Offset(panel.right, panel.top + panel.height * .3),
      Paint()..color = VosseColors.warning.withValues(alpha: .35),
    );
    canvas.drawLine(
      Offset(panel.left, panel.top + panel.height * .7),
      Offset(panel.right, panel.top + panel.height * .7),
      Paint()..color = VosseColors.down.withValues(alpha: .35),
    );
    canvas.drawPath(
      path,
      Paint()
        ..color = VosseColors.warning
        ..strokeWidth = 1.5
        ..style = PaintingStyle.stroke,
    );
  }

  void _paintMacd(Canvas canvas, Size size, double chartWidth) {
    final panel = Rect.fromLTWH(0, size.height * .72, chartWidth, 42);
    _paintIndicatorPanel(canvas, panel, 'MACD');
    final values = _macdHistogram();
    if (values.isEmpty) return;
    final maxAbs = values
        .map((v) => v.abs())
        .reduce((a, b) => a > b ? a : b)
        .clamp(1.0, double.infinity);
    final step = chartWidth / _slots;
    final zeroY = panel.top + panel.height / 2;
    for (var i = 0; i < values.length; i += 1) {
      final x = _x(i, step);
      final height = (values[i].abs() / maxAbs) * panel.height * .42;
      final paint = Paint()
        ..color = values[i] >= 0
            ? VosseColors.up.withValues(alpha: .65)
            : VosseColors.down.withValues(alpha: .65);
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTRB(
            x - step * .24,
            values[i] >= 0 ? zeroY - height : zeroY,
            x + step * .24,
            values[i] >= 0 ? zeroY : zeroY + height,
          ),
          const Radius.circular(1.5),
        ),
        paint,
      );
    }
  }

  void _paintIndicatorPanel(Canvas canvas, Rect panel, String label) {
    canvas.drawRRect(
      RRect.fromRectAndRadius(panel, const Radius.circular(4)),
      Paint()..color = VosseColors.bgPanel.withValues(alpha: .62),
    );
    final textPainter = TextPainter(
      text: TextSpan(
        text: label,
        style: const TextStyle(
          color: VosseColors.textMuted,
          fontSize: 10,
          fontWeight: FontWeight.w600,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    textPainter.paint(canvas, Offset(panel.left + 6, panel.top + 4));
  }

  List<double> _rsiValues() {
    final values = <double>[];
    for (var i = history.length; i < _indicatorCandles.length; i += 1) {
      final from = math.max(1, i - 13);
      var gain = 0.0;
      var loss = 0.0;
      for (var j = from; j <= i; j += 1) {
        final diff =
            _indicatorCandles[j].close - _indicatorCandles[j - 1].close;
        if (diff >= 0) {
          gain += diff;
        } else {
          loss += diff.abs();
        }
      }
      if (gain == 0 && loss == 0) {
        values.add(50);
      } else if (loss == 0) {
        values.add(100);
      } else {
        final rs = gain / loss;
        values.add(100 - (100 / (1 + rs)));
      }
    }
    return values;
  }

  List<double> _macdHistogram() {
    final closes = _indicatorCandles.map((c) => c.close).toList();
    final fast = _emaSeries(closes, 12);
    final slow = _emaSeries(closes, 26);
    final macd = <double>[];
    for (var i = 0; i < closes.length; i += 1) {
      macd.add(fast[i] - slow[i]);
    }
    final signal = _emaSeries(macd, 9);
    return [
      for (var i = history.length; i < macd.length; i += 1) macd[i] - signal[i],
    ];
  }

  List<double> _emaSeries(List<double> values, int period) {
    if (values.isEmpty) return const [];
    final alpha = 2 / (period + 1);
    final output = <double>[values.first];
    for (var i = 1; i < values.length; i += 1) {
      output.add(values[i] * alpha + output.last * (1 - alpha));
    }
    return output;
  }

  void _paintDrawingAnnotations(
    Canvas canvas,
    Size size,
    List<ChartDrawingAnnotation> drawings,
    int? selectedDrawingIndex,
  ) {
    for (var i = 0; i < drawings.length; i += 1) {
      final drawing = drawings[i];
      if (drawing.hidden) continue;
      final selected = i == selectedDrawingIndex;
      final paint = Paint()
        ..color = Color(drawing.colorValue)
        ..strokeWidth = drawing.strokeWidth + (selected ? .5 : 0)
        ..style = PaintingStyle.stroke;
      if (drawing.label.isNotEmpty) {
        _drawText(
            canvas,
            drawing.label,
            Offset(
                drawing.endX * size.width + 8, drawing.endY * size.height - 20),
            TextStyle(color: paint.color, fontSize: 11),
            maxWidth: 180);
      }
      switch (drawing.tool) {
        case ChartDrawingTool.none:
          continue;
        case ChartDrawingTool.vertical:
          final x = drawing.startX * size.width;
          _drawAnnotationLine(canvas, Offset(x, 0), Offset(x, size.height),
              paint, drawing.dashed);
          continue;
        case ChartDrawingTool.text:
          if (selected) {
            canvas.drawCircle(
                _drawingOffset(size, drawing.endX, drawing.endY), 3, paint);
          }
          continue;
        case ChartDrawingTool.rectangle:
        case ChartDrawingTool.range:
          final a = _drawingOffset(size, drawing.startX, drawing.startY);
          final b = _drawingOffset(size, drawing.endX, drawing.endY);
          final rect = Rect.fromPoints(a, b);
          canvas.drawRect(
              rect, Paint()..color = paint.color.withValues(alpha: .08));
          for (final edge in [
            (rect.topLeft, rect.topRight),
            (rect.topRight, rect.bottomRight),
            (rect.bottomRight, rect.bottomLeft),
            (rect.bottomLeft, rect.topLeft)
          ]) {
            _drawAnnotationLine(
                canvas, edge.$1, edge.$2, paint, drawing.dashed);
          }
          if (drawing.tool == ChartDrawingTool.range && drawing.anchored) {
            final delta = drawing.endPrice! - drawing.startPrice!;
            final pct = _percentChange(drawing.endPrice!, drawing.startPrice!);
            final bars =
                ((drawing.endX - drawing.startX).abs() * _slots).round() + 1;
            _drawText(
                canvas,
                '${_formatPrice(delta)} (${_formatPercent(pct)}) · $bars봉',
                Offset(rect.left + 8, rect.top + 8),
                TextStyle(color: paint.color, fontSize: 12),
                maxWidth: math.max(180, rect.width));
          }
          continue;
        case ChartDrawingTool.channel:
          _paintTrendDrawing(canvas, size, drawing, paint, selected);
          final shift = drawing.channelOffset / ChartPriceScale(candles).span;
          _drawAnnotationLine(
              canvas,
              _drawingOffset(size, drawing.startX, drawing.startY - shift),
              _drawingOffset(size, drawing.endX, drawing.endY - shift),
              paint,
              drawing.dashed);
          continue;
        case ChartDrawingTool.trend:
          _paintTrendDrawing(canvas, size, drawing, paint, selected);
          continue;
        case ChartDrawingTool.horizontal:
          _paintHorizontalDrawing(canvas, size, drawing, paint, selected);
          continue;
        case ChartDrawingTool.fibonacci:
          _paintFibonacciDrawing(canvas, size, drawing, paint, selected);
          continue;
      }
    }
  }

  void _drawAnnotationLine(
      Canvas canvas, Offset a, Offset b, Paint paint, bool dashed) {
    if (dashed) {
      _drawDashedLine(canvas, a, b, paint, dash: 6, gap: 4);
    } else {
      canvas.drawLine(a, b, paint);
    }
  }

  void _paintTrendDrawing(
    Canvas canvas,
    Size size,
    ChartDrawingAnnotation drawing,
    Paint paint,
    bool selected,
  ) {
    final start = _drawingOffset(size, drawing.startX, drawing.startY);
    final end = _drawingOffset(size, drawing.endX, drawing.endY);
    _drawAnnotationLine(canvas, start, end, paint, drawing.dashed);
    final handlePaint = Paint()..color = paint.color;
    if (selected && !drawing.locked) {
      canvas.drawCircle(start, 4, Paint()..color = VosseColors.bgPanel);
      canvas.drawCircle(end, 4, Paint()..color = VosseColors.bgPanel);
      handlePaint.style = PaintingStyle.stroke;
      canvas.drawCircle(start, 4, handlePaint);
      canvas.drawCircle(end, 4, handlePaint);
    }
  }

  void _paintHorizontalDrawing(
    Canvas canvas,
    Size size,
    ChartDrawingAnnotation drawing,
    Paint paint,
    bool selected,
  ) {
    final y = drawing.endY * size.height;
    _drawAnnotationLine(
        canvas, Offset(0, y), Offset(size.width, y), paint, drawing.dashed);
    final marker = RRect.fromRectAndRadius(
      Rect.fromLTWH(math.max(0, size.width - 76), y - 10, 66, 20),
      const Radius.circular(4),
    );
    canvas.drawRRect(
      marker,
      Paint()..color = paint.color,
    );
    if (drawing.endPrice != null) {
      _drawText(
          canvas,
          _formatPrice(drawing.endPrice!),
          Offset(math.max(0, size.width - 72), y - 7),
          const TextStyle(color: Color(0xFF0B0C10), fontSize: 10),
          maxWidth: 62);
    }
    if (selected && !drawing.locked) {
      final handlePaint = Paint()..color = VosseColors.warning;
      canvas.drawCircle(Offset(0, y), 4.2, handlePaint);
      canvas.drawCircle(Offset(size.width, y), 4.2, handlePaint);
    }
  }

  void _paintFibonacciDrawing(
    Canvas canvas,
    Size size,
    ChartDrawingAnnotation drawing,
    Paint paint,
    bool selected,
  ) {
    final start = _drawingOffset(size, drawing.startX, drawing.startY);
    final end = _drawingOffset(size, drawing.endX, drawing.endY);
    final left = math.min(start.dx, end.dx);
    final right = math.max(start.dx, end.dx);
    final top = math.min(start.dy, end.dy);
    final bottom = math.max(start.dy, end.dy);
    final lineLeft = (right - left).abs() < 20 ? 0.0 : left;
    final lineRight = (right - left).abs() < 20 ? size.width : right;
    const levels = [0.0, .236, .382, .5, .618, .786, 1.0];
    final levelPaint = Paint()
      ..color = paint.color.withValues(alpha: selected ? .95 : .8)
      ..strokeWidth = paint.strokeWidth
      ..style = PaintingStyle.stroke;
    for (final level in levels) {
      final y = top + (bottom - top) * level;
      _drawAnnotationLine(canvas, Offset(lineLeft, y), Offset(lineRight, y),
          levelPaint, drawing.dashed);
      _paintFibLabel(canvas, level, Offset(lineRight - 38, y - 8));
    }
    if (selected && !drawing.locked) {
      final handlePaint = Paint()..color = VosseColors.warning;
      canvas.drawCircle(start, 4.2, handlePaint);
      canvas.drawCircle(end, 4.2, handlePaint);
    }
  }

  void _paintFibLabel(Canvas canvas, double level, Offset offset) {
    final textPainter = TextPainter(
      text: TextSpan(
        text:
            '${(level * 100).toStringAsFixed(level == 0 || level == 1 ? 0 : 1)}%',
        style: const TextStyle(
          color: VosseColors.textMuted,
          fontSize: 9,
          fontWeight: FontWeight.w600,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout(maxWidth: 38);
    textPainter.paint(canvas, offset);
  }

  Offset _drawingOffset(Size size, double x, double y) {
    return Offset(
      x * size.width,
      y * size.height,
    );
  }

  void _paintHighLowMarkers(
      Canvas canvas, Size size, double step, double low, double gap) {
    if (candles.length < 2) return;
    var highIndex = 0;
    var lowIndex = 0;
    for (var i = 1; i < candles.length; i += 1) {
      if (candles[i].high > candles[highIndex].high) highIndex = i;
      if (candles[i].low < candles[lowIndex].low) lowIndex = i;
    }
    _paintExtremeMarker(
      canvas,
      size,
      index: highIndex,
      value: candles[highIndex].high,
      low: low,
      gap: gap,
      step: step,
      label: '최고 ${_formatPrice(candles[highIndex].high)} - '
          '${_formatShortDate(candles[highIndex].timestamp)} →',
      color: VosseColors.up,
      preferAbove: true,
    );
    _paintExtremeMarker(
      canvas,
      size,
      index: lowIndex,
      value: candles[lowIndex].low,
      low: low,
      gap: gap,
      step: step,
      label: '← 최저 ${_formatPrice(candles[lowIndex].low)} - '
          '${_formatShortDate(candles[lowIndex].timestamp)}',
      color: VosseColors.down,
      preferAbove: false,
    );
  }

  void _paintExtremeMarker(
    Canvas canvas,
    Size size, {
    required int index,
    required double value,
    required double low,
    required double gap,
    required double step,
    required String label,
    required Color color,
    required bool preferAbove,
  }) {
    final x = _x(index, step);
    final y = size.height - ((value - low) / gap) * size.height;
    final textPainter = TextPainter(
      text: TextSpan(
        text: label,
        style: TextStyle(
          color: color,
          fontSize: 11.5,
          fontWeight: FontWeight.w500,
        ),
      ),
      maxLines: 1,
      ellipsis: '...',
      textDirection: TextDirection.ltr,
    )..layout(maxWidth: math.min(260.0, size.width - 20));
    final left = (preferAbove ? x - textPainter.width : x - 8)
        .clamp(8.0, math.max(8.0, size.width - textPainter.width - 8))
        .toDouble();
    final top = (preferAbove ? y - 28 : y + 8)
        .clamp(42.0, math.max(42.0, size.height - 38))
        .toDouble();
    textPainter.paint(canvas, Offset(left, top));
  }

  void _paintTimeAxis(Canvas canvas, Size size, double chartWidth) {
    final labels =
        timeAxisTimestamps ?? candles.map((c) => c.timestamp).toList();
    if (labels.length < 2) return;
    final y = size.height - 22;
    final tickPaint = Paint()..color = VosseColors.borderSubtle;
    final usedWidth = chartWidth * labels.length / _slots;
    final tickCount = (usedWidth / 110).floor().clamp(2, 9);
    for (var i = 0; i < tickCount; i += 1) {
      final index = (i * (labels.length - 1) / (tickCount - 1))
          .round()
          .clamp(0, labels.length - 1);
      final leading = math.max(0, _slots - labels.length);
      final x = chartWidth * (leading + index + .5) / _slots;
      canvas.drawLine(Offset(x, y - 6), Offset(x, y - 1), tickPaint);
      _drawText(
        canvas,
        _formatAxisDate(labels[index]),
        Offset(_clampDouble(x - 38, 0, math.max(0.0, chartWidth - 76)), y),
        const TextStyle(
          color: VosseColors.textPrimary,
          fontSize: 11,
          fontWeight: FontWeight.w700,
        ),
        maxWidth: 76,
        align: TextAlign.center,
      );
    }
  }

  void _paintLinkedCrosshair(Canvas canvas, Size size, double priceHeight) {
    final slot = linkedCrosshairSlot;
    if (slot == null || slot < 0 || slot >= _slots) return;
    final chartWidth = math.max(1.0, size.width - chartAxisWidth);
    final x = chartWidth * (slot + .5) / _slots;
    _drawDashedLine(
      canvas,
      Offset(x, 0),
      Offset(x, priceHeight),
      Paint()
        ..color = VosseColors.textSecondary.withValues(alpha: .72)
        ..strokeWidth = 1,
      dash: 5,
      gap: 5,
    );
  }

  void _paintTopInfo(Canvas canvas, double chartWidth, int index) {
    final candle = candles[index];
    final previousClose = _previousClose(index);
    final spans = <InlineSpan>[
      TextSpan(
        text: '${_formatCandleDateTime(candle.timestamp, fallback: '최신 캔들')}  ',
        style: const TextStyle(color: Colors.white),
      ),
      _ohlcSpan('시', candle.open, previousClose),
      _ohlcSpan('고', candle.high, previousClose),
      _ohlcSpan('저', candle.low, previousClose),
      _ohlcSpan('종', candle.close, previousClose),
    ];
    final textPainter = TextPainter(
      text: TextSpan(
        style: const TextStyle(
          fontSize: 12,
          height: 1.35,
          fontWeight: FontWeight.w500,
          color: VosseColors.textSecondary,
        ),
        children: spans,
      ),
      maxLines: 1,
      ellipsis: '...',
      textDirection: TextDirection.ltr,
    )..layout(maxWidth: math.max(160.0, chartWidth - 24));
    textPainter.paint(canvas, const Offset(12, 8));
  }

  TextSpan _ohlcSpan(String label, double value, double previousClose) {
    final delta = value - previousClose;
    return TextSpan(
      children: [
        TextSpan(
          text: '$label ',
          style: const TextStyle(color: VosseColors.textSecondary),
        ),
        TextSpan(
          text: '${_formatPrice(value)}  ',
          style: TextStyle(color: _deltaColor(delta)),
        ),
      ],
    );
  }

  void _paintMovingAverageLegend(Canvas canvas, double chartWidth) {
    final textPainter = TextPainter(
      text: TextSpan(
        style: const TextStyle(
          fontSize: 11,
          height: 1.25,
          fontWeight: FontWeight.w500,
          color: VosseColors.textSecondary,
        ),
        children: [
          const TextSpan(text: '단순이동평균 '),
          const TextSpan(text: '5 ', style: TextStyle(color: VosseColors.ma5)),
          const TextSpan(
              text: '10 ', style: TextStyle(color: Color(0xFFFF7A00))),
          const TextSpan(
              text: '20 ', style: TextStyle(color: VosseColors.ma20)),
          const TextSpan(
              text: '60 ', style: TextStyle(color: Color(0xFF00D36F))),
          TextSpan(
              text: _indicatorCandles.length < 120 ? '120 (이력 부족)' : '120',
              style: const TextStyle(color: Color(0xFF00B7D8))),
        ],
      ),
      maxLines: 1,
      ellipsis: '...',
      textDirection: TextDirection.ltr,
    )..layout(maxWidth: math.max(140.0, chartWidth - 24));
    textPainter.paint(canvas, const Offset(12, 30));
  }

  void _paintAxis(Canvas canvas, Size size, double high, double low,
      double axisWidth, double priceHeight) {
    final axisPaint = Paint()..color = VosseColors.borderSubtle;
    final x = size.width - axisWidth;
    canvas.drawLine(Offset(x, 0), Offset(x, size.height), axisPaint);
    final textPainter = TextPainter(textDirection: TextDirection.ltr);
    for (final value
        in chartPriceTicks(low, high, target: priceHeight < 240 ? 3 : 6)) {
      final y = priceHeight * (high - value) / (high - low);
      canvas.drawLine(
          Offset(0, y),
          Offset(x, y),
          Paint()
            ..color = VosseColors.textMuted.withValues(alpha: .08)
            ..strokeWidth = .5);
      textPainter.text = TextSpan(
        text: _formatPrice(value),
        style: const TextStyle(color: VosseColors.textPrimary, fontSize: 11.5),
      );
      textPainter.layout();
      final labelTop = (y - 7)
          .clamp(0.0, math.max(0.0, priceHeight - textPainter.height))
          .toDouble();
      if (showLastPrice && candles.isNotEmpty) {
        final lastY = (priceHeight * (high - candles.last.close) / (high - low))
            .clamp(0.0, priceHeight);
        final tagHeight = axisWidth >= 68 ? 42.0 : 26.0;
        final tagTop = _clampDouble(lastY - tagHeight / 2, 2,
            math.max(2.0, priceHeight - tagHeight - 2));
        // Keep complete labels outside the current-price badge's occupied area.
        if (labelTop < tagTop + tagHeight + 3 &&
            labelTop + textPainter.height > tagTop - 3) {
          continue;
        }
      }
      textPainter.paint(canvas, Offset(x + 10, labelTop));
    }
  }

  void _paintCurrentPrice(
      Canvas canvas,
      Size size,
      double price,
      double previousClose,
      double high,
      double low,
      double axisWidth,
      double priceHeight) {
    final chartWidth = size.width - axisWidth;
    final gap = (high - low) <= 0 ? 1.0 : high - low;
    final y = (((high - price) / gap) * priceHeight).clamp(0.0, priceHeight);
    final change = price - previousClose;
    final percent = previousClose == 0 ? 0.0 : change / previousClose * 100;
    final color = _deltaColor(change);
    final linePaint = Paint()
      ..color = color
      ..strokeWidth = 1;
    _drawDashedLine(canvas, Offset(0, y), Offset(chartWidth, y), linePaint,
        dash: 2.4, gap: 2.4);
    final tagHeight = axisWidth >= 68 ? 42.0 : 26.0;
    final tagTop = _clampDouble(
        y - tagHeight / 2, 2, math.max(2.0, priceHeight - tagHeight - 2));
    final rect = RRect.fromRectAndRadius(
      Rect.fromLTWH(chartWidth + 2, tagTop, axisWidth - 2, tagHeight),
      const Radius.circular(2),
    );
    canvas.drawRRect(rect, Paint()..color = color);
    final textPainter = TextPainter(
      text: TextSpan(
        text: '${_formatPrice(price)}\n${_formatPercent(percent)}',
        style: const TextStyle(
          color: Colors.white,
          fontSize: 11.5,
          height: 1.12,
          fontWeight: FontWeight.w600,
        ),
      ),
      textAlign: TextAlign.center,
      maxLines: 2,
      textDirection: TextDirection.ltr,
    )..layout(maxWidth: axisWidth - 8);
    textPainter.paint(
      canvas,
      Offset(chartWidth + 4 + (axisWidth - 8 - textPainter.width) / 2,
          tagTop + (tagHeight - textPainter.height) / 2),
    );
  }

  void _paintCrosshair(Canvas canvas, Size canvasSize, Size priceSize,
      double step, double high, double low, double axisWidth) {
    final snapshot = crosshair;
    if (snapshot == null || candles.isEmpty) return;
    final index = snapshot.candleIndex.clamp(0, candles.length - 1).toInt();
    final candle = candles[index];
    final previousClose = _previousClose(index);
    final x = _x(index, step);
    final y = snapshot.y.clamp(0.0, 1.0) * priceSize.height;
    final linePaint = Paint()
      ..color = VosseColors.textMuted.withValues(alpha: .74)
      ..strokeWidth = 1;
    _drawDashedLine(
        canvas, Offset(x, 0), Offset(x, canvasSize.height - 28), linePaint,
        dash: 7, gap: 7);
    _drawDashedLine(canvas, Offset(0, y), Offset(priceSize.width, y), linePaint,
        dash: 7, gap: 7);

    _paintCrosshairPriceLabel(
      canvas,
      canvasSize,
      y,
      low,
      high,
      axisWidth,
      priceSize.height,
    );
    _paintCrosshairTimeLabel(canvas, canvasSize, x, candle);
    _paintTooltip(canvas, priceSize, candle, previousClose, index, x, y);
  }

  void _paintTooltip(Canvas canvas, Size priceSize, CandlePoint candle,
      double previousClose, int index, double x, double y) {
    final width = math.min(304.0, math.max(160.0, priceSize.width - 16));
    const rowHeight = 22.0;
    const height = 184.0;
    final prefersLeft = x + width + 14 > priceSize.width;
    final maxLeft = math.max(8.0, priceSize.width - width - 8);
    final maxTop = math.max(8.0, priceSize.height - height - 8);
    final left =
        (prefersLeft ? x - width - 10 : x + 10).clamp(8.0, maxLeft).toDouble();
    final top = (y - height - 10).clamp(8.0, maxTop).toDouble();
    final rect = RRect.fromRectAndRadius(
      Rect.fromLTWH(left, top, width, height),
      const Radius.circular(6),
    );
    // Why: the tooltip must remain readable over candles and drawing overlays.
    canvas.drawRRect(
      rect,
      Paint()..color = const Color(0xFF191919).withValues(alpha: .96),
    );
    canvas.drawRRect(
      rect,
      Paint()
        ..color = _deltaColor(candle.close - previousClose)
        ..style = PaintingStyle.stroke,
    );
    _drawText(
      canvas,
      _formatCandleDateTime(candle.timestamp, fallback: '선택 캔들'),
      Offset(left + 14, top + 12),
      const TextStyle(
        color: Colors.white,
        fontSize: 14,
        fontWeight: FontWeight.w600,
      ),
      maxWidth: width - 28,
    );
    final rows = [
      ('시가', candle.open),
      ('고가', candle.high),
      ('저가', candle.low),
      ('종가', candle.close),
    ];
    for (var i = 0; i < rows.length; i += 1) {
      final rowTop = top + 44 + rowHeight * i;
      final label = rows[i].$1;
      final value = rows[i].$2;
      _drawText(
        canvas,
        label,
        Offset(left + 14, rowTop),
        const TextStyle(
          color: VosseColors.textSecondary,
          fontSize: 12.5,
          fontWeight: FontWeight.w500,
        ),
        maxWidth: 56,
      );
      _drawText(
        canvas,
        '${_formatPrice(value)} (${_formatPercent(_percentChange(value, previousClose))})',
        Offset(left + 82, rowTop),
        TextStyle(
          color: _deltaColor(value - previousClose),
          fontSize: 12.5,
          fontWeight: FontWeight.w600,
        ),
        maxWidth: width - 96,
        align: TextAlign.right,
      );
    }
    final volumeChange = index > 0
        ? _percentChange(candle.volume, candles[index - 1].volume)
        : 0.0;
    _paintTooltipMetric(
      canvas,
      left,
      top + 136,
      '거래량',
      '${_formatKoreanNumber(candle.volume)} (${_formatPercent(volumeChange)})',
      _deltaColor(volumeChange),
      width,
    );
    _paintTooltipMetric(
      canvas,
      left,
      top + 158,
      '대금(추정)',
      _formatKoreanNumber(candle.volume * candle.close),
      _deltaColor(candle.close - previousClose),
      width,
    );
  }

  void _paintTooltipMetric(Canvas canvas, double left, double top, String label,
      String value, Color color, double width) {
    _drawText(
      canvas,
      label,
      Offset(left + 14, top),
      const TextStyle(
        color: VosseColors.textSecondary,
        fontSize: 12.5,
        fontWeight: FontWeight.w500,
      ),
      maxWidth: 64,
    );
    _drawText(
      canvas,
      value,
      Offset(left + 82, top),
      TextStyle(
        color: color,
        fontSize: 12.5,
        fontWeight: FontWeight.w600,
      ),
      maxWidth: width - 96,
      align: TextAlign.right,
    );
  }

  void _paintCrosshairPriceLabel(Canvas canvas, Size size, double y, double low,
      double high, double axisWidth, double priceHeight) {
    final chartWidth = size.width - axisWidth;
    final gap = (high - low) <= 0 ? 1.0 : high - low;
    final value = high - (y / math.max(1.0, priceHeight)) * gap;
    final rect = RRect.fromRectAndRadius(
      Rect.fromLTWH(
        chartWidth + 2,
        _clampDouble(y - 12, 2, math.max(2.0, priceHeight - 24)),
        axisWidth - 2,
        24,
      ),
      const Radius.circular(2),
    );
    canvas.drawRRect(rect, Paint()..color = const Color(0xFF6B7280));
    _drawText(
      canvas,
      _formatPrice(value),
      Offset(chartWidth + 7,
          _clampDouble(y - 8, 6, math.max(6.0, priceHeight - 18))),
      const TextStyle(
        color: Colors.white,
        fontSize: 11,
        fontWeight: FontWeight.w600,
      ),
      maxWidth: axisWidth - 12,
      align: TextAlign.center,
    );
  }

  void _paintCrosshairTimeLabel(
      Canvas canvas, Size size, double x, CandlePoint candle) {
    final label = _formatCandleBottomLabel(candle.timestamp);
    if (label.isEmpty) return;
    final textPainter = TextPainter(
      text: TextSpan(
        text: label,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 11.5,
          fontWeight: FontWeight.w500,
        ),
      ),
      maxLines: 1,
      ellipsis: '...',
      textDirection: TextDirection.ltr,
    )..layout(maxWidth: 120);
    final width = textPainter.width + 16;
    final left =
        _clampDouble(x - width / 2, 2, math.max(2.0, size.width - width - 76));
    final top = size.height - 28;
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(left, top, width, 26),
        const Radius.circular(2),
      ),
      Paint()..color = const Color(0xFF6B7280),
    );
    textPainter.paint(canvas, Offset(left + 8, top + 5));
  }

  Color _deltaColor(double delta) {
    if (delta > 0) return VosseColors.up;
    if (delta < 0) return VosseColors.down;
    return VosseColors.textMuted;
  }

  double _percentChange(double value, double base) {
    if (base == 0) return 0;
    return (value - base) / base * 100;
  }

  String _formatPercent(double value) {
    final sign = value > 0 ? '+' : '';
    return '$sign${value.toStringAsFixed(2)}%';
  }

  String _formatPrice(double value) {
    return decimalPriceText(priceDecimals == 0 ? value.round() : value);
  }

  String _formatKoreanNumber(double value) {
    final rounded = value.round();
    final sign = rounded < 0 ? '-' : '';
    final absValue = rounded.abs();
    final eok = absValue ~/ 100000000;
    final man = (absValue % 100000000) ~/ 10000;
    final rest = absValue % 10000;
    if (eok > 0) {
      if (man > 0) {
        return '$sign${_formatPrice(eok.toDouble())}억 ${_formatPrice(man.toDouble())}만';
      }
      return '$sign${_formatPrice(eok.toDouble())}억';
    }
    if (man > 0) {
      if (rest > 0) {
        return '$sign${_formatPrice(man.toDouble())}만 ${_formatPrice(rest.toDouble())}';
      }
      return '$sign${_formatPrice(man.toDouble())}만';
    }
    return '$sign${_formatPrice(absValue.toDouble())}';
  }

  String _formatCandleDateTime(String timestamp, {required String fallback}) {
    final parsed = parseCandleTimestamp(timestamp);
    if (parsed == null) return fallback;
    final date = '${parsed.year}.${parsed.month.toString().padLeft(2, '0')}.'
        '${parsed.day.toString().padLeft(2, '0')}(${_weekday(parsed)})';
    if (parsed.hour == 0 && parsed.minute == 0 && parsed.second == 0) {
      return date;
    }
    final hour = parsed.hour.toString().padLeft(2, '0');
    final minute = parsed.minute.toString().padLeft(2, '0');
    return '$date $hour:$minute';
  }

  String _formatCandleBottomLabel(String timestamp) {
    final parsed = parseCandleTimestamp(timestamp);
    if (parsed == null) return '';
    final month = parsed.month.toString().padLeft(2, '0');
    final day = parsed.day.toString().padLeft(2, '0');
    if (parsed.hour == 0 && parsed.minute == 0 && parsed.second == 0) {
      return '$month.$day(${_weekday(parsed)})';
    }
    final hour = parsed.hour.toString().padLeft(2, '0');
    final minute = parsed.minute.toString().padLeft(2, '0');
    return '$month.$day(${_weekday(parsed)}) $hour:$minute';
  }

  String _formatAxisDate(String timestamp) {
    final parsed = parseCandleTimestamp(timestamp);
    if (parsed == null) return '';
    final month = parsed.month.toString().padLeft(2, '0');
    final day = parsed.day.toString().padLeft(2, '0');
    if (parsed.hour == 0 && parsed.minute == 0 && parsed.second == 0) {
      return '${parsed.year}.$month.$day';
    }
    final hour = parsed.hour.toString().padLeft(2, '0');
    final minute = parsed.minute.toString().padLeft(2, '0');
    return '$hour:$minute';
  }

  String _formatShortDate(String timestamp) {
    final parsed = parseCandleTimestamp(timestamp);
    if (parsed == null) return '최근';
    final month = parsed.month.toString().padLeft(2, '0');
    final day = parsed.day.toString().padLeft(2, '0');
    if (parsed.hour == 0 && parsed.minute == 0 && parsed.second == 0) {
      return '${parsed.year}.$month.$day';
    }
    final hour = parsed.hour.toString().padLeft(2, '0');
    final minute = parsed.minute.toString().padLeft(2, '0');
    return '$month.$day $hour:$minute';
  }

  String _weekday(DateTime date) {
    const labels = ['월', '화', '수', '목', '금', '토', '일'];
    return labels[date.weekday - 1];
  }

  void _drawText(
    Canvas canvas,
    String text,
    Offset offset,
    TextStyle style, {
    required double maxWidth,
    TextAlign align = TextAlign.left,
  }) {
    final textPainter = TextPainter(
      text: TextSpan(text: text, style: style),
      maxLines: 1,
      ellipsis: '...',
      textAlign: align,
      textDirection: TextDirection.ltr,
    )..layout(maxWidth: maxWidth);
    var dx = offset.dx;
    if (align == TextAlign.right) {
      dx = offset.dx + maxWidth - textPainter.width;
    } else if (align == TextAlign.center) {
      dx = offset.dx + (maxWidth - textPainter.width) / 2;
    }
    textPainter.paint(canvas, Offset(dx, offset.dy));
  }

  void _drawDashedLine(Canvas canvas, Offset start, Offset end, Paint paint,
      {double dash = 4, double gap = 4}) {
    final delta = end - start;
    final distance = delta.distance;
    if (distance <= 0) return;
    final direction = delta / distance;
    var drawn = 0.0;
    while (drawn < distance) {
      final segmentEnd = math.min(drawn + dash, distance);
      canvas.drawLine(
          start + direction * drawn, start + direction * segmentEnd, paint);
      drawn = segmentEnd + gap;
    }
  }

  double _clampDouble(double value, double lower, double upper) {
    return value.clamp(lower, math.max(lower, upper)).toDouble();
  }

  void _paintWatermark(Canvas canvas, Size size) {
    final textPainter = TextPainter(
      text: TextSpan(
          text: 'Tikker',
          style: TextStyle(
              color: Colors.white.withValues(alpha: .10),
              fontSize: 32,
              fontWeight: FontWeight.w600)),
      textDirection: TextDirection.ltr,
    )..layout();
    textPainter.paint(canvas, Offset(22, size.height * .72));
  }

  @override
  bool shouldRepaint(covariant CandleChartPainter oldDelegate) =>
      oldDelegate.candles != candles ||
      oldDelegate.history != history ||
      oldDelegate.slotCount != slotCount ||
      oldDelegate.showSummary != showSummary ||
      oldDelegate.showLastPrice != showLastPrice ||
      oldDelegate.priceDecimals != priceDecimals ||
      oldDelegate.candleSlots != candleSlots ||
      oldDelegate.timeAxisTimestamps != timeAxisTimestamps ||
      oldDelegate.linkedCrosshairSlot != linkedCrosshairSlot ||
      oldDelegate.renderMode != renderMode ||
      oldDelegate.indicators != indicators ||
      oldDelegate.drawingEnabled != drawingEnabled ||
      oldDelegate.drawingTool != drawingTool ||
      oldDelegate.drawings != drawings ||
      oldDelegate.selectedDrawingIndex != selectedDrawingIndex ||
      oldDelegate.crosshair != crosshair ||
      oldDelegate.comparisonEnabled != comparisonEnabled ||
      oldDelegate.comparisonLabels != comparisonLabels ||
      oldDelegate.comparisonCandleSets != comparisonCandleSets ||
      oldDelegate.volumeVisible != volumeVisible ||
      oldDelegate.compact != compact;
}

class _MovingAverageSpec {
  const _MovingAverageSpec(this.period, this.color);

  final int period;
  final Color color;
}
