import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../providers/market_providers.dart';
import '../../core/theme/vosse_theme.dart';
import 'chart_state.dart';

class ChartConnectionSummary extends ConsumerWidget {
  const ChartConnectionSummary({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final candles = ref.watch(liveCandleProvider);
    final frame = ref.watch(chartTimeframeProvider);
    final count = candles.valueOrNull?.length ?? 0;
    return Text('${frame.title} · 직접 생성 · $count개 봉',
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: const TextStyle(color: VosseColors.textMuted, fontSize: 11));
  }
}

class ChartStatusBar extends StatelessWidget {
  const ChartStatusBar({super.key, this.bottom = false});
  final bool bottom;
  @override
  Widget build(BuildContext context) => const Padding(
      padding: EdgeInsets.all(8), child: ChartConnectionSummary());
}
