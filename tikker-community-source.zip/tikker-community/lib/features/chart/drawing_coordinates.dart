import 'dart:math' as math;

import '../../shared/models/market_models.dart';
import 'chart_state.dart';
import 'realtime_candle_builder.dart';

class ChartPriceScale {
  ChartPriceScale(List<CandlePoint> candles, {bool legacy = false}) {
    final high =
        candles.isEmpty ? 1.0 : candles.map((c) => c.high).reduce(math.max);
    final low =
        candles.isEmpty ? 0.0 : candles.map((c) => c.low).reduce(math.min);
    final padding = math.max(high - low, math.max(high.abs() * .001, .01));
    top = high + (legacy ? 0 : padding * .28);
    bottom = low - (legacy ? 0 : padding * .08);
    span = top > bottom ? top - bottom : 1;
  }
  late final double top, bottom, span;
  double price(double y) => top - y * span;
  double y(double price) => (top - price) / span;
}

// Interpolate between trading slots, not elapsed wall time across market gaps.
class DrawingCoordinates {
  DrawingCoordinates(
      {required List<String> timestamps,
      this.priceCandles = const [],
      required this.start,
      required this.end,
      required this.slots,
      required this.scale})
      : times = timestamps.map((t) {
          final d = parseCandleTimestamp(t);
          return d == null
              ? double.nan
              : DateTime.utc(d.year, d.month, d.day, d.hour, d.minute, d.second,
                      d.millisecond)
                  .millisecondsSinceEpoch
                  .toDouble();
        }).toList();

  final List<CandlePoint> priceCandles;
  final List<double> times;
  final int start, end, slots;
  final ChartPriceScale scale;
  bool get usable =>
      times.isNotEmpty && times.every((t) => t.isFinite) && slots > 0;
  double get leading => (slots - (end - start)).toDouble();

  double _time(double index) {
    if (times.length == 1) return times.first;
    final i = index.floor().clamp(0, times.length - 2);
    return times[i] + (times[i + 1] - times[i]) * (index - i);
  }

  double _index(String timestamp) {
    final d = parseCandleTimestamp(timestamp)!;
    final t = DateTime.utc(
            d.year, d.month, d.day, d.hour, d.minute, d.second, d.millisecond)
        .millisecondsSinceEpoch
        .toDouble();
    if (times.length == 1) return 0;
    var lo = 0;
    var hi = times.length - 1;
    while (lo < hi) {
      final mid = (lo + hi) ~/ 2;
      if (times[mid] < t) {
        lo = mid + 1;
      } else {
        hi = mid;
      }
    }
    final i = (lo - 1).clamp(0, times.length - 2);
    final gap = times[i + 1] - times[i];
    return i + (gap == 0 ? 0 : (t - times[i]) / gap);
  }

  String _timestamp(double x) => DateTime.fromMillisecondsSinceEpoch(
          _time(start + x * slots - leading - .5).round(),
          isUtc: true)
      .toIso8601String()
      .replaceFirst('Z', '');

  int? candleIndex(double x) {
    if (!usable) return null;
    final index = (start + x.clamp(0.0, 1.0) * slots - leading).floor();
    return index < start || index >= end ? null : index;
  }

  // Snap to the nearest OHLC of the actual bar at this trading slot.
  ({double x, double y}) snap(double x, double y) {
    final index = candleIndex(x);
    if (index == null || index >= times.length) return (x: x, y: y);
    for (final candle in priceCandles) {
      final at = parseCandleTimestamp(candle.timestamp);
      if (at == null) continue;
      final time =
          DateTime.utc(at.year, at.month, at.day, at.hour, at.minute, at.second)
              .millisecondsSinceEpoch
              .toDouble();
      if (time != times[index]) continue;
      final price = scale.price(y);
      final levels = [candle.open, candle.high, candle.low, candle.close]
        ..sort((a, b) => (a - price).abs().compareTo((b - price).abs()));
      return (
        x: (index - start + leading + .5) / slots,
        y: scale.y(levels.first)
      );
    }
    return (x: x, y: y);
  }

  ChartDrawingAnnotation capture(ChartDrawingAnnotation drawing) {
    if (!usable) return drawing;
    return drawing.copyWith(
        startTime: _timestamp(drawing.startX),
        startPrice: scale.price(drawing.startY),
        endTime: _timestamp(drawing.endX),
        endPrice: scale.price(drawing.endY));
  }

  ChartDrawingAnnotation project(ChartDrawingAnnotation drawing) {
    if (!drawing.anchored || !usable) return drawing;
    return drawing.copyWith(
        startX: (_index(drawing.startTime!) - start + leading + .5) / slots,
        endX: (_index(drawing.endTime!) - start + leading + .5) / slots,
        startY: scale.y(drawing.startPrice!),
        endY: scale.y(drawing.endPrice!));
  }
}
