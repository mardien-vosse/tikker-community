import 'package:flutter_riverpod/flutter_riverpod.dart';

final paneLayoutProvider = StateProvider<PaneLayout>(
  (ref) => const PaneLayout(left: 280, right: 340),
);

class PaneLayout {
  const PaneLayout(
      {required this.left, required this.right, this.rightVisible = true});

  final double left;
  final double right;
  final bool rightVisible;

  PaneLayout copyWith({double? left, double? right, bool? rightVisible}) {
    return PaneLayout(
      left: left ?? this.left,
      right: right ?? this.right,
      rightVisible: rightVisible ?? this.rightVisible,
    );
  }
}
