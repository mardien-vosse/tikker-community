import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/vosse_theme.dart';
import '../../providers/market_providers.dart';
import '../../shared/utils/formatters.dart';
import '../chart/chart_panel.dart';
import '../chart/chart_state.dart';
import 'demo_market_data.dart';
import 'demo_providers.dart';

class TikkerDemoApp extends StatelessWidget {
  const TikkerDemoApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Tikker Community Preview',
        debugShowCheckedModeBanner: false,
        theme: VosseTheme.dark(),
        home: const _DemoWorkspace(),
      );
}

class _DemoWorkspace extends ConsumerStatefulWidget {
  const _DemoWorkspace();
  @override
  ConsumerState<_DemoWorkspace> createState() => _DemoWorkspaceState();
}

class _DemoWorkspaceState extends ConsumerState<_DemoWorkspace> {
  Timer? _timer;

  void _pause() {
    _timer?.cancel();
    _timer = null;
    ref.read(demoReplayPlayingProvider.notifier).state = false;
  }

  void _toggleReplay() {
    if (ref.read(demoReplayPlayingProvider)) {
      _pause();
      return;
    }
    if (ref.read(demoReplayProvider) >= DemoMarketData.maxReplaySteps) return;
    ref.read(demoReplayPlayingProvider.notifier).state = true;
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      ref.read(demoReplayProvider.notifier).advance();
      if (ref.read(demoReplayProvider) >= DemoMarketData.maxReplaySteps) {
        _pause();
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final step = ref.watch(demoReplayProvider);
    final playing = ref.watch(demoReplayPlayingProvider);
    final timeframe = ref.watch(chartTimeframeProvider);
    final selected = ref.watch(selectedSymbolProvider);
    final last = DemoMarketData.candles(selected, timeframe, step: step).last;
    return Scaffold(
        body: SafeArea(
            child: Column(children: [
      Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: const BoxDecoration(
            color: Color(0xFF10251F),
            border: Border(bottom: BorderSide(color: Color(0xFF285848)))),
        child: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Tikker Community Preview',
                  style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
              SizedBox(height: 4),
              Text('가상 시세로 자유롭게 탐색하세요 · 실제 투자 데이터가 아닙니다',
                  style: TextStyle(color: Color(0xFFA9E8CA))),
            ]),
      ),
      Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          child: Align(
              alignment: Alignment.centerLeft,
              child: Wrap(
                spacing: 8,
                runSpacing: 4,
                crossAxisAlignment: WrapCrossAlignment.center,
                children: [
                  IconButton(
                      tooltip: '오픈소스 라이선스',
                      onPressed: () => showLicensePage(
                          context: context,
                          applicationName: 'Tikker Community Preview',
                          applicationVersion: '0.1.0'),
                      icon: const Icon(Icons.info_outline)),
                  ...[
                    OutlinedButton.icon(
                        key: const ValueKey('demo-replay-toggle'),
                        onPressed:
                            step >= DemoMarketData.maxReplaySteps && !playing
                                ? null
                                : _toggleReplay,
                        icon: Icon(playing ? Icons.pause : Icons.play_arrow,
                            size: 17),
                        label: Text(playing ? '재생 일시정지' : '가상 시세 재생')),
                    OutlinedButton(
                        key: const ValueKey('demo-replay-step'),
                        onPressed: playing ||
                                step >= DemoMarketData.maxReplaySteps
                            ? null
                            : () =>
                                ref.read(demoReplayProvider.notifier).advance(),
                        child: const Text('한 단계')),
                    TextButton(
                        key: const ValueKey('demo-replay-reset'),
                        onPressed: () {
                          _pause();
                          ref.read(demoReplayProvider.notifier).reset();
                        },
                        child: const Text('시세 처음으로')),
                  ],
                ],
              ))),
      Expanded(child: LayoutBuilder(builder: (context, constraints) {
        const panel =
            ChartPanel(allowDiagnostics: false, showHeaderActions: false);
        if (constraints.maxWidth >= 940) {
          return const Row(children: [
            SizedBox(width: 220, child: _DemoWatchlist()),
            Expanded(child: panel)
          ]);
        }
        return const Column(children: [
          SizedBox(height: 88, child: _CompactWatchlist()),
          Expanded(child: panel)
        ]);
      })),
      Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
          color: VosseColors.bgPanel,
          child: Text(
              '직접 생성 · 가상 시각 ${last.timestamp.substring(0, 16).replaceFirst('T', ' ')} · '
              '${playing ? '재생 중' : step == DemoMarketData.maxReplaySteps ? '재생 완료' : '일시정지'} '
              '$step/${DemoMarketData.maxReplaySteps} · 선과 배치는 이 기기에 저장',
              style:
                  const TextStyle(fontSize: 11, color: VosseColors.textMuted),
              maxLines: 2,
              overflow: TextOverflow.ellipsis)),
    ])));
  }
}

class _DemoWatchlist extends ConsumerWidget {
  const _DemoWatchlist();
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final stocks = ref.watch(displayWatchlistProvider);
    final selected = ref.watch(selectedSymbolProvider);
    return DecoratedBox(
        decoration: const BoxDecoration(
            color: VosseColors.bgPanel,
            border: Border(right: BorderSide(color: VosseColors.border))),
        child: Column(children: [
          const Padding(
              padding: EdgeInsets.all(12),
              child: Text('관심종목 · 가상 4종',
                  style: TextStyle(fontWeight: FontWeight.w700))),
          Expanded(
              child: ReorderableListView.builder(
                  buildDefaultDragHandles: false,
                  itemCount: stocks.length,
                  onReorder: (oldIndex, newIndex) =>
                      reorderWatchlistStock(ref, oldIndex, newIndex),
                  itemBuilder: (context, index) {
                    final stock = stocks[index];
                    return ListTile(
                        key: ValueKey('demo-watch-${stock.symbol}'),
                        selected: stock.symbol == selected,
                        selectedTileColor: VosseColors.bgElevated,
                        title: Text(stock.name,
                            style: const TextStyle(fontSize: 13)),
                        subtitle: Text(
                            '${stock.symbol}\n${stockPriceText(stock)} · ${percentText(stock.changePercent)}',
                            style: const TextStyle(fontSize: 11)),
                        isThreeLine: true,
                        trailing: ReorderableDragStartListener(
                            index: index,
                            child: const Icon(Icons.drag_indicator, size: 18)),
                        onTap: () => ref
                            .read(selectedSymbolProvider.notifier)
                            .state = stock.symbol);
                  })),
          TextButton.icon(
              onPressed: () => _editWatchlist(context),
              icon: const Icon(Icons.star_outline, size: 17),
              label: const Text('관심종목 선택')),
          const Padding(
              padding: EdgeInsets.all(12),
              child: Text('종목명·가격·거래량·시각은 모두 가상입니다.\n등락률은 직전 가상 봉 대비입니다.',
                  style:
                      TextStyle(fontSize: 11, color: VosseColors.textMuted))),
        ]));
  }
}

class _CompactWatchlist extends ConsumerWidget {
  const _CompactWatchlist();
  @override
  Widget build(BuildContext context, WidgetRef ref) =>
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Padding(
            padding: EdgeInsets.symmetric(horizontal: 12),
            child: Text('직접 생성한 가상 종목 · 가격 단위 임의',
                style: TextStyle(fontSize: 11, color: VosseColors.textMuted))),
        Expanded(
            child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 10),
                children: [
              for (final stock in ref.watch(displayWatchlistProvider))
                Padding(
                    padding: const EdgeInsets.only(right: 7),
                    child: ChoiceChip(
                        label: Text(stock.name),
                        selected:
                            stock.symbol == ref.watch(selectedSymbolProvider),
                        onSelected: (_) => ref
                            .read(selectedSymbolProvider.notifier)
                            .state = stock.symbol)),
              IconButton(
                  tooltip: '관심종목 선택',
                  onPressed: () => _editWatchlist(context),
                  icon: const Icon(Icons.star_outline)),
            ])),
      ]);
}

void _editWatchlist(BuildContext context) => showDialog<void>(
    context: context,
    builder: (context) => Consumer(builder: (context, ref, _) {
          final stocks = ref.watch(watchlistProvider);
          final symbols = stocks.map((stock) => stock.symbol).toSet();
          return AlertDialog(
              title: const Text('관심종목 선택'),
              content: Column(mainAxisSize: MainAxisSize.min, children: [
                for (final symbol in DemoMarketData.symbols)
                  CheckboxListTile(
                      title: Text(DemoMarketData.stock(symbol).name),
                      subtitle: Text(symbol),
                      value: symbols.contains(symbol),
                      onChanged: (checked) {
                        if (checked == true) {
                          ref.read(watchlistProvider.notifier).state = [
                            ...stocks,
                            DemoMarketData.stock(symbol)
                          ];
                        } else if (stocks.length > 1) {
                          if (ref.read(selectedSymbolProvider) == symbol) {
                            ref.read(selectedSymbolProvider.notifier).state =
                                stocks
                                    .firstWhere(
                                        (stock) => stock.symbol != symbol)
                                    .symbol;
                          }
                          ref.read(watchlistProvider.notifier).state = stocks
                              .where((stock) => stock.symbol != symbol)
                              .toList();
                        }
                      }),
              ]),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('완료'))
              ]);
        }));
