import 'dart:math' as math;

import '../chart/chart_state.dart';
import '../../shared/models/market_models.dart';

/// Independent fictional series. No real tickers, provider data or sample feed.
class DemoMarketData {
  static const symbols = ['DEMO001', 'DEMO002', 'DEMO003', 'DEMO004'];
  static const initialBars = 120;
  static const maxReplaySteps = 180;

  static bool contains(String symbol) => symbols.contains(symbol);

  static List<CandlePoint> candles(
    String symbol,
    ChartTimeframe timeframe, {
    int step = 0,
  }) {
    final symbolIndex = symbols.indexOf(symbol);
    if (symbolIndex < 0) throw ArgumentError.value(symbol, 'symbol');
    if (step < 0 || step > maxReplaySteps) {
      throw RangeError.range(step, 0, maxReplaySteps, 'step');
    }
    final base = 1000.0 + symbolIndex * 750;
    double closeAt(int i) =>
        base +
        math.sin((i + symbolIndex * 13) / (9 + symbolIndex)) * base * .025 +
        math.cos(i / 3.7 + symbolIndex) * base * .005 +
        i * (symbolIndex.isEven ? .45 : -.25);
    return List.generate(initialBars + step, (i) {
      final open = closeAt(i - 1);
      final close = closeAt(i);
      final wick = base * (.002 + (i % 5) * .0003);
      return CandlePoint(
        open: open,
        high: math.max(open, close) + wick,
        low: math.min(open, close) - wick,
        close: close,
        volume: 200.0 + ((i * 73 + symbolIndex * 137) % 1700),
        timestamp: _timeAt(i, timeframe).toIso8601String(),
      );
    }, growable: false);
  }

  static DateTime _timeAt(int i, ChartTimeframe timeframe) {
    final origin = DateTime.utc(2025, 1, 6, timeframe.isIntraday ? 9 : 0);
    if (timeframe.isIntraday) {
      return origin.add(Duration(minutes: i * timeframe.aggregationMinutes));
    }
    return switch (timeframe) {
      ChartTimeframe.week => origin.add(Duration(days: i * 7)),
      ChartTimeframe.month => DateTime.utc(2001, 1 + i, 1),
      ChartTimeframe.year => DateTime.utc(1800 + i, 1, 1),
      _ => origin.add(Duration(days: i)),
    };
  }

  static MarketStock stock(
    String symbol, {
    int step = 0,
    ChartTimeframe timeframe = ChartTimeframe.minute,
  }) {
    final data = candles(symbol, timeframe, step: step);
    final latest = data.last;
    final previous = data[data.length - 2].close;
    final change = latest.close - previous;
    return MarketStock(
      symbol: symbol,
      name: '가상 종목 ${symbols.indexOf(symbol) + 1}',
      market: 'DEMO',
      sector: '직접 생성 · 가격 단위 임의',
      price: latest.close.round(),
      quotePrice: latest.close,
      change: change.round(),
      quoteChange: change,
      changePercent: change / previous * 100,
      volume: latest.volume.round(),
      score: 0, // The legacy model requires this field; it is never displayed.
    );
  }
}
