import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../providers/app_preferences.dart';
import '../../providers/market_providers.dart';
import '../../shared/models/market_data_source.dart';
import '../chart/chart_state.dart';
import 'demo_market_data.dart';

const demoPreferencesNamespace = 'tikker.community.v1';
final demoReplayProvider = StateNotifierProvider<DemoReplayController, int>(
    (ref) => DemoReplayController());
final demoReplayPlayingProvider = StateProvider<bool>((ref) => false);

class DemoReplayController extends StateNotifier<int> {
  DemoReplayController() : super(0);
  void advance() {
    if (state < DemoMarketData.maxReplaySteps) state++;
  }

  void reset() => state = 0;
}

/// Restore local preferences; every provider uses generated data only.
List<Override> demoProviderOverrides(AppPreferencesStore store) {
  final saved = store.load();
  final symbols =
      saved.watchlistSymbols.where(DemoMarketData.contains).toList();
  final watchSymbols = symbols.isEmpty ? DemoMarketData.symbols : symbols;
  final selected = watchSymbols.contains(saved.selectedSymbol)
      ? saved.selectedSymbol
      : watchSymbols.first;
  final wasSaved = DemoMarketData.contains(saved.selectedSymbol);
  final timeframe = wasSaved ? saved.timeframe : ChartTimeframe.minute;
  return [
    appPreferencesStoreProvider.overrideWithValue(store),
    selectedSymbolProvider.overrideWith((ref) => selected),
    watchlistProvider.overrideWith((ref) => [
          for (final symbol in watchSymbols) DemoMarketData.stock(symbol),
        ]),
    displayWatchlistProvider.overrideWith((ref) {
      final step = ref.watch(demoReplayProvider);
      final timeframe = ref.watch(chartTimeframeProvider);
      return [
        for (final stock in ref.watch(watchlistProvider))
          DemoMarketData.stock(stock.symbol, step: step, timeframe: timeframe),
      ];
    }),
    liveWatchlistProvider
        .overrideWith((ref) async => ref.watch(displayWatchlistProvider)),
    selectedStockProvider.overrideWith((ref) => DemoMarketData.stock(
          ref.watch(selectedSymbolProvider),
          step: ref.watch(demoReplayProvider),
          timeframe: ref.watch(chartTimeframeProvider),
        )),
    liveSelectedStockProvider
        .overrideWith((ref) async => ref.watch(selectedStockProvider)),
    candleProvider.overrideWith((ref) => DemoMarketData.candles(
          ref.watch(selectedSymbolProvider),
          ref.watch(chartTimeframeProvider),
          step: ref.watch(demoReplayProvider),
        )),
    liveCandleProvider
        .overrideWith((ref) => Stream.value(ref.watch(candleProvider))),
    multiChartCandlesProvider.overrideWith((ref) => Stream.value({
          for (final symbol in DemoMarketData.symbols)
            symbol: DemoMarketData.candles(
              symbol,
              ref.watch(chartTimeframeProvider),
              step: ref.watch(demoReplayProvider),
            ),
        })),
    liveComparisonCandlesProvider.overrideWith((ref) => Stream.value({
          for (final symbol in ref
              .watch(chartComparisonSymbolsProvider)
              .where(DemoMarketData.contains))
            symbol: DemoMarketData.candles(
              symbol,
              ref.watch(chartTimeframeProvider),
              step: ref.watch(demoReplayProvider),
            ),
        })),
    selectedCandleSourceProvider.overrideWithValue(MarketDataSource.generated),
    selectedStockSourceProvider.overrideWithValue(MarketDataSource.generated),
    chartTimeframeProvider.overrideWith((ref) => timeframe),
    chartMultiLayoutProvider.overrideWith(
        (ref) => wasSaved ? saved.multiLayout : ChartMultiLayout.fourGrid),
    chartMultiSymbolsProvider.overrideWith(
        (ref) => saved.multiSymbols.where(DemoMarketData.contains).toList()),
    chartRenderModeProvider.overrideWith((ref) => saved.renderMode),
    chartIndicatorVisibilityProvider.overrideWith((ref) => saved.indicators),
    chartVolumeVisibleProvider.overrideWith((ref) => saved.volumeVisible),
    chartComparisonEnabledProvider
        .overrideWith((ref) => saved.comparisonEnabled),
    chartComparisonSymbolsProvider.overrideWith((ref) =>
        saved.comparisonSymbols.where(DemoMarketData.contains).toSet()),
    chartHiddenComparisonSymbolsProvider.overrideWith((ref) =>
        saved.hiddenComparisonSymbols.where(DemoMarketData.contains).toSet()),
    chartDrawingAnnotationsProvider.overrideWith((ref) =>
        store.loadDrawingAnnotations(symbol: selected, timeframe: timeframe)),
    menuHelpEnabledProvider.overrideWith((ref) => saved.menuHelpEnabled),
  ];
}
