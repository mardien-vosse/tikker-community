import 'package:flutter_riverpod/flutter_riverpod.dart';

final watchlistDisplaySettingsProvider =
    StateProvider<WatchlistDisplaySettings>(
  (ref) => const WatchlistDisplaySettings(),
);

enum WatchlistDeltaBasis {
  previousClose,
  lastTrade,
}

class WatchlistDisplaySettings {
  const WatchlistDisplaySettings({
    this.showRowSeparators = false,
    this.showVolume = true,
    this.showChangeAmount = true,
    this.showCandleMarker = true,
    this.showMemo = true,
    this.showAfterHoursDomestic = false,
    this.showAfterHoursForeign = true,
    this.flashPriceChanges = true,
    this.deltaBasis = WatchlistDeltaBasis.previousClose,
    this.showSpecialTags = false,
  });

  final bool showRowSeparators;
  final bool showVolume;
  final bool showChangeAmount;
  final bool showCandleMarker;
  final bool showMemo;
  final bool showAfterHoursDomestic;
  final bool showAfterHoursForeign;
  final bool flashPriceChanges;
  final WatchlistDeltaBasis deltaBasis;
  final bool showSpecialTags;

  WatchlistDisplaySettings copyWith({
    bool? showRowSeparators,
    bool? showVolume,
    bool? showChangeAmount,
    bool? showCandleMarker,
    bool? showMemo,
    bool? showAfterHoursDomestic,
    bool? showAfterHoursForeign,
    bool? flashPriceChanges,
    WatchlistDeltaBasis? deltaBasis,
    bool? showSpecialTags,
  }) {
    return WatchlistDisplaySettings(
      showRowSeparators: showRowSeparators ?? this.showRowSeparators,
      showVolume: showVolume ?? this.showVolume,
      showChangeAmount: showChangeAmount ?? this.showChangeAmount,
      showCandleMarker: showCandleMarker ?? this.showCandleMarker,
      showMemo: showMemo ?? this.showMemo,
      showAfterHoursDomestic:
          showAfterHoursDomestic ?? this.showAfterHoursDomestic,
      showAfterHoursForeign:
          showAfterHoursForeign ?? this.showAfterHoursForeign,
      flashPriceChanges: flashPriceChanges ?? this.flashPriceChanges,
      deltaBasis: deltaBasis ?? this.deltaBasis,
      showSpecialTags: showSpecialTags ?? this.showSpecialTags,
    );
  }
}
