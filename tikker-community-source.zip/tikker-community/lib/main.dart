import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'features/chart/chart_state.dart';
import 'features/demo/demo_app.dart';
import 'features/demo/demo_market_data.dart';
import 'features/demo/demo_providers.dart';
import 'providers/app_preferences.dart';

/// Separate entry point: never initializes private routing, Firebase or KIS.
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  LicenseRegistry.addLicense(() async* {
    yield LicenseEntryWithLineBreaks(
        ['Noto Sans KR'], await rootBundle.loadString('assets/fonts/OFL.txt'));
  });
  final store = await SharedPreferencesAppPreferencesStore.create(
      namespace: demoPreferencesNamespace);
  if (!DemoMarketData.contains(store.load().selectedSymbol)) {
    await store.saveSelectedSymbol(DemoMarketData.symbols.first);
    await store.saveWatchlistSymbols(DemoMarketData.symbols);
    await store.saveTimeframe(ChartTimeframe.minute);
    await store.saveMultiLayout(ChartMultiLayout.fourGrid);
  }
  runApp(ProviderScope(
    overrides: demoProviderOverrides(store),
    child: const AppPreferencesBinder(
      child: TikkerDemoApp(),
    ),
  ));
}
