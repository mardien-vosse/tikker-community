import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/vosse_theme.dart';
import '../../providers/app_preferences.dart';

enum MenuHelpPlacement { right, left, below, above }

class MenuTermHelp extends StatelessWidget {
  const MenuTermHelp({
    required this.term,
    required this.child,
    this.description,
    this.placement = MenuHelpPlacement.below,
    super.key,
  });

  final String term;
  final String? description;
  final Widget child;
  final MenuHelpPlacement placement;

  @override
  Widget build(BuildContext context) {
    final help = description ?? menuTermHelpDescription(term);
    if (help == null || help.isEmpty) return child;
    return MenuHelp(
      title: term,
      description: help,
      placement: placement,
      child: child,
    );
  }
}

class MenuHelp extends StatefulWidget {
  const MenuHelp({
    required this.title,
    required this.description,
    required this.child,
    this.placement = MenuHelpPlacement.right,
    super.key,
  });

  final String title;
  final String description;
  final Widget child;
  final MenuHelpPlacement placement;

  @override
  State<MenuHelp> createState() => _MenuHelpState();
}

class _MenuHelpState extends State<MenuHelp> {
  final LayerLink _link = LayerLink();
  OverlayEntry? _entry;
  ProviderSubscription<bool>? _helpSubscription;
  bool _helpEnabled = true;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _bindMenuHelpProvider();
  }

  @override
  void dispose() {
    _helpSubscription?.close();
    _hide();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return CompositedTransformTarget(
      link: _link,
      child: MouseRegion(
        onEnter: (_) => _show(),
        onExit: (_) => _hide(),
        child: Focus(
          onFocusChange: (focused) => focused ? _show() : _hide(),
          child: widget.child,
        ),
      ),
    );
  }

  void _bindMenuHelpProvider() {
    _helpSubscription?.close();
    _helpSubscription = null;

    final container = _maybeProviderContainer(context);
    if (container == null) {
      // Why: isolated widget tests and story-like renders should not crash just because the app shell is absent.
      _helpEnabled = true;
      return;
    }

    final enabled = container.read(menuHelpEnabledProvider);
    _helpEnabled = enabled;
    if (!enabled) _hide();
    _helpSubscription = container.listen<bool>(
      menuHelpEnabledProvider,
      (_, enabled) {
        if (!mounted) return;
        if (!enabled) _hide();
        setState(() => _helpEnabled = enabled);
      },
    );
  }

  ProviderContainer? _maybeProviderContainer(BuildContext context) {
    try {
      return ProviderScope.containerOf(context, listen: false);
    } on Object {
      return null;
    }
  }

  void _show() {
    if (_entry != null || !_helpEnabled) return;
    final overlay = Overlay.maybeOf(context);
    if (overlay == null) return;
    final geometry = _geometryFor(context, widget.placement);
    final transform = geometry.transform;
    _entry = OverlayEntry(
      builder: (context) => Positioned.fill(
        child: IgnorePointer(
          child: CompositedTransformFollower(
            link: _link,
            showWhenUnlinked: false,
            targetAnchor: transform.targetAnchor,
            followerAnchor: transform.followerAnchor,
            offset: transform.offset,
            child: Align(
              alignment: transform.followerAnchor,
              widthFactor: 1,
              heightFactor: 1,
              child: _MenuHelpBubble(
                title: widget.title,
                description: widget.description,
                width: geometry.width,
              ),
            ),
          ),
        ),
      ),
    );
    overlay.insert(_entry!);
  }

  void _hide() {
    _entry?.remove();
    _entry = null;
  }
}

class MenuHelpToggleButton extends ConsumerWidget {
  const MenuHelpToggleButton({this.compact = false, super.key});

  final bool compact;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final enabled = ref.watch(menuHelpEnabledProvider);
    return Tooltip(
      message: enabled ? '메뉴 설명 끄기' : '메뉴 설명 켜기',
      child: IconButton(
        onPressed: () {
          ref.read(menuHelpEnabledProvider.notifier).state = !enabled;
        },
        icon: Icon(
          enabled ? Icons.help_center_rounded : Icons.help_outline_rounded,
          size: compact ? 18 : 20,
        ),
        color: enabled ? VosseColors.accent : VosseColors.textMuted,
        visualDensity: VisualDensity.compact,
        constraints: BoxConstraints.tightFor(
          width: compact ? 34 : 36,
          height: compact ? 34 : 36,
        ),
        padding: EdgeInsets.zero,
      ),
    );
  }
}

class _MenuHelpBubble extends StatelessWidget {
  const _MenuHelpBubble({
    required this.title,
    required this.description,
    required this.width,
  });

  final String title;
  final String description;
  final double width;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: Container(
        key: const ValueKey('menu-help-bubble'),
        width: width,
        padding: const EdgeInsets.fromLTRB(10, 8, 10, 9),
        decoration: BoxDecoration(
          color: const Color(0xFF101219),
          border: Border.all(color: VosseColors.accent.withValues(alpha: .42)),
          borderRadius: BorderRadius.circular(6),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: .35),
              blurRadius: 18,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: VosseColors.textPrimary,
                fontSize: 12,
                height: 1.1,
                fontWeight: FontWeight.w900,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              description,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: VosseColors.textSecondary,
                fontSize: 11,
                height: 1.28,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

_MenuHelpTransform _transformFor(MenuHelpPlacement placement) {
  return switch (placement) {
    MenuHelpPlacement.left => const _MenuHelpTransform(
        targetAnchor: Alignment.centerLeft,
        followerAnchor: Alignment.centerRight,
        offset: Offset(-8, 0),
      ),
    MenuHelpPlacement.below => const _MenuHelpTransform(
        targetAnchor: Alignment.bottomCenter,
        followerAnchor: Alignment.topCenter,
        offset: Offset(0, 8),
      ),
    MenuHelpPlacement.above => const _MenuHelpTransform(
        targetAnchor: Alignment.topCenter,
        followerAnchor: Alignment.bottomCenter,
        offset: Offset(0, -8),
      ),
    MenuHelpPlacement.right => const _MenuHelpTransform(
        targetAnchor: Alignment.centerRight,
        followerAnchor: Alignment.centerLeft,
        offset: Offset(8, 0),
      ),
  };
}

_MenuHelpGeometry _geometryFor(
  BuildContext context,
  MenuHelpPlacement preferredPlacement,
) {
  final screenSize = MediaQuery.maybeSizeOf(context) ??
      _logicalViewSize(context) ??
      const Size(1024, 768);
  final targetRect = _globalTargetRect(context);
  final width = math.min(
    _menuHelpPreferredWidth,
    math.max(120.0, screenSize.width - (_menuHelpScreenMargin * 2)),
  );
  if (targetRect == null) {
    return _MenuHelpGeometry(
      width: width,
      transform: _transformFor(preferredPlacement),
    );
  }

  final placement =
      _resolvePlacement(preferredPlacement, targetRect, screenSize, width);
  final base = _transformFor(placement);
  final offset = _clampedOffset(
    placement: placement,
    baseOffset: base.offset,
    bubbleWidth: width,
    screenSize: screenSize,
    targetRect: targetRect,
  );
  return _MenuHelpGeometry(
    width: width,
    transform: _MenuHelpTransform(
      targetAnchor: base.targetAnchor,
      followerAnchor: base.followerAnchor,
      offset: offset,
    ),
  );
}

MenuHelpPlacement _resolvePlacement(
  MenuHelpPlacement preferredPlacement,
  Rect targetRect,
  Size screenSize,
  double bubbleWidth,
) {
  final rightSpace = screenSize.width -
      targetRect.right -
      _menuHelpGap -
      _menuHelpScreenMargin;
  final leftSpace = targetRect.left - _menuHelpGap - _menuHelpScreenMargin;
  final belowSpace = screenSize.height -
      targetRect.bottom -
      _menuHelpGap -
      _menuHelpScreenMargin;
  final aboveSpace = targetRect.top - _menuHelpGap - _menuHelpScreenMargin;

  return switch (preferredPlacement) {
    MenuHelpPlacement.right
        when rightSpace < bubbleWidth && leftSpace > rightSpace =>
      MenuHelpPlacement.left,
    MenuHelpPlacement.left
        when leftSpace < bubbleWidth && rightSpace > leftSpace =>
      MenuHelpPlacement.right,
    // Why: dense terminal panes place controls close to the bottom edge; flipping
    // keeps the explanation readable instead of letting it leave the viewport.
    MenuHelpPlacement.below
        when belowSpace < _menuHelpEstimatedHeight && aboveSpace > belowSpace =>
      MenuHelpPlacement.above,
    MenuHelpPlacement.above
        when aboveSpace < _menuHelpEstimatedHeight && belowSpace > aboveSpace =>
      MenuHelpPlacement.below,
    _ => preferredPlacement,
  };
}

Offset _clampedOffset({
  required MenuHelpPlacement placement,
  required Offset baseOffset,
  required double bubbleWidth,
  required Size screenSize,
  required Rect targetRect,
}) {
  if (placement == MenuHelpPlacement.below ||
      placement == MenuHelpPlacement.above) {
    final anchorX = targetRect.left + (targetRect.width / 2);
    final currentLeft = anchorX - (bubbleWidth / 2) + baseOffset.dx;
    final maxLeft = screenSize.width - _menuHelpScreenMargin - bubbleWidth;
    final clampedLeft = _clampDouble(
      currentLeft,
      _menuHelpScreenMargin,
      maxLeft,
    );
    return Offset(baseOffset.dx + clampedLeft - currentLeft, baseOffset.dy);
  }

  final anchorY = targetRect.top + (targetRect.height / 2);
  final currentTop = anchorY - (_menuHelpEstimatedHeight / 2) + baseOffset.dy;
  final maxTop =
      screenSize.height - _menuHelpScreenMargin - _menuHelpEstimatedHeight;
  final clampedTop = _clampDouble(
    currentTop,
    _menuHelpScreenMargin,
    maxTop,
  );
  return Offset(baseOffset.dx, baseOffset.dy + clampedTop - currentTop);
}

double _clampDouble(double value, double min, double max) {
  if (max < min) return min;
  return math.max(min, math.min(max, value));
}

Rect? _globalTargetRect(BuildContext context) {
  final renderObject = context.findRenderObject();
  if (renderObject is! RenderBox || !renderObject.hasSize) return null;
  return renderObject.localToGlobal(Offset.zero) & renderObject.size;
}

Size? _logicalViewSize(BuildContext context) {
  final view = View.maybeOf(context);
  if (view == null || view.devicePixelRatio == 0) return null;
  return view.physicalSize / view.devicePixelRatio;
}

const _menuHelpPreferredWidth = 218.0;
const _menuHelpEstimatedHeight = 76.0;
const _menuHelpScreenMargin = 8.0;
const _menuHelpGap = 8.0;

class _MenuHelpGeometry {
  const _MenuHelpGeometry({
    required this.width,
    required this.transform,
  });

  final double width;
  final _MenuHelpTransform transform;
}

class _MenuHelpTransform {
  const _MenuHelpTransform({
    required this.targetAnchor,
    required this.followerAnchor,
    required this.offset,
  });

  final Alignment targetAnchor;
  final Alignment followerAnchor;
  final Offset offset;
}

String? menuTermHelpDescription(String term) {
  return switch (term) {
    '차트' => '선택 종목의 캔들, 보조지표, 비교선, 드로잉을 함께 보는 중심 화면입니다.',
    '그리기' => '추세선, 수평선, 피보나치 되돌림을 차트 위에 직접 표시하는 도구입니다.',
    '비교' => '현재 종목과 다른 관심 종목의 가격 흐름을 같은 차트 위에 겹쳐 봅니다.',
    '보조지표' => 'EMA, Bollinger Band, RSI, MACD처럼 가격 흐름을 해석하는 참고 지표입니다.',
    'EMA' => '최근 가격에 더 큰 비중을 두는 이동평균선으로 단기 추세를 봅니다.',
    'Bollinger Band' => '평균선 주변 변동성 범위를 표시해 과열과 이탈 구간을 봅니다.',
    '분봉' => '1분, 3분, 5분처럼 짧은 시간 단위로 만든 캔들입니다.',
    '일봉' => '하루 가격 움직임을 하나의 캔들로 표현한 차트 단위입니다.',
    '주봉' => '일주일 가격 움직임을 하나의 캔들로 표현한 중기 차트 단위입니다.',
    '월봉' => '한 달 가격 움직임을 하나의 캔들로 표현한 장기 차트 단위입니다.',
    '연봉' => '1년 가격 움직임을 하나의 캔들로 표현한 매우 긴 기간 차트 단위입니다.',
    '시장요약' => '주요 지수, 투자자 수급, 장중 흐름을 한 화면에서 요약합니다.',
    '특징종목' => '상승/하락, 거래대금, 변동성이 큰 종목을 빠르게 확인하는 목록입니다.',
    '시장지표' => '환율, 금리, 선물, 섹터 흐름처럼 시장 배경이 되는 값을 봅니다.',
    '시장이슈' => '현재 시장을 움직이는 뉴스와 테마성 이슈를 요약해서 봅니다.',
    '종목발굴' => '관심 조건과 시장 흐름에 맞는 후보 종목을 탐색하는 화면입니다.',
    '트레이딩' => '주문, 미체결, 잔고, AI 코치 확인 흐름을 실행하는 화면입니다.',
    '주문' => '자동매매 없이 사용자 확인을 거쳐 매수·매도를 실행하는 화면입니다.',
    '미체결' => '아직 체결되지 않아 취소나 정정 가능 여부를 확인해야 하는 주문입니다.',
    '잔고' => '보유 종목, 평가 금액, 손익, 주문 가능 상태를 확인하는 영역입니다.',
    'AI 스코어' => '종목별 가격 흐름, 거래량, 리스크, 분석 신뢰도를 합친 0~100 참고 점수입니다.',
    '단타 AI 시그널' => 'Tier-1 실시간 지표와 ChatGPT 판단을 합쳐 진입 여부를 보여주는 단타 보조 신호입니다.',
    'Tier-1' => 'KIS tick/호가 데이터를 100ms 단위로 계산하는 로컬 신호 엔진입니다.',
    'LIVE_TIER1' => '현재 화면의 단타 점수가 실시간 KIS 데이터 기반 Tier-1 엔진에서 왔다는 뜻입니다.',
    'OBI' => '호가 불균형입니다. 매수1호가 잔량과 매도1호가 잔량 차이로 단기 수급 압력을 봅니다.',
    'VWAP' => '거래량 가중 평균가입니다. 현재가가 당일 평균 체결 가격보다 위/아래인지 보는 기준입니다.',
    'RSI' => '상승과 하락 압력을 0~100으로 보는 과열/침체 보조지표입니다.',
    'MACD' => '짧은 이동평균과 긴 이동평균의 차이로 추세 전환 가능성을 보는 보조지표입니다.',
    '거래량' => '해당 기간 동안 실제로 거래된 주식 수입니다. 급증하면 관심과 변동성이 커진 상태입니다.',
    '거래대금' => '거래량에 가격을 곱한 금액입니다. 큰돈이 들어왔는지 보는 유동성 기준입니다.',
    '현재가' => '주문 화면에서 기준으로 보는 최신 가격입니다. 주문 전 KIS 데이터 출처를 함께 확인하세요.',
    '주문유형' => '시장가와 지정가 중 어떤 방식으로 주문할지 고르는 항목입니다.',
    '시장가' => '가격을 직접 지정하지 않고 현재 체결 가능한 가격으로 빠르게 주문하는 방식입니다.',
    '지정가' => '사용자가 입력한 가격 조건에 맞을 때만 체결되도록 주문하는 방식입니다.',
    '수량' => '주문할 주식 수입니다. 예상금액과 잔고를 함께 확인해야 합니다.',
    '주문단가' => '시장가 주문은 현재가 기준, 지정가 주문은 입력 가격 기준으로 표시되는 1주당 가격입니다.',
    '예상금액' => '주문단가와 수량을 곱한 참고 금액입니다. 실제 체결 금액은 수수료와 체결 가격에 따라 달라질 수 있습니다.',
    '진입' => 'AI 시그널 기준으로 매수를 고려할 수 있는 참고 가격입니다. 자동 주문은 실행하지 않습니다.',
    '손절' => '예상과 다르게 움직일 때 손실을 제한하기 위해 참고할 가격입니다.',
    '익절' => '목표 수익을 확보하기 위해 참고할 가격입니다. 기본 R:R은 1:1.5 기준입니다.',
    '왜 지금인가' => 'OBI, 거래량 스파이크, RSI, VWAP, 체결 강도 등 현재 신호의 핵심 근거입니다.',
    '종목분석' => '제공된 차트/재무 데이터를 종합한 중기 관점 분석 상태입니다.',
    '단타판단' => '실시간 Tier-1 점수와 ChatGPT 판단을 합친 단기 진입 판단입니다.',
    '데이터' => 'KIS LIVE, KIS REST, 모의 데이터 등 현재 카드가 사용한 데이터 출처입니다.',
    '위험' => 'AI 신호의 과열, 만료, 데이터 지연, 필터 차단 같은 주의 조건입니다.',
    'AI 밸류에이션 레인지' => 'Bull/Base/Bear 시나리오를 반영한 AI 적정가 범위입니다.',
    '뉴스·소셜 감성' => '분석에 제공된 자료의 분위기를 요약합니다. 실시간 뉴스·소셜 검색은 포함하지 않습니다.',
    'AI 신뢰도' => '입력 데이터 품질과 모델 응답 안정성을 함께 본 참고 신뢰도입니다.',
    '핵심 리스크' => '해당 종목을 보기 전에 반드시 확인해야 할 주요 위험 요인입니다.',
    '차트 데이터' => 'KIS 캔들과 앱 내부 집계 캔들이 주문 전 기준을 통과했는지 보는 카드입니다.',
    'KIS 캔들' => 'KIS 조회 데이터로 받은 원본 캔들입니다. 1분봉은 실시간 집계의 기준입니다.',
    '캔들' => '시가, 고가, 저가, 종가를 한 막대로 표현한 차트 단위입니다.',
    'Socket.IO' => '백엔드와 앱 사이에서 실시간 데이터를 전달하는 연결입니다.',
    'Quote room' => '선택 종목 실시간 데이터를 구독하는 앱 클라이언트 방입니다.',
    'KIS stream' => '한국투자증권 WebSocket으로 들어오는 실시간 시세/호가 스트림입니다.',
    '시장 상태' => '정규장, 장외, 휴장 여부에 따라 실시간 데이터 기대치를 구분합니다.',
    'MVP gate' => '개인 MVP 기준을 통과했는지 보는 자동 검증 관문입니다.',
    '마지막 검증' => '가장 최근 실행된 실시간/차트 검증 결과 요약입니다.',
    '최근 1시간 gate' => '장중 1시간 이상 실시간 시세와 호가를 안정적으로 받은 검증 결과입니다.',
    '차트 live' => '실시간 tick이 앱 내부 캔들로 변환되어 차트에 반영되는지 본 smoke 결과입니다.',
    '차트 판단' => '차트 live smoke가 실제 판단 데이터까지 연결됐는지 보는 요약입니다.',
    '차트 검토' => '기본 연결은 됐지만 샘플 간격이나 종료 간격이 커서 다음 장중 재검증이 필요한 상태입니다.',
    '검증 기준' => 'MVP-ready로 인정하기 위해 필요한 quote, fresh sample, LIVE_TIER1 기준입니다.',
    '실시간 상태' => '앱, 백엔드, KIS WebSocket, 실시간 신호가 현재 연결되어 있는지 보는 운영 카드입니다.',
    _ => null,
  };
}
