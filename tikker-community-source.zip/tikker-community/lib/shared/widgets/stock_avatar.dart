import 'package:flutter/material.dart';

class StockAvatar extends StatelessWidget {
  const StockAvatar({
    required this.label,
    this.size = 40,
    this.logoUrl,
    super.key,
  });

  final String label;
  final double size;
  final String? logoUrl;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: Colors.white.withValues(alpha: .10)),
      ),
      clipBehavior: Clip.antiAlias,
      child: _FallbackAvatar(label: label, size: size),
    );
  }
}

class _FallbackAvatar extends StatelessWidget {
  const _FallbackAvatar({
    required this.label,
    required this.size,
  });

  final String label;
  final double size;

  @override
  Widget build(BuildContext context) {
    final text = label.length <= 2 ? label : label.substring(0, 2);
    return Semantics(
      label: '$label 로고',
      image: true,
      child: DecoratedBox(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF1D4ED8), Color(0xFF101827)],
          ),
        ),
        child: Center(
          child: Text(
            text,
            style: TextStyle(
              color: Colors.white,
              fontSize: size <= 34 ? 9 : 11,
              fontWeight: FontWeight.w900,
            ),
          ),
        ),
      ),
    );
  }
}
