import '../models/market_models.dart';

String priceText(int value, {String suffix = ''}) => '${_comma(value)}$suffix';

String decimalPriceText(num value, {String suffix = ''}) {
  if (value is int || value == value.roundToDouble()) {
    return '${_comma(value.round())}$suffix';
  }
  final sign = value < 0 ? '-' : '';
  final absValue = value.abs();
  final decimals = absValue < 1 ? 4 : 2;
  final fixed = absValue.toStringAsFixed(decimals);
  final parts = fixed.split('.');
  return '$sign${_comma(int.parse(parts.first))}.${parts.last}$suffix';
}

String stockPriceText(MarketStock stock, {String suffix = ''}) {
  if (stock.displayPrice <= 0 || !stock.displayPrice.isFinite) return '--';
  return decimalPriceText(stock.displayPrice, suffix: suffix);
}

String stockSignedText(MarketStock stock) {
  final value = stock.displayChange;
  final sign = value > 0 ? '+' : '';
  return '$sign${decimalPriceText(value)}';
}

String signedText(int value) {
  if (value > 0) return '+${_comma(value)}';
  return _comma(value);
}

String percentText(double value) {
  final sign = value > 0 ? '+' : '';
  return '$sign${value.toStringAsFixed(2)}%';
}

String compactVolume(int value) {
  if (value >= 100000000) return '${(value / 100000000).toStringAsFixed(1)}억';
  if (value >= 10000) return '${(value / 10000).toStringAsFixed(1)}만';
  return _comma(value);
}

String _comma(int value) {
  final raw = value.abs().toString();
  final buffer = StringBuffer();
  for (var i = 0; i < raw.length; i += 1) {
    if (i > 0 && (raw.length - i) % 3 == 0) buffer.write(',');
    buffer.write(raw[i]);
  }
  return value < 0 ? '-$buffer' : buffer.toString();
}
