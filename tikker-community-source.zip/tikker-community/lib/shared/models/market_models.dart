class MarketStock {
  const MarketStock({
    required this.symbol,
    required this.name,
    required this.market,
    required this.sector,
    required this.price,
    required this.change,
    required this.changePercent,
    required this.volume,
    required this.score,
    this.logoUrl,
    this.quotePrice,
    this.quoteChange,
    this.turnover,
  });

  final String symbol;
  final String name;
  final String market;
  final String sector;
  final int price;
  final int change;
  final double changePercent;
  final int volume;
  final int score;
  final String? logoUrl;
  final double? quotePrice;
  final double? quoteChange;
  final double? turnover;

  bool get rising => change >= 0;
  bool get isDomesticKisTicker => RegExp(r'^\d{6}$').hasMatch(symbol.trim());
  double get displayPrice => quotePrice ?? price.toDouble();
  double get displayChange => quoteChange ?? change.toDouble();

  MarketStock copyWith({
    String? name,
    String? market,
    String? sector,
    int? price,
    int? change,
    double? changePercent,
    int? volume,
    int? score,
    String? logoUrl,
    double? quotePrice,
    double? quoteChange,
    double? turnover,
  }) {
    return MarketStock(
      symbol: symbol,
      name: name ?? this.name,
      market: market ?? this.market,
      sector: sector ?? this.sector,
      price: price ?? this.price,
      change: change ?? this.change,
      changePercent: changePercent ?? this.changePercent,
      volume: volume ?? this.volume,
      score: score ?? this.score,
      logoUrl: logoUrl ?? this.logoUrl,
      quotePrice: quotePrice ?? this.quotePrice,
      quoteChange: quoteChange ?? this.quoteChange,
      turnover: turnover ?? this.turnover,
    );
  }
}

class CandlePoint {
  const CandlePoint({
    required this.open,
    required this.high,
    required this.low,
    required this.close,
    required this.volume,
    this.timestamp = '',
  });

  final double open;
  final double high;
  final double low;
  final double close;
  final double volume;
  final String timestamp;

  CandlePoint copyWith({
    double? open,
    double? high,
    double? low,
    double? close,
    double? volume,
    String? timestamp,
  }) {
    return CandlePoint(
      open: open ?? this.open,
      high: high ?? this.high,
      low: low ?? this.low,
      close: close ?? this.close,
      volume: volume ?? this.volume,
      timestamp: timestamp ?? this.timestamp,
    );
  }
}

class SignalSnapshot {
  const SignalSnapshot({
    required this.score,
    required this.decision,
    required this.reason,
    required this.entry,
    required this.stop,
    required this.take,
    this.riskWarning,
    this.snapshotId = '',
    this.aiStatus = 'LOCAL',
    this.validUntil,
    this.hasTradePrices = true,
    this.cancelConditions = const [],
    this.dangerSignals = const [],
    this.staleDataMs = 0,
  });

  final int score;
  final String decision;
  final String reason;
  final int entry;
  final int stop;
  final int take;
  final String? riskWarning;
  final String snapshotId;
  final String aiStatus;
  final DateTime? validUntil;
  final bool hasTradePrices;
  final List<String> cancelConditions;
  final List<String> dangerSignals;
  final int staleDataMs;

  bool get isExpired {
    final until = validUntil;
    return until != null && DateTime.now().isAfter(until);
  }

  bool get isActionable {
    return decision == 'ENTER' &&
        aiStatus != 'HARD_FILTERED' &&
        !isExpired &&
        hasTradePrices;
  }
}
