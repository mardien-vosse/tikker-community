enum MarketDataSource {
  generated('가상 시세', '외부 공급 없이 직접 생성한 기능 검사 데이터'),
  kisLive('KIS LIVE', 'KIS WebSocket 실시간'),
  kisRest('KIS REST', 'KIS REST 조회'),
  fallbackSample('FALLBACK', '대체 샘플 데이터'),
  stale('STALE', '오래된 실시간 데이터'),
  unavailable('UNAVAILABLE', '데이터 확인 불가');

  const MarketDataSource(this.label, this.description);

  final String label;
  final String description;

  bool get isTrusted =>
      this == MarketDataSource.kisLive || this == MarketDataSource.kisRest;

  bool get needsCaution => !isTrusted;
}
