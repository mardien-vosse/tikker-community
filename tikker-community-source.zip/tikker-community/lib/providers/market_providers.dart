import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../features/demo/demo_market_data.dart';
import '../features/chart/chart_state.dart';
import '../features/chart/realtime_candle_builder.dart';
import '../shared/models/market_models.dart';
import '../shared/models/market_data_source.dart';

// No network transport exists in Community Preview.
final selectedSymbolProvider =
    StateProvider<String>((ref) => DemoMarketData.symbols.first);
final watchlistProvider = StateProvider<List<MarketStock>>(
    (ref) => DemoMarketData.symbols.map(DemoMarketData.stock).toList());
final displayWatchlistProvider =
    Provider<List<MarketStock>>((ref) => ref.watch(watchlistProvider));
final liveWatchlistProvider = FutureProvider<List<MarketStock>>(
    (ref) async => ref.watch(displayWatchlistProvider));
final selectedStockProvider = Provider<MarketStock>(
    (ref) => DemoMarketData.stock(ref.watch(selectedSymbolProvider)));
final liveSelectedStockProvider = FutureProvider<MarketStock>(
    (ref) async => ref.watch(selectedStockProvider));
final candleProvider = Provider<List<CandlePoint>>((ref) =>
    DemoMarketData.candles(
        ref.watch(selectedSymbolProvider), ref.watch(chartTimeframeProvider)));
final liveCandleProvider = StreamProvider<List<CandlePoint>>(
    (ref) => Stream.value(ref.watch(candleProvider)));
final multiChartCandlesProvider =
    StreamProvider<Map<String, List<CandlePoint>>>((ref) => Stream.value({
          for (final symbol in DemoMarketData.symbols)
            symbol: DemoMarketData.candles(
                symbol, ref.watch(chartTimeframeProvider))
        }));
final liveComparisonCandlesProvider =
    StreamProvider<Map<String, List<CandlePoint>>>((ref) => Stream.value({
          for (final symbol in ref
              .watch(chartComparisonSymbolsProvider)
              .where(DemoMarketData.contains))
            symbol: DemoMarketData.candles(
                symbol, ref.watch(chartTimeframeProvider))
        }));
final selectedCandleSourceProvider =
    Provider<MarketDataSource>((ref) => MarketDataSource.generated);
final selectedStockSourceProvider =
    Provider<MarketDataSource>((ref) => MarketDataSource.generated);
final realtimeCandleUpdateCountProvider = Provider<int>((ref) => 0);
final lastRealtimeTradeTickProvider =
    Provider<RealtimeTradeTick?>((ref) => null);
final lastRealtimeCandleReceivedAtProvider = Provider<DateTime?>((ref) => null);
final realtimeCandleFreshnessClockProvider =
    StreamProvider<DateTime>((ref) => const Stream.empty());

void reorderWatchlistStock(WidgetRef ref, int oldIndex, int newIndex) {
  final current = ref.read(watchlistProvider);
  if (oldIndex < 0 || oldIndex >= current.length) return;
  final boundedNewIndex = newIndex.clamp(0, current.length).toInt();
  final adjustedNewIndex =
      oldIndex < boundedNewIndex ? boundedNewIndex - 1 : boundedNewIndex;
  if (oldIndex == adjustedNewIndex) return;

  final reordered = current.toList();
  final moved = reordered.removeAt(oldIndex);
  reordered.insert(adjustedNewIndex, moved);
  ref.read(watchlistProvider.notifier).state = reordered;
}
