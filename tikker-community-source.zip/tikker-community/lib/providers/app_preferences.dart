import 'dart:async';
import 'dart:convert';

import 'package:flutter/widgets.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../features/chart/chart_state.dart';
import '../features/chart/chart_viewport.dart';
import '../features/home/widgets/pane_layout.dart';
import '../features/watchlist/watchlist_display_settings.dart';
import 'market_providers.dart';
import '../shared/models/market_models.dart';

class AppPreferenceSnapshot {
  const AppPreferenceSnapshot({
    required this.selectedSymbol,
    required this.watchlistSymbols,
    required this.timeframe,
    required this.renderMode,
    required this.multiLayout,
    required this.multiSymbols,
    required this.indicators,
    required this.volumeVisible,
    required this.comparisonEnabled,
    required this.comparisonSymbols,
    required this.hiddenComparisonSymbols,
    required this.drawingAnnotations,
    required this.menuHelpEnabled,
    required this.watchlistDisplaySettings,
    required this.paneLayout,
  });

  static const defaults = AppPreferenceSnapshot(
    selectedSymbol: 'DEMO001',
    watchlistSymbols: ['DEMO001', 'DEMO002', 'DEMO003', 'DEMO004'],
    timeframe: ChartTimeframe.day,
    renderMode: ChartRenderMode.candle,
    multiLayout: ChartMultiLayout.one,
    multiSymbols: [],
    indicators: {ChartIndicator.ema},
    volumeVisible: true,
    comparisonEnabled: false,
    comparisonSymbols: {'DEMO002'},
    hiddenComparisonSymbols: {},
    drawingAnnotations: [],
    menuHelpEnabled: true,
    watchlistDisplaySettings: WatchlistDisplaySettings(),
    paneLayout: PaneLayout(left: 280, right: 340),
  );

  final String selectedSymbol;
  final List<String> watchlistSymbols;
  final ChartTimeframe timeframe;
  final ChartRenderMode renderMode;
  final ChartMultiLayout multiLayout;
  final List<String> multiSymbols;
  final Set<ChartIndicator> indicators;
  final bool volumeVisible;
  final bool comparisonEnabled;
  final Set<String> comparisonSymbols;
  final Set<String> hiddenComparisonSymbols;
  final List<ChartDrawingAnnotation> drawingAnnotations;
  final bool menuHelpEnabled;
  final WatchlistDisplaySettings watchlistDisplaySettings;
  final PaneLayout paneLayout;
}

abstract interface class AppPreferencesStore {
  AppPreferenceSnapshot load();
  Future<void> saveSelectedSymbol(String symbol);
  Future<void> saveWatchlistSymbols(List<String> symbols);
  Future<void> saveTimeframe(ChartTimeframe timeframe);
  Future<void> saveRenderMode(ChartRenderMode renderMode);
  Future<void> saveMultiLayout(ChartMultiLayout multiLayout);
  Future<void> saveMultiSymbols(List<String> symbols);
  Future<void> saveIndicators(Set<ChartIndicator> indicators);
  Future<void> saveVolumeVisible(bool visible);
  Future<void> saveComparisonEnabled(bool enabled);
  Future<void> saveComparisonSymbols(Set<String> symbols);
  Future<void> saveHiddenComparisonSymbols(Set<String> symbols);
  Future<void> saveMenuHelpEnabled(bool enabled);
  Future<void> saveWatchlistDisplaySettings(
    WatchlistDisplaySettings settings,
  );
  Future<void> savePaneLayout(PaneLayout layout);
  ChartViewport loadChartViewport({
    required String symbol,
    required ChartTimeframe timeframe,
  });
  Future<void> saveChartViewport({
    required String symbol,
    required ChartTimeframe timeframe,
    required ChartViewport viewport,
  });
  List<ChartDrawingAnnotation> loadDrawingAnnotations({
    required String symbol,
    required ChartTimeframe timeframe,
    bool includeLegacyFallback = false,
  });
  Future<void> saveDrawingAnnotations({
    required String symbol,
    required ChartTimeframe timeframe,
    required List<ChartDrawingAnnotation> drawings,
  });
}

final appPreferencesStoreProvider = Provider<AppPreferencesStore>(
  (ref) => const NoopAppPreferencesStore(),
);

final menuHelpEnabledProvider = StateProvider<bool>(
  (ref) => AppPreferenceSnapshot.defaults.menuHelpEnabled,
);

class NoopAppPreferencesStore implements AppPreferencesStore {
  const NoopAppPreferencesStore();

  @override
  AppPreferenceSnapshot load() => AppPreferenceSnapshot.defaults;

  @override
  Future<void> saveIndicators(Set<ChartIndicator> indicators) async {}

  @override
  Future<void> saveComparisonEnabled(bool enabled) async {}

  @override
  Future<void> saveComparisonSymbols(Set<String> symbols) async {}

  @override
  Future<void> saveHiddenComparisonSymbols(Set<String> symbols) async {}

  @override
  Future<void> saveMenuHelpEnabled(bool enabled) async {}

  @override
  Future<void> saveWatchlistDisplaySettings(
    WatchlistDisplaySettings settings,
  ) async {}

  @override
  Future<void> savePaneLayout(PaneLayout layout) async {}

  @override
  ChartViewport loadChartViewport({
    required String symbol,
    required ChartTimeframe timeframe,
  }) =>
      const ChartViewport();

  @override
  Future<void> saveChartViewport({
    required String symbol,
    required ChartTimeframe timeframe,
    required ChartViewport viewport,
  }) async {}

  @override
  List<ChartDrawingAnnotation> loadDrawingAnnotations({
    required String symbol,
    required ChartTimeframe timeframe,
    bool includeLegacyFallback = false,
  }) {
    return const [];
  }

  @override
  Future<void> saveDrawingAnnotations({
    required String symbol,
    required ChartTimeframe timeframe,
    required List<ChartDrawingAnnotation> drawings,
  }) async {}

  @override
  Future<void> saveRenderMode(ChartRenderMode renderMode) async {}

  @override
  Future<void> saveMultiLayout(ChartMultiLayout multiLayout) async {}

  @override
  Future<void> saveMultiSymbols(List<String> symbols) async {}

  @override
  Future<void> saveSelectedSymbol(String symbol) async {}

  @override
  Future<void> saveWatchlistSymbols(List<String> symbols) async {}

  @override
  Future<void> saveTimeframe(ChartTimeframe timeframe) async {}

  @override
  Future<void> saveVolumeVisible(bool visible) async {}
}

class SharedPreferencesAppPreferencesStore implements AppPreferencesStore {
  SharedPreferencesAppPreferencesStore(
    SharedPreferences preferences, {
    String namespace = '',
  }) : _preferences = _NamespacedPreferences(preferences, namespace);

  static Future<SharedPreferencesAppPreferencesStore> create({
    String namespace = '',
  }) async {
    final preferences = await SharedPreferences.getInstance();
    return SharedPreferencesAppPreferencesStore(preferences,
        namespace: namespace);
  }

  final _NamespacedPreferences _preferences;

  @override
  AppPreferenceSnapshot load() {
    const defaults = AppPreferenceSnapshot.defaults;
    final selectedSymbol =
        _preferences.getString(_PreferenceKeys.selectedSymbol) ??
            defaults.selectedSymbol;
    final timeframe = _enumValue(
      ChartTimeframe.values,
      _preferences.getString(_PreferenceKeys.timeframe),
      defaults.timeframe,
    );
    return AppPreferenceSnapshot(
      selectedSymbol: selectedSymbol,
      watchlistSymbols: _readStringList(
        _PreferenceKeys.watchlistSymbols,
        defaults.watchlistSymbols,
      ),
      timeframe: timeframe,
      renderMode: _enumValue(
        ChartRenderMode.values,
        _preferences.getString(_PreferenceKeys.renderMode),
        defaults.renderMode,
      ),
      multiLayout: _enumValue(
        ChartMultiLayout.values,
        _preferences.getString(_PreferenceKeys.multiLayout),
        defaults.multiLayout,
      ),
      multiSymbols: _readStringList(
        _PreferenceKeys.multiSymbols,
        defaults.multiSymbols,
      ),
      indicators: _readIndicators(defaults.indicators),
      volumeVisible: _preferences.getBool(_PreferenceKeys.volumeVisible) ??
          defaults.volumeVisible,
      comparisonEnabled:
          _preferences.getBool(_PreferenceKeys.comparisonEnabled) ??
              defaults.comparisonEnabled,
      comparisonSymbols: _readStringSet(
        _PreferenceKeys.comparisonSymbols,
        defaults.comparisonSymbols,
      ),
      hiddenComparisonSymbols: _readStringSet(
        _PreferenceKeys.hiddenComparisonSymbols,
        defaults.hiddenComparisonSymbols,
      ),
      drawingAnnotations: loadDrawingAnnotations(
        symbol: selectedSymbol,
        timeframe: timeframe,
        includeLegacyFallback: true,
      ),
      menuHelpEnabled: _preferences.getBool(_PreferenceKeys.menuHelpEnabled) ??
          defaults.menuHelpEnabled,
      watchlistDisplaySettings: _readWatchlistDisplaySettings(
        defaults.watchlistDisplaySettings,
      ),
      paneLayout: _readPaneLayout(defaults.paneLayout),
    );
  }

  @override
  Future<void> saveSelectedSymbol(String symbol) async {
    final trimmed = symbol.trim();
    if (trimmed.isEmpty) return;
    await _preferences.setString(_PreferenceKeys.selectedSymbol, trimmed);
  }

  @override
  Future<void> saveWatchlistSymbols(List<String> symbols) async {
    await _saveStringList(_PreferenceKeys.watchlistSymbols, symbols);
  }

  @override
  Future<void> saveTimeframe(ChartTimeframe timeframe) async {
    await _preferences.setString(_PreferenceKeys.timeframe, timeframe.name);
  }

  @override
  Future<void> saveRenderMode(ChartRenderMode renderMode) async {
    await _preferences.setString(_PreferenceKeys.renderMode, renderMode.name);
  }

  @override
  Future<void> saveMultiLayout(ChartMultiLayout multiLayout) async {
    await _preferences.setString(_PreferenceKeys.multiLayout, multiLayout.name);
  }

  @override
  Future<void> saveMultiSymbols(List<String> symbols) async {
    await _saveStringList(_PreferenceKeys.multiSymbols, symbols);
  }

  @override
  Future<void> saveIndicators(Set<ChartIndicator> indicators) async {
    final names = indicators.map((indicator) => indicator.name).toList()
      ..sort();
    await _preferences.setString(_PreferenceKeys.indicators, names.join(','));
  }

  @override
  Future<void> saveVolumeVisible(bool visible) async {
    await _preferences.setBool(_PreferenceKeys.volumeVisible, visible);
  }

  @override
  Future<void> saveComparisonEnabled(bool enabled) async {
    await _preferences.setBool(_PreferenceKeys.comparisonEnabled, enabled);
  }

  @override
  Future<void> saveComparisonSymbols(Set<String> symbols) async {
    await _saveStringSet(_PreferenceKeys.comparisonSymbols, symbols);
  }

  @override
  Future<void> saveHiddenComparisonSymbols(Set<String> symbols) async {
    await _saveStringSet(_PreferenceKeys.hiddenComparisonSymbols, symbols);
  }

  @override
  Future<void> saveMenuHelpEnabled(bool enabled) async {
    await _preferences.setBool(_PreferenceKeys.menuHelpEnabled, enabled);
  }

  @override
  Future<void> saveWatchlistDisplaySettings(
    WatchlistDisplaySettings settings,
  ) async {
    await _preferences.setString(
      _PreferenceKeys.watchlistDisplaySettings,
      jsonEncode({
        'showRowSeparators': settings.showRowSeparators,
        'showVolume': settings.showVolume,
        'showChangeAmount': settings.showChangeAmount,
        'showCandleMarker': settings.showCandleMarker,
        'showMemo': settings.showMemo,
        'showAfterHoursDomestic': settings.showAfterHoursDomestic,
        'showAfterHoursForeign': settings.showAfterHoursForeign,
        'flashPriceChanges': settings.flashPriceChanges,
        'deltaBasis': settings.deltaBasis.name,
        'showSpecialTags': settings.showSpecialTags,
      }),
    );
  }

  @override
  Future<void> savePaneLayout(PaneLayout layout) async {
    await _preferences.setString(
      _PreferenceKeys.paneLayout,
      jsonEncode({
        'left': layout.left,
        'right': layout.right,
        'rightVisible': layout.rightVisible,
      }),
    );
  }

  @override
  ChartViewport loadChartViewport({
    required String symbol,
    required ChartTimeframe timeframe,
  }) {
    final raw = _preferences.getString(
      _PreferenceKeys.chartViewportFor(symbol, timeframe),
    );
    if (raw == null) return const ChartViewport();
    try {
      final decoded = jsonDecode(raw);
      if (decoded is! Map<String, Object?>) return const ChartViewport();
      final capacity = decoded['capacity'];
      final endTime = decoded['endTime'];
      if (capacity is! num) return const ChartViewport();
      return ChartViewport(
        capacity: capacity.toInt().clamp(20, 600),
        endTime: endTime is String && endTime.isNotEmpty ? endTime : null,
      );
    } on FormatException {
      return const ChartViewport();
    } on TypeError {
      return const ChartViewport();
    }
  }

  @override
  Future<void> saveChartViewport({
    required String symbol,
    required ChartTimeframe timeframe,
    required ChartViewport viewport,
  }) async {
    await _preferences.setString(
      _PreferenceKeys.chartViewportFor(symbol, timeframe),
      jsonEncode({
        'capacity': viewport.capacity,
        'endTime': viewport.endTime,
      }),
    );
  }

  @override
  List<ChartDrawingAnnotation> loadDrawingAnnotations({
    required String symbol,
    required ChartTimeframe timeframe,
    bool includeLegacyFallback = false,
  }) {
    final fallback = includeLegacyFallback
        ? _readDrawingAnnotations(
            _PreferenceKeys.legacyDrawingAnnotations,
            AppPreferenceSnapshot.defaults.drawingAnnotations,
          )
        : AppPreferenceSnapshot.defaults.drawingAnnotations;
    return _readDrawingAnnotations(
      _PreferenceKeys.drawingAnnotationsFor(symbol, timeframe),
      fallback,
    );
  }

  @override
  Future<void> saveDrawingAnnotations({
    required String symbol,
    required ChartTimeframe timeframe,
    required List<ChartDrawingAnnotation> drawings,
  }) async {
    final payload = [
      for (final drawing in drawings.take(30))
        {
          'tool': drawing.tool.name,
          'channelOffset': drawing.channelOffset,
          'colorValue': drawing.colorValue,
          'strokeWidth': drawing.strokeWidth,
          'dashed': drawing.dashed,
          'locked': drawing.locked,
          'hidden': drawing.hidden,
          'label': drawing.label,
          'startX': drawing.startX,
          if (drawing.anchored) ...{
            'version': 2,
            'startTime': drawing.startTime,
            'startPrice': drawing.startPrice,
            'endTime': drawing.endTime,
            'endPrice': drawing.endPrice,
          },
          'startY': drawing.startY,
          'endX': drawing.endX,
          'endY': drawing.endY,
        },
    ];
    await _preferences.setString(
      _PreferenceKeys.drawingAnnotationsFor(symbol, timeframe),
      jsonEncode(payload),
    );
  }

  Set<ChartIndicator> _readIndicators(Set<ChartIndicator> defaults) {
    final raw = _preferences.getString(_PreferenceKeys.indicators);
    if (raw == null) return defaults;
    if (raw.isEmpty) return const {};
    return raw
        .split(',')
        .map((name) => _nullableEnumValue(ChartIndicator.values, name))
        .whereType<ChartIndicator>()
        .toSet();
  }

  Set<String> _readStringSet(String key, Set<String> defaults) {
    final raw = _preferences.getString(key);
    if (raw == null) return defaults;
    if (raw.isEmpty) return const {};
    return raw
        .split(',')
        .map((symbol) => symbol.trim())
        .where((symbol) => symbol.isNotEmpty)
        .toSet();
  }

  List<String> _readStringList(String key, List<String> defaults) {
    final raw = _preferences.getString(key);
    if (raw == null) return defaults;
    return raw
        .split(',')
        .map((symbol) => symbol.trim())
        .where((symbol) => symbol.isNotEmpty)
        .toList(growable: false);
  }

  List<ChartDrawingAnnotation> _readDrawingAnnotations(
    String key,
    List<ChartDrawingAnnotation> defaults,
  ) {
    final raw = _preferences.getString(key);
    if (raw == null) return defaults;
    try {
      final decoded = jsonDecode(raw);
      if (decoded is! List) return defaults;
      final drawings = <ChartDrawingAnnotation>[];
      for (final item in decoded) {
        if (item is! Map<String, Object?>) continue;
        final tool = _nullableEnumValue(
          ChartDrawingTool.values,
          item['tool'] as String?,
        );
        final startX = _readDouble(item['startX']);
        final startY = _readDouble(item['startY']);
        final endX = _readDouble(item['endX']);
        final endY = _readDouble(item['endY']);
        if (item['version'] == 2 &&
            (_validDrawingTime(item['startTime']) == null ||
                _validDrawingTime(item['endTime']) == null ||
                _readDouble(item['startPrice']) == null ||
                _readDouble(item['endPrice']) == null)) {
          continue;
        }
        if (tool == null ||
            tool == ChartDrawingTool.none ||
            startX == null ||
            startY == null ||
            endX == null ||
            endY == null) {
          continue;
        }
        drawings.add(
          ChartDrawingAnnotation(
            tool: tool,
            channelOffset: _readDouble(item['channelOffset']) ?? 0,
            colorValue: item['colorValue'] is int
                ? (item['colorValue'] as int) & 0xFFFFFFFF
                : 0xFF00C4B4,
            strokeWidth:
                (_readDouble(item['strokeWidth']) ?? 1.5).clamp(1.0, 4.0),
            dashed: item['dashed'] == true,
            locked: item['locked'] == true,
            hidden: item['hidden'] == true,
            label: item['label'] is String
                ? (item['label'] as String)
                    .substring(0, (item['label'] as String).length.clamp(0, 40))
                : '',
            startX: _clampUnit(startX),
            startY: _clampUnit(startY),
            endX: _clampUnit(endX),
            endY: _clampUnit(endY),
            startTime: _validDrawingTime(item['startTime']),
            endTime: _validDrawingTime(item['endTime']),
            startPrice: _readDouble(item['startPrice']),
            endPrice: _readDouble(item['endPrice']),
          ),
        );
      }
      // Why: malformed or very old preference payloads should not overload the
      // custom painter or gesture hit testing during app start.
      return drawings.take(30).toList(growable: false);
    } on FormatException {
      return defaults;
    } on TypeError {
      return defaults;
    }
  }

  String? _validDrawingTime(Object? value) =>
      value is String && DateTime.tryParse(value) != null ? value : null;

  WatchlistDisplaySettings _readWatchlistDisplaySettings(
    WatchlistDisplaySettings defaults,
  ) {
    final raw =
        _preferences.getString(_PreferenceKeys.watchlistDisplaySettings);
    if (raw == null) return defaults;
    try {
      final decoded = jsonDecode(raw);
      if (decoded is! Map<String, Object?>) return defaults;
      // Why: display settings should tolerate old or partially written payloads
      // so a malformed preference cannot blank the personal watchlist.
      return WatchlistDisplaySettings(
        showRowSeparators:
            decoded['showRowSeparators'] as bool? ?? defaults.showRowSeparators,
        showVolume: decoded['showVolume'] as bool? ?? defaults.showVolume,
        showChangeAmount:
            decoded['showChangeAmount'] as bool? ?? defaults.showChangeAmount,
        showCandleMarker:
            decoded['showCandleMarker'] as bool? ?? defaults.showCandleMarker,
        showMemo: decoded['showMemo'] as bool? ?? defaults.showMemo,
        showAfterHoursDomestic: decoded['showAfterHoursDomestic'] as bool? ??
            defaults.showAfterHoursDomestic,
        showAfterHoursForeign: decoded['showAfterHoursForeign'] as bool? ??
            defaults.showAfterHoursForeign,
        flashPriceChanges:
            decoded['flashPriceChanges'] as bool? ?? defaults.flashPriceChanges,
        deltaBasis: _enumValue(
          WatchlistDeltaBasis.values,
          decoded['deltaBasis'] as String?,
          defaults.deltaBasis,
        ),
        showSpecialTags:
            decoded['showSpecialTags'] as bool? ?? defaults.showSpecialTags,
      );
    } on FormatException {
      return defaults;
    } on TypeError {
      return defaults;
    }
  }

  PaneLayout _readPaneLayout(PaneLayout defaults) {
    final raw = _preferences.getString(_PreferenceKeys.paneLayout);
    if (raw == null) return defaults;
    try {
      final decoded = jsonDecode(raw);
      if (decoded is! Map<String, Object?>) return defaults;
      return PaneLayout(
        left: _readDouble(decoded['left']) ?? defaults.left,
        right: _readDouble(decoded['right']) ?? defaults.right,
        rightVisible: decoded['rightVisible'] as bool? ?? defaults.rightVisible,
      );
    } on FormatException {
      return defaults;
    } on TypeError {
      return defaults;
    }
  }

  double? _readDouble(Object? value) {
    if (value is num && value.isFinite) return value.toDouble();
    return null;
  }

  double _clampUnit(double value) {
    return value.clamp(0.0, 1.0).toDouble();
  }

  Future<void> _saveStringList(String key, List<String> values) async {
    final seen = <String>{};
    final symbols = [
      for (final value in values)
        if (value.trim().isNotEmpty && seen.add(value.trim())) value.trim(),
    ];
    await _preferences.setString(key, symbols.join(','));
  }

  Future<void> _saveStringSet(String key, Set<String> values) async {
    final names = values.map((value) => value.trim()).where((value) {
      return value.isNotEmpty;
    }).toList()
      ..sort();
    await _preferences.setString(key, names.join(','));
  }
}

// Prefix every read, write and legacy fallback; private keys remain unchanged.
class _NamespacedPreferences {
  const _NamespacedPreferences(this.preferences, this.namespace);

  final SharedPreferences preferences;
  final String namespace;

  String _key(String key) => namespace.isEmpty ? key : '$namespace.$key';
  String? getString(String key) => preferences.getString(_key(key));
  bool? getBool(String key) => preferences.getBool(_key(key));
  Future<bool> setString(String key, String value) =>
      preferences.setString(_key(key), value);
  Future<bool> setBool(String key, bool value) =>
      preferences.setBool(_key(key), value);
}

class AppPreferencesBinder extends ConsumerWidget {
  const AppPreferencesBinder({
    required this.child,
    super.key,
  });

  final Widget child;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final store = ref.watch(appPreferencesStoreProvider);

    ref.listen<String>(selectedSymbolProvider, (previous, next) {
      final timeframe = ref.read(chartTimeframeProvider);
      if (previous != null) {
        unawaited(
          store.saveDrawingAnnotations(
            symbol: previous,
            timeframe: timeframe,
            drawings: ref.read(chartDrawingAnnotationsProvider),
          ),
        );
      }
      unawaited(store.saveSelectedSymbol(next));
      _restoreDrawingsForScope(ref, store, next, timeframe);
    });
    ref.listen<List<MarketStock>>(watchlistProvider, (_, next) {
      unawaited(store.saveWatchlistSymbols([
        for (final stock in next) stock.symbol,
      ]));
    });
    ref.listen<ChartTimeframe>(chartTimeframeProvider, (previous, next) {
      final symbol = ref.read(selectedSymbolProvider);
      if (previous != null) {
        unawaited(
          store.saveDrawingAnnotations(
            symbol: symbol,
            timeframe: previous,
            drawings: ref.read(chartDrawingAnnotationsProvider),
          ),
        );
      }
      unawaited(store.saveTimeframe(next));
      _restoreDrawingsForScope(ref, store, symbol, next);
    });
    ref.listen<ChartRenderMode>(chartRenderModeProvider, (_, next) {
      unawaited(store.saveRenderMode(next));
    });
    ref.listen<ChartMultiLayout>(chartMultiLayoutProvider, (_, next) {
      unawaited(store.saveMultiLayout(next));
    });
    ref.listen<List<String>>(chartMultiSymbolsProvider, (_, next) {
      unawaited(store.saveMultiSymbols(next));
    });
    ref.listen<Set<ChartIndicator>>(chartIndicatorVisibilityProvider, (
      _,
      next,
    ) {
      unawaited(store.saveIndicators(next));
    });
    ref.listen<bool>(chartVolumeVisibleProvider, (_, next) {
      unawaited(store.saveVolumeVisible(next));
    });
    ref.listen<bool>(chartComparisonEnabledProvider, (_, next) {
      unawaited(store.saveComparisonEnabled(next));
    });
    ref.listen<Set<String>>(chartComparisonSymbolsProvider, (_, next) {
      unawaited(store.saveComparisonSymbols(next));
    });
    ref.listen<Set<String>>(chartHiddenComparisonSymbolsProvider, (_, next) {
      unawaited(store.saveHiddenComparisonSymbols(next));
    });
    ref.listen<bool>(menuHelpEnabledProvider, (_, next) {
      unawaited(store.saveMenuHelpEnabled(next));
    });
    ref.listen<WatchlistDisplaySettings>(
      watchlistDisplaySettingsProvider,
      (_, next) {
        unawaited(store.saveWatchlistDisplaySettings(next));
      },
    );
    ref.listen<PaneLayout>(paneLayoutProvider, (_, next) {
      unawaited(Future<void>.delayed(const Duration(milliseconds: 250), () {
        if (identical(ref.read(paneLayoutProvider), next)) {
          return store.savePaneLayout(next);
        }
      }));
    });
    ref.listen<List<ChartDrawingAnnotation>>(chartDrawingAnnotationsProvider, (
      _,
      next,
    ) {
      unawaited(
        store.saveDrawingAnnotations(
          symbol: ref.read(selectedSymbolProvider),
          timeframe: ref.read(chartTimeframeProvider),
          drawings: next,
        ),
      );
    });

    return child;
  }

  void _restoreDrawingsForScope(
    WidgetRef ref,
    AppPreferencesStore store,
    String symbol,
    ChartTimeframe timeframe,
  ) {
    // Why: chart annotations belong to the current stock and candle interval;
    // leaking them across symbols makes technical analysis misleading.
    ref.read(chartDraftDrawingProvider.notifier).state = null;
    ref.read(chartSelectedDrawingIndexProvider.notifier).state = null;
    ref.read(chartDrawingAnnotationsProvider.notifier).state =
        store.loadDrawingAnnotations(symbol: symbol, timeframe: timeframe);
  }
}

class _PreferenceKeys {
  static const selectedSymbol = 'tikker.selected_symbol';
  static const watchlistSymbols = 'tikker.watchlist_symbols';
  static const timeframe = 'tikker.chart_timeframe';
  static const renderMode = 'tikker.chart_render_mode';
  static const multiLayout = 'tikker.chart_multi_layout';
  static const multiSymbols = 'tikker.chart_multi_symbols';
  static const indicators = 'tikker.chart_indicators';
  static const volumeVisible = 'tikker.chart_volume_visible';
  static const comparisonEnabled = 'tikker.chart_comparison_enabled';
  static const comparisonSymbols = 'tikker.chart_comparison_symbols';
  static const hiddenComparisonSymbols =
      'tikker.chart_hidden_comparison_symbols';
  static const menuHelpEnabled = 'tikker.menu_help_enabled';
  static const watchlistDisplaySettings = 'tikker.watchlist_display_settings';
  static const paneLayout = 'tikker.pane_layout';
  static const legacyDrawingAnnotations = 'tikker.chart_drawing_annotations';

  static String drawingAnnotationsFor(
    String symbol,
    ChartTimeframe timeframe,
  ) {
    return 'tikker.chart_drawing_annotations.${symbol.trim()}.${timeframe.name}';
  }

  static String chartViewportFor(
    String symbol,
    ChartTimeframe timeframe,
  ) {
    return 'tikker.chart_viewport.${symbol.trim()}.${timeframe.name}';
  }
}

T _enumValue<T extends Enum>(List<T> values, String? name, T fallback) {
  return _nullableEnumValue(values, name) ?? fallback;
}

T? _nullableEnumValue<T extends Enum>(List<T> values, String? name) {
  if (name == null) return null;
  for (final value in values) {
    if (value.name == name) return value;
  }
  return null;
}
