# Contributing

Keep changes focused and include reproduction steps for bugs. Use generated
fictional data in tests. Never include account details, tokens, personal logs,
real market feeds or private screenshots in issues or commits.

Run `flutter analyze` and `flutter test`. For visual changes, also build and
exercise the web app and include screenshots made with fictional data.

Contributions are submitted under Apache-2.0. Keep all third-party notices.
Live data adapters, order execution and AI authentication are outside this preview.
