# Community Preview verification — 2026-10-18

## Verified locally

- Flutter 3.41.9 / Dart 3.11.5; web release and macOS release builds.
- `flutter analyze`: no issues.
- `flutter test`: 23 passed. Deterministic generated data; valid OHLC;
  watchlist selection updates actual painted candles; drawing edit/cancel;
  per-symbol drawing persistence and multi-chart reload; coordinate/viewport
  calculations; SMA warm-up and statistics; preferences namespace isolation.
- Public source boundary check passed. No Dio, sockets, Firebase, account,
  order, AI or real-data adapters are included.
- Browser: switched generated symbols, switched to 1 minute, stepped replay,
  drew a rectangle, changed color/dash/lock/name and reloaded to verify restoration.
- Source ZIP opened and CRC integrity checked; explicit allowlist excludes
  private backend, history, environment files, user data, logs and caches.

## Scope and known limits

- Only generated fictional data. Replay starts at step zero after reopening;
  saved drawings and layout persist. Nothing synchronizes between devices.
- Standalone EMA overlay is not present; the available moving-average overlay
  is SMA. MACD uses EMA internally. Do not advertise a separate EMA control.
- Real providers, AI login, trading, mobile apps and Windows are excluded.
- Source checks are not a complete security or copyright audit. Runtime traffic
  was not captured with a network trace; inspection found no app transport and
  macOS entitlement verification is recorded separately in the local QA log.
- macOS universal executable builds for arm64/x86_64; only launch/render on this Apple Silicon
  Mac is verified. Developer ID signing, notarization and clean-machine
  installation remain pending. The ZIP is a local test artifact, not a public release.
- GitHub owner selected by the user: mardien-vosse. Initial private repository
  created; public visibility and Pages deployment are pending.
- macOS native window rendered correctly, including daily date labels. Further
  native input verification was blocked by the UI tool returning noWindowsAvailable;
  interactive checks above were performed in Chrome.

QA logs/screenshots live in ignored `.qa/`. The homepage screenshot contains
only generated fictional data. Re-run checks before a future release.
