# Release procedure

1. Run `flutter pub get`, `flutter analyze`, `flutter test`.
2. Run `python3 scripts/audit_public.py` and review THIRD_PARTY_NOTICES.md.
3. Run `python3 scripts/build_site.py`; serve `dist/site` on a local HTTP server.
4. Exercise symbol changes, replay, timeframe/layout changes, drawing edit/save
   and reload. Verify no market, AI, authentication or analytics requests.
5. Inspect the source ZIP and SHA256SUMS. Do not upload the private parent project.
6. Publish only this isolated repository, then select GitHub Actions as the Pages
   source and manually run Pages. The workflow is manual to avoid surprise runs.
7. Build macOS with `bash scripts/build_macos.sh`. This creates a **local preview**
   ZIP, not an approved public download. Do not instruct users to disable Gatekeeper.
8. For a public Mac release, sign nested code and the bundle with Developer ID,
   notarize with notarytool, staple the ticket, verify Gatekeeper acceptance on a
   separate clean Mac, and upload that verified ZIP as a GitHub Release asset.
   Add its exact versioned link/checksum to the website only after verification.

Release signing needs the owner's Apple Developer account/certificate. No paid
account is created or charged by these scripts. Windows and mobile are deferred.
