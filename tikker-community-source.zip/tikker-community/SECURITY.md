# Security

Community Preview has no account system, API keys, analytics or market-data
network client. The macOS release sandbox has no network-client entitlement.
Web assets are served by the hosting provider; chart data are generated locally.

Do not post secrets or personal data in public issues. Use GitHub private
vulnerability reporting when it has been enabled by the repository owner.
Until that channel is enabled, do not disclose a security issue publicly.
No response-time or supported-version guarantee is offered during preview.
