#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
if command -v ruby >/dev/null 2>&1; then
  tikker_gem_bin="$(ruby -e 'print Gem.user_dir')/bin"
  export PATH="$tikker_gem_bin:$PATH"
fi
export RUBYOPT="-rlogger ${RUBYOPT:-}"
"${FLUTTER_BIN:-flutter}" build macos --release
mkdir -p dist
app='build/macos/Build/Products/Release/Tikker Community.app'
codesign --force --deep --sign - --entitlements macos/Runner/Release.entitlements "$app"
codesign --verify --deep --strict "$app"
ditto -c -k --sequesterRsrc --keepParent "$app" dist/Tikker-Community-macOS-local-preview.zip
shasum -a 256 dist/Tikker-Community-macOS-local-preview.zip > dist/macos-SHA256SUMS.txt
printf '%s\n' 'Local preview only: Developer ID signing and notarization required before public app distribution.'
