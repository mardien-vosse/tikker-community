#!/usr/bin/env python3
"""Build a self-contained site and a source archive from an explicit allowlist."""
from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys, zipfile
ROOT=Path(__file__).resolve().parents[1]
os.chdir(ROOT)
flutter=os.environ.get('FLUTTER_BIN','flutter')
if '--package-only' not in sys.argv:
 subprocess.run([flutter,'build','web','--release','--no-web-resources-cdn','--base-href','/demo/','--pwa-strategy=none'],check=True)
site=ROOT/'dist/site'
if site.exists(): shutil.rmtree(site)
shutil.copytree(ROOT/'site',site)
shutil.copytree(ROOT/'build/web',site/'demo')
index=site/'demo/index.html'
index.write_text(index.read_text().replace('<base href="/demo/">','<base href="./">'))
(site/'downloads').mkdir(exist_ok=True)
allowed=['lib','test','macos','web','assets','site','scripts','docs','.github']
files=[ROOT/n for n in ['README.md','LICENSE','NOTICE','THIRD_PARTY_NOTICES.md','CONTRIBUTING.md','SECURITY.md','pubspec.yaml','pubspec.lock','analysis_options.yaml','.gitignore']]
excluded={'ephemeral','Pods','xcuserdata','.DS_Store','__pycache__'}
for name in allowed:
 files.extend(p for p in (ROOT/name).rglob('*') if p.is_file() and not any(x in excluded for x in p.relative_to(ROOT).parts))
archive=site/'downloads/tikker-community-source.zip'
manifest={}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(set(files)):
  assert not p.is_symlink(),p
  rel=p.relative_to(ROOT).as_posix()
  z.write(p,'tikker-community/'+rel)
  manifest[rel]=hashlib.sha256(p.read_bytes()).hexdigest()
(site/'downloads/source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(site/'downloads/SHA256SUMS.txt').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+archive.name+'\n')
(site/'.nojekyll').touch()
print(f'Built {site}: {len(manifest)} source files; archive {archive.stat().st_size} bytes')
