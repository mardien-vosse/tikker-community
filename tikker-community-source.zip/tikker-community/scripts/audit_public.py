#!/usr/bin/env python3
"""Fail on private transports/credentials and paths in the public source boundary.
This is a focused regression check, not a full security or rights audit.
"""
from pathlib import Path
import re,sys
root=Path(__file__).resolve().parents[1]
issues=[]
for p in (root/'lib').rglob('*.dart'):
 s=p.read_text()
 patterns=[r"package:(?:dio|firebase|socket_io|url_launcher)",r"dart:(?:io|html)",r'Image\.network',r'https?://',r'/Users/',r'/api/']
 for pattern in patterns:
  if re.search(pattern,s):issues.append(f'{p.relative_to(root)}: forbidden transport or private path ({pattern})')
for directory in ['lib','test','site','docs','web','macos','scripts','.github']:
 for p in (root/directory).rglob('*'):
  if not p.is_file() or any(x in {'Pods','ephemeral','xcuserdata','__pycache__'} for x in p.parts):continue
  if p.name.startswith('.env') or p.suffix in {'.p12','.p8','.key'}:issues.append(str(p.relative_to(root)))
  try:s=p.read_text()
  except UnicodeError:continue
  for pattern in [r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY',r'gh[pousr]_[A-Za-z0-9]{30,}',r'sk-[A-Za-z0-9_-]{30,}']:
   if re.search(pattern,s):issues.append(f'{p.relative_to(root)}: possible credential')
for name in ['LICENSE','NOTICE','THIRD_PARTY_NOTICES.md','assets/fonts/OFL.txt']:
 if not (root/name).is_file():issues.append('Missing '+name)
if issues:
 print('\n'.join(issues));sys.exit(1)
print('PASS: public source boundary, credential patterns and notice presence')
