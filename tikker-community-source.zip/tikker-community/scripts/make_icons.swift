import AppKit
import Foundation
let root = URL(fileURLWithPath: FileManager.default.currentDirectoryPath)
func icon(_ size: Int, _ path: String) throws {
  let bitmap = NSBitmapImageRep(bitmapDataPlanes: nil, pixelsWide: size, pixelsHigh: size, bitsPerSample: 8, samplesPerPixel: 4, hasAlpha: true, isPlanar: false, colorSpaceName: .deviceRGB, bytesPerRow: 0, bitsPerPixel: 0)!
  NSGraphicsContext.saveGraphicsState()
  NSGraphicsContext.current = NSGraphicsContext(bitmapImageRep: bitmap)
  let s = CGFloat(size)
  NSColor(red: 198/255, green: 239/255, blue: 154/255, alpha: 1).setFill()
  NSBezierPath(roundedRect: NSRect(x: s*0.06, y:s*0.06, width:s*0.88,height:s*0.88),xRadius:s*0.19,yRadius:s*0.19).fill()
  NSColor(red:25/255,green:51/255,blue:36/255,alpha:1).setStroke()
  let t = NSBezierPath(); t.lineWidth=s*0.10;t.lineCapStyle = .round
  t.move(to:NSPoint(x:s*0.29,y:s*0.68));t.line(to:NSPoint(x:s*0.71,y:s*0.68));t.move(to:NSPoint(x:s*0.5,y:s*0.68));t.line(to:NSPoint(x:s*0.5,y:s*0.25));t.stroke()
  let bars=NSBezierPath();bars.lineWidth=s*0.065;bars.lineCapStyle = .round
  bars.move(to:NSPoint(x:s*0.31,y:s*0.39));bars.line(to:NSPoint(x:s*0.31,y:s*0.25));bars.move(to:NSPoint(x:s*0.69,y:s*0.5));bars.line(to:NSPoint(x:s*0.69,y:s*0.25));bars.stroke()
  NSGraphicsContext.restoreGraphicsState()
  try bitmap.representation(using:.png,properties:[:])!.write(to:root.appendingPathComponent(path))
}
for size in [16,32,64,128,256,512,1024] {try icon(size,"macos/Runner/Assets.xcassets/AppIcon.appiconset/app_icon_\(size).png")}
try icon(32,"web/favicon.png")
for size in [192,512] {try icon(size,"web/icons/Icon-\(size).png");try icon(size,"web/icons/Icon-maskable-\(size).png")}
