# Third-party notices

Licenses copied from the packages resolved by pubspec.lock. Includes development dependencies; no license was replaced. Flutter engine notices are also bundled by Flutter in release assets.

| Package | Notice |
| --- | --- |
| async | [license](docs/licenses/async-LICENSE) |
| boolean_selector | [license](docs/licenses/boolean_selector-LICENSE) |
| characters | [license](docs/licenses/characters-LICENSE) |
| clock | [license](docs/licenses/clock-LICENSE) |
| collection | [license](docs/licenses/collection-LICENSE) |
| fake_async | [license](docs/licenses/fake_async-LICENSE) |
| ffi | [license](docs/licenses/ffi-LICENSE) |
| file | [license](docs/licenses/file-LICENSE) |
| flutter | [license](docs/licenses/flutter-LICENSE) |
| flutter_lints | [license](docs/licenses/flutter_lints-LICENSE) |
| flutter_riverpod | [license](docs/licenses/flutter_riverpod-LICENSE) |
| leak_tracker | [license](docs/licenses/leak_tracker-LICENSE) |
| leak_tracker_flutter_testing | [license](docs/licenses/leak_tracker_flutter_testing-LICENSE) |
| leak_tracker_testing | [license](docs/licenses/leak_tracker_testing-LICENSE) |
| lints | [license](docs/licenses/lints-LICENSE) |
| matcher | [license](docs/licenses/matcher-LICENSE) |
| material_color_utilities | [license](docs/licenses/material_color_utilities-LICENSE) |
| meta | [license](docs/licenses/meta-LICENSE) |
| path | [license](docs/licenses/path-LICENSE) |
| path_provider_linux | [license](docs/licenses/path_provider_linux-LICENSE) |
| path_provider_platform_interface | [license](docs/licenses/path_provider_platform_interface-LICENSE) |
| path_provider_windows | [license](docs/licenses/path_provider_windows-LICENSE) |
| platform | [license](docs/licenses/platform-LICENSE) |
| plugin_platform_interface | [license](docs/licenses/plugin_platform_interface-LICENSE) |
| riverpod | [license](docs/licenses/riverpod-LICENSE) |
| shared_preferences | [license](docs/licenses/shared_preferences-LICENSE) |
| shared_preferences_android | [license](docs/licenses/shared_preferences_android-LICENSE) |
| shared_preferences_foundation | [license](docs/licenses/shared_preferences_foundation-LICENSE) |
| shared_preferences_linux | [license](docs/licenses/shared_preferences_linux-LICENSE) |
| shared_preferences_platform_interface | [license](docs/licenses/shared_preferences_platform_interface-LICENSE) |
| shared_preferences_web | [license](docs/licenses/shared_preferences_web-LICENSE) |
| shared_preferences_windows | [license](docs/licenses/shared_preferences_windows-LICENSE) |
| sky_engine | [license](docs/licenses/sky_engine-LICENSE) |
| source_span | [license](docs/licenses/source_span-LICENSE) |
| stack_trace | [license](docs/licenses/stack_trace-LICENSE) |
| state_notifier | [license](docs/licenses/state_notifier-LICENSE) |
| stream_channel | [license](docs/licenses/stream_channel-LICENSE) |
| string_scanner | [license](docs/licenses/string_scanner-LICENSE) |
| term_glyph | [license](docs/licenses/term_glyph-LICENSE) |
| test_api | [license](docs/licenses/test_api-LICENSE) |
| vector_math | [license](docs/licenses/vector_math-LICENSE) |
| vm_service | [license](docs/licenses/vm_service-LICENSE) |
| web | [license](docs/licenses/web-LICENSE) |
| xdg_directories | [license](docs/licenses/xdg_directories-LICENSE) |

Noto Sans KR (unmodified): [SIL OFL 1.1](assets/fonts/OFL.txt). Source: https://github.com/notofonts/noto-cjk/tree/main/Sans/Variable/TTF/Subset

Font SHA-256: `9e1d729e7e2b36f9ef439da102f8c134c10aabe46f1c843bf0aca5c043b86f76`

The website mark is an original SVG for this preview. No third-party stock logos or market feed data are bundled.

Flutter test and web plugins are part of the Flutter SDK: [Flutter license](docs/licenses/flutter-LICENSE).
